import React from 'react';
import { Sparkles, Flame, ShieldCheck, RefreshCw } from 'lucide-react';

interface MarqueeBannerProps {
  marqueeTexts?: string[];
}

export const MarqueeBanner: React.FC<MarqueeBannerProps> = ({ marqueeTexts }) => {
  const defaultTexts = [
    'BÔNG STORE',
    'WEAR YOUR STORY',
    '100% COMPACT COTTON 260GSM - 380GSM',
    'ĐỔI TRẢ DỄ DÀNG 14 NGÀY',
    'DESIGNED IN SAIGON',
    'FREE NATIONWIDE SHIPPING > 499K',
    'LIMITED DROPS ONLY',
  ];

  const texts = marqueeTexts && marqueeTexts.length > 0 ? marqueeTexts : defaultTexts;
  const icons = [Sparkles, Flame, ShieldCheck, RefreshCw];

  const items = texts.map((t, idx) => ({
    text: t,
    icon: icons[idx % icons.length]
  }));

  return (
    <div id="marquee-section" className="bg-[#0F0F10] border-y border-neutral-800 text-neutral-100 py-3 overflow-hidden select-none">
      <div className="animate-marquee flex items-center whitespace-nowrap">
        {items.concat(items).map((item, idx) => {
          const Icon = item.icon;
          return (
            <div key={idx} className="flex items-center mx-6 gap-3 text-xs sm:text-sm font-extrabold tracking-widest uppercase">
              <span className="text-neutral-200">{item.text}</span>
              <Icon className="w-3.5 h-3.5 text-amber-400" />
            </div>
          );
        })}
      </div>
    </div>
  );
};

