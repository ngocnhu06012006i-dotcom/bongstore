import React, { useState } from 'react';
import { Heart, Eye, ShoppingBag, Sparkles, Check } from 'lucide-react';
import { Product, ProductColor, ProductSize } from '../types';
import { formatVND } from '../utils/formatters';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, color: ProductColor, size: ProductSize) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
}) => {
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [showQuickSize, setShowQuickSize] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const currentColor = product.colors[selectedColorIndex] || product.colors[0];

  const handleQuickAddSize = (size: ProductSize, e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, currentColor, size);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
      setShowQuickSize(false);
    }, 1200);
  };

  // Determine low stock notice
  const totalStock = (Object.values(product.inStockSizes) as number[]).reduce((a, b) => a + b, 0);

  return (
    <div 
      id={`product-card-${product.id}`}
      className="group relative flex flex-col bg-white rounded-xs border border-neutral-100 overflow-hidden transition-all duration-300 hover:shadow-lg hover:border-neutral-200"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setShowQuickSize(false);
      }}
    >
      {/* Media Container */}
      <div 
        className="relative w-full aspect-4/5 bg-neutral-100 overflow-hidden cursor-pointer"
        onClick={() => onQuickView(product)}
      >
        {/* Main Product Image */}
        <img
          src={isHovered && currentColor.secondaryImage ? currentColor.secondaryImage : currentColor.image}
          alt={`${product.name} - ${currentColor.name}`}
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />

        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          {product.isNew && (
            <span className="bg-black text-white text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-xs tracking-wider">
              NEW DROP
            </span>
          )}
          {product.isBestSeller && (
            <span className="bg-amber-400 text-black text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-xs tracking-wider">
              BEST SELLER
            </span>
          )}
          {product.isLimited && (
            <span className="bg-red-600 text-white text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-xs tracking-wider">
              LIMITED
            </span>
          )}
          {product.discountPercent && (
            <span className="bg-rose-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-xs tracking-tight">
              -{product.discountPercent}%
            </span>
          )}
        </div>

        {/* Wishlist button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full backdrop-blur-md transition-all z-10 cursor-pointer ${
            isWishlisted
              ? 'bg-red-500 text-white shadow-md scale-110'
              : 'bg-white/80 text-neutral-700 hover:bg-white hover:text-black shadow-xs'
          }`}
          aria-label="Yêu thích"
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Action Toolbar on Hover */}
        <div className="absolute bottom-2.5 inset-x-2.5 flex gap-2 z-10 transition-all duration-300 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100">
          {/* Quick View Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="flex-1 bg-white/95 hover:bg-white text-neutral-900 text-xs font-bold py-2.5 px-3 rounded-xs shadow-md backdrop-blur-sm flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Xem Nhanh</span>
          </button>

          {/* Quick Add trigger */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowQuickSize(!showQuickSize);
            }}
            className="bg-neutral-900 hover:bg-black text-white p-2.5 rounded-xs shadow-md flex items-center justify-center transition-colors cursor-pointer"
            title="Chọn size mua nhanh"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Size Flyout Overlay */}
        {showQuickSize && (
          <div 
            className="absolute inset-x-0 bottom-0 bg-white/98 backdrop-blur-md p-3 border-t border-neutral-200 z-20 animate-in slide-in-from-bottom-2 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-neutral-800 uppercase tracking-wider">Chọn Size:</span>
              <span className="text-[10px] text-neutral-500 font-medium">{currentColor.name}</span>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {product.sizes.map((size) => {
                const stock = product.inStockSizes[size] || 0;
                const isAvailable = stock > 0;
                return (
                  <button
                    key={size}
                    disabled={!isAvailable}
                    onClick={(e) => handleQuickAddSize(size, e)}
                    className={`py-1.5 text-xs font-bold rounded-xs border transition-all ${
                      isAvailable
                        ? 'border-neutral-300 hover:border-black hover:bg-black hover:text-white text-neutral-900 cursor-pointer'
                        : 'border-neutral-200 bg-neutral-100 text-neutral-400 line-through cursor-not-allowed'
                    }`}
                  >
                    {size}
                  </button>
                );
              })}
            </div>
            {addedAnimation && (
              <div className="mt-2 text-center text-xs font-bold text-emerald-600 flex items-center justify-center gap-1">
                <Check className="w-3.5 h-3.5" /> Đã thêm vào giỏ hàng!
              </div>
            )}
          </div>
        )}
      </div>

      {/* Product Information */}
      <div className="p-3.5 flex flex-col flex-1">
        {/* Color Swatches */}
        <div className="flex items-center gap-1.5 mb-2">
          {product.colors.map((color, idx) => (
            <button
              key={color.name}
              onClick={() => setSelectedColorIndex(idx)}
              className={`w-4 h-4 rounded-full border transition-all cursor-pointer ${
                selectedColorIndex === idx 
                  ? 'ring-2 ring-black ring-offset-1 scale-110' 
                  : 'border-neutral-300 hover:scale-110 opacity-70 hover:opacity-100'
              }`}
              style={{ backgroundColor: color.hex }}
              title={color.name}
              aria-label={`Màu ${color.name}`}
            />
          ))}
          <span className="text-[10px] text-neutral-400 ml-1 font-medium truncate">
            {product.colors.length} màu
          </span>
        </div>

        {/* Product Title */}
        <h3 
          onClick={() => onQuickView(product)}
          className="text-xs sm:text-[13px] font-bold text-neutral-900 line-clamp-2 hover:underline cursor-pointer mb-1.5 flex-1"
        >
          {product.name}
        </h3>

        {/* Fit / Fabric note */}
        <div className="text-[11px] text-neutral-400 line-clamp-1 mb-2 font-medium">
          {product.gsm} • {product.fit}
        </div>

        {/* Price & Rating */}
        <div className="flex items-baseline justify-between pt-1 border-t border-neutral-100 mt-auto">
          <div className="flex items-baseline gap-2">
            <span className="text-sm sm:text-base font-extrabold text-neutral-900 font-mono-num">
              {formatVND(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-neutral-400 line-through font-mono-num">
                {formatVND(product.originalPrice)}
              </span>
            )}
          </div>

          <div className="text-[10px] text-amber-500 font-bold flex items-center gap-0.5">
            <span>★</span>
            <span className="text-neutral-700">{product.rating}</span>
            <span className="text-neutral-400">({product.reviewCount})</span>
          </div>
        </div>

        {/* Low stock tag */}
        {totalStock < 25 && totalStock > 0 && (
          <div className="mt-2 text-[10px] font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-xs w-fit">
            Sắp hết hàng ({totalStock} chiếc)
          </div>
        )}
      </div>
    </div>
  );
};
