import React, { useState } from 'react';
import { X, Ruler, CheckCircle2, Sparkles, RefreshCw } from 'lucide-react';
import { ProductSize } from '../types';
import { calculateSmartSize } from '../utils/formatters';

interface SmartSizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSize?: (size: ProductSize) => void;
}

export const SmartSizeGuideModal: React.FC<SmartSizeGuideModalProps> = ({
  isOpen,
  onClose,
  onSelectSize,
}) => {
  const [height, setHeight] = useState<number>(170);
  const [weight, setWeight] = useState<number>(65);
  const [fitPreference, setFitPreference] = useState<'standard' | 'oversize' | 'boxy'>('oversize');
  const [activeTab, setActiveTab] = useState<'calculator' | 'matrix'>('calculator');

  if (!isOpen) return null;

  const result = calculateSmartSize({
    heightCm: height,
    weightKg: weight,
    fitPreference,
  });

  const handleApplySize = () => {
    if (onSelectSize) {
      onSelectSize(result.recommendedSize);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-amber-400 text-black flex items-center justify-center font-bold shadow-xs">
              <Ruler className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider">
                BẢNG SIZE & GỢI Ý THÔNG MINH
              </h3>
              <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase">BÔNG STORE • WEAR YOUR STORY</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switchers */}
        <div className="flex border-b border-neutral-200 bg-neutral-50 text-xs font-bold">
          <button
            onClick={() => setActiveTab('calculator')}
            className={`flex-1 py-3 text-center flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'calculator'
                ? 'bg-white text-black border-b-2 border-black'
                : 'text-neutral-500 hover:text-black'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Gợi Ý Size Tự Động</span>
          </button>
          <button
            onClick={() => setActiveTab('matrix')}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              activeTab === 'matrix'
                ? 'bg-white text-black border-b-2 border-black'
                : 'text-neutral-500 hover:text-black'
            }`}
          >
            Bảng Thông Số Chuẩn
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 max-h-[75vh] overflow-y-auto">
          {activeTab === 'calculator' ? (
            <div className="space-y-6">
              
              {/* Sliders */}
              <div className="space-y-4 bg-neutral-50 p-4 rounded-xs border border-neutral-200">
                {/* Height Slider */}
                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="text-neutral-700">Chiều cao của bạn:</span>
                    <span className="text-black font-mono text-sm">{height} cm</span>
                  </div>
                  <input
                    type="range"
                    min="150"
                    max="195"
                    value={height}
                    onChange={(e) => setHeight(Number(e.target.value))}
                    className="w-full h-1.5 bg-neutral-300 rounded-lg appearance-none cursor-pointer accent-black"
                  />
                  <div className="flex justify-between text-[10px] text-neutral-400 mt-1">
                    <span>150cm</span>
                    <span>170cm</span>
                    <span>195cm</span>
                  </div>
                </div>

                {/* Weight Slider */}
                <div>
                  <div className="flex justify-between text-xs font-bold mb-1">
                    <span className="text-neutral-700">Cân nặng của bạn:</span>
                    <span className="text-black font-mono text-sm">{weight} kg</span>
                  </div>
                  <input
                    type="range"
                    min="40"
                    max="105"
                    value={weight}
                    onChange={(e) => setWeight(Number(e.target.value))}
                    className="w-full h-1.5 bg-neutral-300 rounded-lg appearance-none cursor-pointer accent-black"
                  />
                  <div className="flex justify-between text-[10px] text-neutral-400 mt-1">
                    <span>40kg</span>
                    <span>70kg</span>
                    <span>105kg</span>
                  </div>
                </div>

                {/* Fit preference */}
                <div>
                  <label className="text-xs font-bold text-neutral-700 block mb-2">
                    Phong cách mặc bạn mong muốn:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'standard', label: 'Vừa Vặn', desc: 'Chuẩn dáng' },
                      { id: 'boxy', label: 'Boxy Fit', desc: 'Rộng ngang lưng lửng' },
                      { id: 'oversize', label: 'Oversize', desc: 'Rộng thoải mái' },
                    ].map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setFitPreference(item.id as any)}
                        className={`p-2 rounded-xs border text-left transition-all ${
                          fitPreference === item.id
                            ? 'border-black bg-black text-white'
                            : 'border-neutral-200 bg-white text-neutral-800 hover:border-neutral-400'
                        }`}
                      >
                        <div className="text-xs font-bold">{item.label}</div>
                        <div className={`text-[10px] ${fitPreference === item.id ? 'text-neutral-300' : 'text-neutral-400'}`}>
                          {item.desc}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recommendation Result Card */}
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xs">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-12 h-12 rounded-full bg-neutral-900 text-white flex items-center justify-center font-black text-xl font-heading shadow-md">
                    {result.recommendedSize}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 uppercase">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      <span>Size phù hợp nhất: SIZE {result.recommendedSize}</span>
                    </div>
                    <p className="text-[11px] text-amber-800 font-medium mt-0.5">
                      Độ chính xác {result.confidence}% từ hơn 5.000 khách hàng Bông Store
                    </p>
                  </div>
                </div>

                <p className="text-xs text-neutral-700 leading-relaxed bg-white/70 p-2.5 rounded-xs border border-amber-100 mb-3">
                  {result.reason}
                </p>

                {/* Measurements spec */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="bg-white p-2 rounded-xs border border-amber-100">
                    <span className="text-[10px] text-neutral-400 block uppercase">Rộng Ngực</span>
                    <span className="font-bold text-neutral-800 font-mono">{result.measurements.chest}</span>
                  </div>
                  <div className="bg-white p-2 rounded-xs border border-amber-100">
                    <span className="text-[10px] text-neutral-400 block uppercase">Dài Áo</span>
                    <span className="font-bold text-neutral-800 font-mono">{result.measurements.length}</span>
                  </div>
                  <div className="bg-white p-2 rounded-xs border border-amber-100">
                    <span className="text-[10px] text-neutral-400 block uppercase">Rộng Vai</span>
                    <span className="font-bold text-neutral-800 font-mono">{result.measurements.shoulder}</span>
                  </div>
                </div>
              </div>

              {onSelectSize && (
                <button
                  onClick={handleApplySize}
                  className="w-full py-3 bg-black hover:bg-neutral-800 text-white text-xs font-extrabold uppercase rounded-xs transition-colors shadow-md flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  <span>Chọn Size {result.recommendedSize} Cho Sản Phẩm Này</span>
                </button>
              )}
            </div>
          ) : (
            /* Standard Matrix Table */
            <div className="space-y-4">
              <p className="text-xs text-neutral-500">
                Bảng thông số kích thước chuẩn áp dụng cho các sản phẩm Áo thun, Hoodie và Áo khoác Bông Store (Đơn vị: cm / kg):
              </p>
              
              <div className="overflow-x-auto border border-neutral-200 rounded-xs">
                <table className="w-full text-xs text-left">
                  <thead className="bg-neutral-100 text-neutral-700 font-bold uppercase text-[11px] border-b border-neutral-200">
                    <tr>
                      <th className="p-2.5">Size</th>
                      <th className="p-2.5">Chiều cao</th>
                      <th className="p-2.5">Cân nặng</th>
                      <th className="p-2.5">Dài áo</th>
                      <th className="p-2.5">Rộng ngực</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-200 font-medium">
                    <tr className="hover:bg-neutral-50">
                      <td className="p-2.5 font-bold text-black">Size S</td>
                      <td className="p-2.5">&lt; 165 cm</td>
                      <td className="p-2.5">&lt; 55 kg</td>
                      <td className="p-2.5">68 cm</td>
                      <td className="p-2.5">106 cm</td>
                    </tr>
                    <tr className="hover:bg-neutral-50">
                      <td className="p-2.5 font-bold text-black">Size M</td>
                      <td className="p-2.5">165 - 175 cm</td>
                      <td className="p-2.5">55 - 65 kg</td>
                      <td className="p-2.5">71 cm</td>
                      <td className="p-2.5">112 cm</td>
                    </tr>
                    <tr className="hover:bg-neutral-50">
                      <td className="p-2.5 font-bold text-black">Size L</td>
                      <td className="p-2.5">175 - 182 cm</td>
                      <td className="p-2.5">65 - 78 kg</td>
                      <td className="p-2.5">74 cm</td>
                      <td className="p-2.5">118 cm</td>
                    </tr>
                    <tr className="hover:bg-neutral-50">
                      <td className="p-2.5 font-bold text-black">Size XL</td>
                      <td className="p-2.5">180 - 190 cm</td>
                      <td className="p-2.5">78 - 90 kg</td>
                      <td className="p-2.5">77 cm</td>
                      <td className="p-2.5">124 cm</td>
                    </tr>
                    <tr className="hover:bg-neutral-50">
                      <td className="p-2.5 font-bold text-black">Size XXL</td>
                      <td className="p-2.5">&gt; 185 cm</td>
                      <td className="p-2.5">&gt; 90 kg</td>
                      <td className="p-2.5">79 cm</td>
                      <td className="p-2.5">130 cm</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="p-3 bg-neutral-100 rounded-xs text-[11px] text-neutral-600 space-y-1">
                <p>• <strong>Ghi chú:</strong> Tất cả sản phẩm Bông Store đã được xử lý giặt hấp chống co rút (Preshrunk).</p>
                <p>• Nếu bạn phân vân giữa 2 size, hãy chọn <strong>size lớn hơn</strong> để có form dáng streetwear thoải mái nhất.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
