import React from 'react';
import { ProductCategory, CategoryShowcaseItem } from '../types';
import { DEFAULT_CATEGORIES } from '../data/mockData';
import { ArrowUpRight } from 'lucide-react';

interface CategoryShowcaseProps {
  categories?: CategoryShowcaseItem[];
  onSelectCategory: (cat: ProductCategory) => void;
  onNavigateSection: (sectionId: string) => void;
}

export const CategoryShowcase: React.FC<CategoryShowcaseProps> = ({
  categories = DEFAULT_CATEGORIES,
  onSelectCategory,
  onNavigateSection,
}) => {
  const activeCategories = categories && categories.length > 0 ? categories : DEFAULT_CATEGORIES;


  return (
    <section id="category-showcase" className="py-12 sm:py-16 bg-[#FAFAFA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-neutral-200">
          <div>
            <span className="text-xs font-bold tracking-widest text-neutral-400 uppercase">
              DANH MỤC NỔI BẬT
            </span>
            <h2 className="text-2xl sm:text-3xl font-black font-heading tracking-tight uppercase text-neutral-900 mt-1">
              KHÁM PHÁ THEO PHONG CÁCH
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-neutral-500 max-w-md mt-2 md:mt-0">
            Từ những chiếc áo thun boxy tối giản đến áo khoác varsity len dạ cao cấp, hoàn thiện tủ đồ streetwear của bạn.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {activeCategories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => {
                onSelectCategory(cat.category);
                onNavigateSection('products-section');
              }}
              className="group relative overflow-hidden rounded-xs bg-neutral-900 cursor-pointer aspect-3/4 flex flex-col justify-end p-4 transition-all duration-300 hover:shadow-xl"
            >
              {/* Background Image with zoom */}
              <img
                src={cat.image}
                alt={cat.name}
                className="absolute inset-0 w-full h-full object-cover object-center brightness-[0.75] transition-transform duration-700 ease-out group-hover:scale-110 group-hover:brightness-[0.65]"
              />

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />

              {/* Count Tag */}
              <div className="absolute top-3 right-3 bg-white/20 backdrop-blur-md px-2 py-0.5 rounded-xs text-[10px] font-bold text-white tracking-wider">
                {cat.count}
              </div>

              {/* Text Info */}
              <div className="relative z-10">
                <p className="text-[10px] text-neutral-300 font-medium line-clamp-1 mb-0.5">
                  {cat.desc}
                </p>
                <div className="flex items-center justify-between">
                  <h3 className="text-sm sm:text-base font-extrabold text-white font-heading tracking-tight">
                    {cat.name}
                  </h3>
                  <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-white group-hover:bg-amber-400 group-hover:text-black transition-all">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
