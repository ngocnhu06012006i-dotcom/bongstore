import React, { useState } from 'react';
import { X, Award, Gift, Sparkles, Check, Copy, Tag, Zap } from 'lucide-react';
import { VOUCHERS } from '../data/mockData';
import { Voucher } from '../types';
import { formatVND } from '../utils/formatters';

interface VipClubModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyVoucher: (voucher: Voucher) => void;
}

export const VipClubModal: React.FC<VipClubModalProps> = ({
  isOpen,
  onClose,
  onApplyVoucher,
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (v: Voucher) => {
    navigator.clipboard.writeText(v.code);
    setCopiedCode(v.code);
    onApplyVoucher(v);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const tiers = [
    { name: 'BÔNG BRONZE', spend: '0đ', discount: '5% sinh nhật', badge: 'Mặc định' },
    { name: 'BÔNG SILVER', spend: '2.000.000đ', discount: 'Giảm 5% mọi đơn + Freeship', badge: 'Hạng Bạc' },
    { name: 'BÔNG GOLD', spend: '5.000.000đ', discount: 'Giảm 10% mọi đơn + Early Drop', badge: 'Hạng Vàng' },
    { name: 'BÔNG DIAMOND', spend: '10.000.000đ', discount: 'Giảm 15% trọn đời + Hộp Quà VIP', badge: 'Hạng Kim Cương' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-2xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-amber-400 text-black flex items-center justify-center font-black shadow-xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider flex items-center gap-2">
                <span>BÔNG MEMBERSHIP VIP CLUB</span>
                <span className="text-[9px] bg-amber-400 text-black px-1.5 py-0.5 rounded-xs font-black">2026</span>
              </h2>
              <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase">TÍCH ĐIỂM ĐỔI QUÀ • ĐẶC QUYỀN KHÁCH HÀNG THÂN THIẾT</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Member Card Simulation */}
          <div className="relative rounded-xs p-5 text-white overflow-hidden shadow-xl bg-gradient-to-br from-neutral-900 via-neutral-800 to-black border border-neutral-700">
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className="text-[10px] tracking-widest text-amber-400 uppercase font-mono font-bold">VIP MEMBER CARD</span>
                <h3 className="text-lg font-black font-heading uppercase tracking-tight">BÔNG STORE VIP PASS</h3>
              </div>
              <Sparkles className="w-6 h-6 text-amber-400" />
            </div>

            <div className="flex justify-between items-end">
              <div>
                <div className="text-[10px] text-neutral-400 uppercase">Mã thẻ thành viên:</div>
                <div className="text-sm font-mono font-bold tracking-widest text-neutral-200">BS-MEMBER-2026</div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-neutral-400 uppercase block">Điểm tích lũy:</span>
                <span className="text-base font-mono font-black text-amber-400">250 Điểm</span>
              </div>
            </div>
          </div>

          {/* Vouchers Section */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 mb-3 flex items-center gap-1.5">
              <Tag className="w-4 h-4 text-amber-600" />
              <span>Mã Giảm Giá Đang Có Thể Sử Dụng</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {VOUCHERS.map((v) => (
                <div
                  key={v.code}
                  className="p-3.5 bg-neutral-50 rounded-xs border border-neutral-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xs font-black font-mono text-neutral-900 bg-white px-2 py-0.5 rounded-xs border border-neutral-300">
                        {v.code}
                      </span>
                      <span className="text-[9px] font-bold bg-amber-400 text-black px-1.5 py-0.2 rounded-xs">
                        {v.badge}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 font-medium mb-3">
                      {v.description}
                    </p>
                  </div>

                  <button
                    onClick={() => handleCopy(v)}
                    className="w-full py-1.5 bg-black hover:bg-neutral-800 text-white text-xs font-bold rounded-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedCode === v.code ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Đã lưu mã & áp dụng!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Lấy mã & Áp dụng</span>
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Member Tiers List */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 mb-3 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-neutral-700" />
              <span>Các Cấp Bậc Thành Viên & Quyền Lợi</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {tiers.map((t, idx) => (
                <div key={idx} className="p-3 bg-neutral-50 border border-neutral-200 rounded-xs text-xs">
                  <div className="flex justify-between font-bold text-neutral-900 mb-1">
                    <span>{t.name}</span>
                    <span className="text-neutral-500 font-mono text-[11px]">{t.spend}</span>
                  </div>
                  <p className="text-neutral-600 text-[11px]">{t.discount}</p>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
