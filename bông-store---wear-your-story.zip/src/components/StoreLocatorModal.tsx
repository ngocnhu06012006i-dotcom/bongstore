import React, { useState } from 'react';
import { X, MapPin, Phone, Clock, Navigation, CheckCircle2, Sparkles } from 'lucide-react';
import { STORE_BRANCHES } from '../data/mockData';
import { StoreBranch } from '../types';

interface StoreLocatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StoreLocatorModal: React.FC<StoreLocatorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [activeBranch, setActiveBranch] = useState<StoreBranch>(STORE_BRANCHES[0]);

  if (!isOpen) return null;

  const filteredBranches = selectedCity === 'all' 
    ? STORE_BRANCHES 
    : STORE_BRANCHES.filter(b => b.city === selectedCity);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-4xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-amber-400">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider">
                HỆ THỐNG CỬA HÀNG BÔNG STORE
              </h2>
              <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase">5 CỬA HÀNG TRÊN TOÀN QUỐC</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* City Filter Tabs */}
        <div className="flex border-b border-neutral-200 bg-neutral-50 px-4 py-2 gap-2 text-xs font-bold">
          {['all', 'TP. Hồ Chí Minh', 'Hà Nội', 'Đà Nẵng'].map((c) => (
            <button
              key={c}
              onClick={() => setSelectedCity(c)}
              className={`px-3 py-1.5 rounded-xs transition-all cursor-pointer ${
                selectedCity === c
                  ? 'bg-black text-white'
                  : 'bg-white text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
              }`}
            >
              {c === 'all' ? 'Tất cả (5)' : c}
            </button>
          ))}
        </div>

        {/* Body Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-0 flex-1 overflow-y-auto">
          
          {/* Left Branch List (5 cols) */}
          <div className="md:col-span-5 border-r border-neutral-200 divide-y divide-neutral-100 overflow-y-auto max-h-[60vh] md:max-h-none">
            {filteredBranches.map((branch) => (
              <div
                key={branch.id}
                onClick={() => setActiveBranch(branch)}
                className={`p-4 cursor-pointer transition-colors ${
                  activeBranch.id === branch.id
                    ? 'bg-amber-50/70 border-l-4 border-amber-400'
                    : 'hover:bg-neutral-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-xs font-black uppercase text-neutral-900">
                    {branch.name}
                  </h4>
                  {branch.isFlagship && (
                    <span className="bg-amber-400 text-black text-[9px] font-extrabold px-1.5 py-0.5 rounded-xs">
                      FLAGSHIP
                    </span>
                  )}
                </div>
                <p className="text-xs text-neutral-600 mb-2 flex items-start gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                  <span>{branch.address}</span>
                </p>
                <div className="flex items-center gap-3 text-[11px] text-neutral-500">
                  <span className="flex items-center gap-1">
                    <Phone className="w-3 h-3" />
                    <span>{branch.phone}</span>
                  </span>
                  <span>•</span>
                  <span>{branch.city}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Right Branch Preview & Directions (7 cols) */}
          <div className="md:col-span-7 p-6 flex flex-col justify-between bg-neutral-50">
            <div>
              <div className="aspect-16/9 rounded-xs overflow-hidden bg-neutral-200 mb-4 shadow-sm relative">
                <img
                  src={activeBranch.image}
                  alt={activeBranch.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-xs text-white px-2.5 py-1 rounded-xs text-xs font-bold">
                  {activeBranch.city}
                </div>
              </div>

              <h3 className="text-lg font-black uppercase font-heading text-neutral-900 mb-2">
                {activeBranch.name}
              </h3>

              <div className="space-y-2.5 text-xs text-neutral-700">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-neutral-900 shrink-0 mt-0.5" />
                  <div>
                    <strong>Địa chỉ:</strong> {activeBranch.address}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-neutral-900 shrink-0" />
                  <div>
                    <strong>Giờ mở cửa:</strong> {activeBranch.hours}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-neutral-900 shrink-0" />
                  <div>
                    <strong>Hotline cửa hàng:</strong> <span className="font-mono font-bold">{activeBranch.phone}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-6 mt-6 border-t border-neutral-200 flex gap-3">
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(activeBranch.googleMapQuery)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3 bg-black hover:bg-neutral-800 text-white text-xs font-extrabold uppercase rounded-xs flex items-center justify-center gap-2 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5 text-amber-400" />
                <span>Chỉ Đường Trên Google Maps</span>
              </a>

              <a
                href={`tel:${activeBranch.phone.replace(/[^0-9]/g, '')}`}
                className="px-4 py-3 bg-white border border-neutral-300 hover:border-black text-black text-xs font-bold rounded-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Gọi Ngay</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
