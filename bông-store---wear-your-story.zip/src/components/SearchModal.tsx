import React, { useState, useEffect, useRef } from 'react';
import { X, Search, ArrowRight, Sparkles, TrendingUp } from 'lucide-react';
import { Product } from '../types';
import { formatVND } from '../utils/formatters';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onSearchSubmit: (query: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct,
  onSearchSubmit,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const popularKeywords = [
    'Áo thun Boxy',
    'Hoodie Zip',
    'Quần Parachute',
    'Varsity Jacket',
    'Wear Your Story',
    'Polo Dệt Kim',
    'Túi Crossbody',
  ];

  const matchedProducts = query.trim()
    ? products.filter((p) => {
        const q = query.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.code.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.material.toLowerCase().includes(q)
        );
      })
    : products.slice(0, 4);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearchSubmit(query.trim());
      onClose();
    }
  };

  const handleKeywordClick = (kw: string) => {
    setQuery(kw);
    onSearchSubmit(kw);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-3xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 mt-6 sm:mt-12 animate-in fade-in slide-in-from-top-4 duration-200 flex flex-col max-h-[85vh]">
        
        {/* Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 bg-white flex items-center gap-3">
          <Search className="w-5 h-5 text-neutral-400 shrink-0" />
          <form onSubmit={handleSubmit} className="flex-1">
            <input
              ref={inputRef}
              type="text"
              placeholder="Tìm kiếm áo thun, hoodie, quần, phụ kiện Bông Store..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full text-sm sm:text-base font-semibold text-neutral-900 focus:outline-hidden placeholder:text-neutral-400"
            />
          </form>
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-neutral-400 hover:text-black"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-bold text-neutral-500 hover:text-black uppercase px-2 py-1"
          >
            Đóng
          </button>
        </div>

        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Trending Searches */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5">
              <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
              <span>Từ khóa tìm kiếm phổ biến</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {popularKeywords.map((kw) => (
                <button
                  key={kw}
                  onClick={() => handleKeywordClick(kw)}
                  className="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-900 hover:text-white rounded-xs text-xs font-medium text-neutral-700 transition-colors cursor-pointer"
                >
                  {kw}
                </button>
              ))}
            </div>
          </div>

          {/* Results preview */}
          <div>
            <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider text-neutral-400 mb-3 pb-2 border-b border-neutral-100">
              <span>{query.trim() ? `Kết quả tìm kiếm (${matchedProducts.length})` : 'Gợi ý sản phẩm nổi bật'}</span>
              {query.trim() && matchedProducts.length > 0 && (
                <button
                  onClick={handleSubmit}
                  className="text-black hover:underline flex items-center gap-1 text-[11px]"
                >
                  <span>Xem tất cả kết quả</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </div>

            {matchedProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {matchedProducts.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      onSelectProduct(p);
                      onClose();
                    }}
                    className="p-2.5 bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 rounded-xs flex gap-3 cursor-pointer transition-colors"
                  >
                    <img
                      src={p.colors[0]?.image}
                      alt={p.name}
                      className="w-16 h-20 object-cover rounded-xs border border-neutral-200 shrink-0"
                    />
                    <div className="flex flex-col justify-between flex-1 min-w-0">
                      <div>
                        <span className="text-[9px] font-bold text-amber-700 uppercase">{p.code}</span>
                        <h4 className="text-xs font-bold text-neutral-900 truncate mt-0.5">{p.name}</h4>
                        <p className="text-[10px] text-neutral-500">{p.fit}</p>
                      </div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-xs font-black font-mono-num text-neutral-900">{formatVND(p.price)}</span>
                        {p.originalPrice && (
                          <span className="text-[10px] text-neutral-400 line-through font-mono-num">{formatVND(p.originalPrice)}</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-neutral-400 text-xs">
                Không tìm thấy sản phẩm nào phù hợp với từ khóa "{query}".
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
