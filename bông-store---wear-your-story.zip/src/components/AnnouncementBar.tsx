import React, { useState, useEffect } from 'react';
import { Truck, Tag, Phone, MapPin, Sparkles } from 'lucide-react';

interface AnnouncementBarProps {
  announcementTexts?: string[];
  hotline?: string;
  onOpenStoreLocator: () => void;
  onOpenOrderTracker: () => void;
  onOpenVouchers: () => void;
  onOpenAdmin?: () => void;
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = ({
  announcementTexts,
  hotline = '1900 6868',
  onOpenStoreLocator,
  onOpenOrderTracker,
  onOpenVouchers,
  onOpenAdmin,
}) => {
  const defaultTexts = [
    'MIỄN PHÍ VẬN CHUYỂN toàn quốc cho đơn hàng từ 499.000₫',
    'Nhập mã "BONGSTORE10" giảm 10% cho đơn hàng đầu tiên',
    'BỘ SƯU TẬP MỚI 2026 "WEAR YOUR STORY" ĐÃ CHÍNH THỨC RA MẮT!'
  ];

  const texts = announcementTexts && announcementTexts.length > 0 ? announcementTexts : defaultTexts;
  const icons = [Truck, Tag, Sparkles];

  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (currentIndex >= texts.length) {
      setCurrentIndex(0);
    }
  }, [texts.length, currentIndex]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % texts.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [texts.length]);

  const CurrentIcon = icons[currentIndex % icons.length] || Sparkles;

  return (
    <div id="announcement-bar" className="bg-[#111111] text-white text-xs py-2 px-4 border-b border-neutral-800">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
        {/* Left utility info */}
        <div className="hidden lg:flex items-center space-x-5 text-neutral-400">
          <button 
            onClick={onOpenStoreLocator}
            className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5 text-neutral-400" />
            <span>Hệ thống 5 cửa hàng</span>
          </button>
          <button 
            onClick={onOpenOrderTracker}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Tra cứu đơn hàng
          </button>
        </div>

        {/* Center Rotating announcement */}
        <div className="flex items-center justify-center gap-2 text-center font-medium tracking-wide">
          <CurrentIcon className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
          <span className="truncate max-w-[320px] sm:max-w-md md:max-w-lg">
            {texts[currentIndex] || texts[0]}
          </span>
          <button 
            onClick={onOpenVouchers} 
            className="hidden sm:inline-block ml-2 text-[10px] uppercase font-bold tracking-wider bg-white text-black px-1.5 py-0.5 rounded-xs hover:bg-amber-400 transition-colors"
          >
            Lấy mã
          </button>
        </div>

        {/* Right info */}
        <div className="hidden lg:flex items-center space-x-4 text-neutral-400">
          <div className="flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5" />
            <span className="font-mono text-[11px] text-neutral-300">Hotline: {hotline}</span>
          </div>
          <span className="text-neutral-600">|</span>
          <span className="text-neutral-300 font-semibold text-[11px]">VIỆT NAM (VND)</span>
        </div>
      </div>
    </div>
  );
};

