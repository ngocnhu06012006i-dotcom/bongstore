import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Layers,
  Image as ImageIcon,
  Plus,
  Trash2,
  Edit3,
  Check,
  Save,
  RotateCcw,
  Upload,
  UploadCloud,
  Laptop,
  Smartphone,
  FolderUp,
  Sliders,
  Type,
  Megaphone,
  BookOpen,
  Grid,
  Camera,
  ArrowUp,
  ArrowDown,
  Eye,
  ExternalLink,
  Store,
  Phone,
  Mail,
  MapPin,
  Clock,
  Truck,
  CheckCircle2,
  X,
  CreditCard,
  QrCode,
  Building2,
  Copy,
  ShieldCheck,
  RefreshCw,
  Landmark
} from 'lucide-react';
import {
  SiteSettings,
  HeroSlide,
  CategoryShowcaseItem,
  LookbookItem,
  StoryContent,
  CollectionSlug,
  ProductCategory
} from '../types';
import { processDeviceImage, PRESET_IMAGES } from './AdminPortal';

export const VIETNAMESE_BANKS = [
  { code: 'MB', name: 'MB Bank (Ngân hàng TMCP Quân Đội)', bin: '970422', shortName: 'MB' },
  { code: 'VCB', name: 'Vietcombank (Ngoại Thương Việt Nam)', bin: '970436', shortName: 'Vietcombank' },
  { code: 'TCB', name: 'Techcombank (Kỹ Thương Việt Nam)', bin: '970407', shortName: 'Techcombank' },
  { code: 'ACB', name: 'ACB (Ngân hàng TMCP Á Châu)', bin: '970416', shortName: 'ACB' },
  { code: 'VPB', name: 'VPBank (Việt Nam Thịnh Vượng)', bin: '970432', shortName: 'VPBank' },
  { code: 'BIDV', name: 'BIDV (Đầu Tư và Phát Triển)', bin: '970418', shortName: 'BIDV' },
  { code: 'ICB', name: 'VietinBank (Công Thương Việt Nam)', bin: '970415', shortName: 'VietinBank' },
  { code: 'TPB', name: 'TPBank (Tiên Phong)', bin: '970423', shortName: 'TPBank' },
  { code: 'STB', name: 'Sacombank (Sài Gòn Thương Tín)', bin: '970403', shortName: 'Sacombank' },
  { code: 'HDB', name: 'HDBank (Phát Triển TP.HCM)', bin: '970437', shortName: 'HDBank' },
  { code: 'VIB', name: 'VIB (Quốc Tế Việt Nam)', bin: '970441', shortName: 'VIB' },
  { code: 'OCB', name: 'OCB (Phương Đông)', bin: '970448', shortName: 'OCB' },
  { code: 'SHB', name: 'SHB (Sài Gòn - Hà Nội)', bin: '970443', shortName: 'SHB' },
  { code: 'MSB', name: 'MSB (Hàng Hải Việt Nam)', bin: '970426', shortName: 'MSB' },
  { code: 'VBA', name: 'Agribank (Nông Nghiệp & PTNT)', bin: '970405', shortName: 'Agribank' },
  { code: 'LPB', name: 'LPBank (Lộc Phát Việt Nam)', bin: '970449', shortName: 'LPBank' },
  { code: 'SEAB', name: 'SeABank (Đông Nam Á)', bin: '970440', shortName: 'SeABank' },
  { code: 'NAB', name: 'Nam A Bank (Nam Á)', bin: '970428', shortName: 'Nam A Bank' },
  { code: 'BAB', name: 'Bac A Bank (Bắc Á)', bin: '970409', shortName: 'Bac A Bank' },
  { code: 'VIETBANK', name: 'VietBank (Việt Nam Thương Tín)', bin: '970433', shortName: 'VietBank' },
  { code: 'OTHER', name: 'Ngân hàng khác (Tùy chỉnh)', bin: '', shortName: 'Khác' },
];

export const generateVietQrUrl = (
  bankName: string,
  accountNumber: string,
  accountName: string,
  amount: number = 0,
  memo: string = 'BONGSTORE'
) => {
  if (!accountNumber) return '';
  const cleanAcc = accountNumber.replace(/\s+/g, '');
  const matched = VIETNAMESE_BANKS.find(
    (b) =>
      b.code !== 'OTHER' &&
      (bankName.toLowerCase().includes(b.shortName.toLowerCase()) ||
        bankName.toLowerCase().includes(b.code.toLowerCase()) ||
        b.name.toLowerCase().includes(bankName.toLowerCase()))
  );
  const bankCode = matched ? matched.code : 'MB';
  const encodedName = encodeURIComponent((accountName || '').toUpperCase());
  const encodedMemo = encodeURIComponent(memo);
  return `https://img.vietqr.io/image/${bankCode}-${cleanAcc}-compact2.png?amount=${amount}&addInfo=${encodedMemo}&accountName=${encodedName}`;
};

export const BANNER_PRESETS = [
  { label: 'Saigon Night Streetwear', url: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1800&auto=format&fit=crop' },
  { label: 'Urban Concrete Vibe', url: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1800&auto=format&fit=crop' },
  { label: 'Signature Bloom Outfit', url: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=1800&auto=format&fit=crop' },
  { label: 'Monochrome Studio Model', url: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1800&auto=format&fit=crop' },
  { label: 'Underground Street Style', url: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?q=80&w=1800&auto=format&fit=crop' },
  { label: 'Minimalist Clean Neutral', url: 'https://images.unsplash.com/photo-1516257984-b1b4d707412e?q=80&w=1800&auto=format&fit=crop' },
];

export const CATEGORY_IMAGE_PRESETS = [
  { label: 'Tee / Áo thun Boxy', url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=800&auto=format&fit=crop' },
  { label: 'Hoodie French Terry', url: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=800&auto=format&fit=crop' },
  { label: 'Jacket & Outerwear', url: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=800&auto=format&fit=crop' },
  { label: 'Pants / Denim & Cargo', url: 'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?q=80&w=800&auto=format&fit=crop' },
  { label: 'Accessories / Phụ kiện', url: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=800&auto=format&fit=crop' },
];

interface AdminSiteSettingsManagerProps {
  siteSettings: SiteSettings;
  onSaveSiteSettings: (settings: SiteSettings) => void;
  heroSlides: HeroSlide[];
  onSaveHeroSlides: (slides: HeroSlide[]) => void;
  categoryShowcase: CategoryShowcaseItem[];
  onSaveCategoryShowcase: (categories: CategoryShowcaseItem[]) => void;
  lookbooks: LookbookItem[];
  onSaveLookbooks: (lookbooks: LookbookItem[]) => void;
  showToast: (msg: string) => void;
}

export const AdminSiteSettingsManager: React.FC<AdminSiteSettingsManagerProps> = ({
  siteSettings,
  onSaveSiteSettings,
  heroSlides,
  onSaveHeroSlides,
  categoryShowcase,
  onSaveCategoryShowcase,
  lookbooks,
  onSaveLookbooks,
  showToast,
}) => {
  const [subTab, setSubTab] = useState<'hero' | 'banking' | 'general' | 'ticker' | 'story' | 'categories' | 'lookbook'>('hero');

  // Local editable copies for smooth form interaction
  const [settingsForm, setSettingsForm] = useState<SiteSettings>(siteSettings);
  const [slidesForm, setSlidesForm] = useState<HeroSlide[]>(heroSlides);
  const [categoriesForm, setCategoriesForm] = useState<CategoryShowcaseItem[]>(categoryShowcase);
  const [lookbooksForm, setLookbooksForm] = useState<LookbookItem[]>(lookbooks);

  // Bank management state
  const [isUploadingBankQr, setIsUploadingBankQr] = useState(false);
  const [copiedBankAcc, setCopiedBankAcc] = useState(false);
  const [copiedBankName, setCopiedBankName] = useState(false);
  const bankQrInputRef = useRef<HTMLInputElement | null>(null);

  // Modal / Editing sub-state
  const [editingSlide, setEditingSlide] = useState<HeroSlide | null>(null);
  const [isNewSlide, setIsNewSlide] = useState(false);
  const [editingCategory, setEditingCategory] = useState<CategoryShowcaseItem | null>(null);
  const [editingLookbook, setEditingLookbook] = useState<LookbookItem | null>(null);

  // Preset picker modal state
  const [presetModal, setPresetModal] = useState<{
    isOpen: boolean;
    title: string;
    presets: { label: string; url: string }[];
    onSelect: (url: string) => void;
  }>({
    isOpen: false,
    title: '',
    presets: [],
    onSelect: () => {},
  });

  // Keep local copies updated if props change from outside
  React.useEffect(() => {
    setSettingsForm(siteSettings);
  }, [siteSettings]);

  React.useEffect(() => {
    setSlidesForm(heroSlides);
  }, [heroSlides]);

  React.useEffect(() => {
    setCategoriesForm(categoryShowcase);
  }, [categoryShowcase]);

  React.useEffect(() => {
    setLookbooksForm(lookbooks);
  }, [lookbooks]);

  // ====================================================
  // HERO SLIDES HANDLERS
  // ====================================================
  const handleSaveHeroSlide = (slide: HeroSlide) => {
    let updated: HeroSlide[];
    if (isNewSlide) {
      updated = [...slidesForm, slide];
      showToast('Đã thêm Banner Hero mới thành công!');
    } else {
      updated = slidesForm.map((s) => (s.id === slide.id ? slide : s));
      showToast('Đã cập nhật Banner Hero!');
    }
    setSlidesForm(updated);
    onSaveHeroSlides(updated);
    setEditingSlide(null);
    setIsNewSlide(false);
  };

  const handleDeleteHeroSlide = (slideId: string | number) => {
    if (slidesForm.length <= 1) {
      alert('Phải giữ lại ít nhất 1 Banner trang chủ!');
      return;
    }
    if (window.confirm('Bạn có chắc chắn muốn xóa Banner này?')) {
      const updated = slidesForm.filter((s) => s.id !== slideId);
      setSlidesForm(updated);
      onSaveHeroSlides(updated);
      showToast('Đã xóa Banner!');
    }
  };

  const handleMoveSlide = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= slidesForm.length) return;
    const newSlides = [...slidesForm];
    const temp = newSlides[index];
    newSlides[index] = newSlides[targetIndex];
    newSlides[targetIndex] = temp;
    setSlidesForm(newSlides);
    onSaveHeroSlides(newSlides);
    showToast('Đã thay đổi thứ tự hiển thị Banner!');
  };

  // ====================================================
  // BANKING SETTINGS HANDLERS
  // ====================================================
  const handleSaveBankingSettings = (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsForm.bankAccountNumber?.trim()) {
      alert('Vui lòng nhập Số Tài Khoản Ngân Hàng!');
      return;
    }
    if (!settingsForm.bankAccountName?.trim()) {
      alert('Vui lòng nhập Tên Chủ Tài Khoản!');
      return;
    }
    if (!settingsForm.bankName?.trim()) {
      alert('Vui lòng chọn hoặc nhập Tên Ngân Hàng!');
      return;
    }

    const updated = {
      ...settingsForm,
      bankAccountName: settingsForm.bankAccountName.trim().toUpperCase(),
      bankAccountNumber: settingsForm.bankAccountNumber.trim(),
      bankName: settingsForm.bankName.trim(),
      bankBranch: (settingsForm.bankBranch || '').trim(),
    };

    setSettingsForm(updated);
    onSaveSiteSettings(updated);
    showToast('Đã lưu thông tin Tài Khoản Ngân Hàng & VietQR thành công!');
  };

  const handleBankQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingBankQr(true);
    try {
      const dataUrl = await processDeviceImage(file);
      setSettingsForm((prev) => ({ ...prev, bankQrCodeUrl: dataUrl }));
      showToast('Đã tải ảnh mã QR tùy chỉnh của ngân hàng!');
    } catch (err: any) {
      alert(err?.message || 'Không thể xử lý file ảnh QR');
    } finally {
      setIsUploadingBankQr(false);
      if (e.target) e.target.value = '';
    }
  };

  // ====================================================
  // GENERAL SETTINGS HANDLERS
  // ====================================================
  const handleSaveGeneralSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSiteSettings(settingsForm);
    showToast('Đã lưu toàn bộ Thông Tin Website & Liên Hệ!');
  };

  // ====================================================
  // TICKER & ANNOUNCEMENT BAR HANDLERS
  // ====================================================
  const handleAddAnnouncement = () => {
    const text = prompt('Nhập câu thông báo mới cho Thanh Trên Cùng:');
    if (!text?.trim()) return;
    const updated = {
      ...settingsForm,
      announcementTexts: [...settingsForm.announcementTexts, text.trim()],
    };
    setSettingsForm(updated);
    onSaveSiteSettings(updated);
    showToast('Đã thêm thông báo mới!');
  };

  const handleRemoveAnnouncement = (index: number) => {
    if (settingsForm.announcementTexts.length <= 1) {
      alert('Phải giữ lại ít nhất 1 câu thông báo!');
      return;
    }
    const updatedTexts = settingsForm.announcementTexts.filter((_, i) => i !== index);
    const updated = { ...settingsForm, announcementTexts: updatedTexts };
    setSettingsForm(updated);
    onSaveSiteSettings(updated);
    showToast('Đã xóa câu thông báo!');
  };

  const handleAddMarquee = () => {
    const text = prompt('Nhập từ khóa / thông điệp mới cho Dải Chữ Chạy (Marquee):');
    if (!text?.trim()) return;
    const updated = {
      ...settingsForm,
      marqueeTexts: [...settingsForm.marqueeTexts, text.trim().toUpperCase()],
    };
    setSettingsForm(updated);
    onSaveSiteSettings(updated);
    showToast('Đã thêm thông điệp Marquee!');
  };

  const handleRemoveMarquee = (index: number) => {
    if (settingsForm.marqueeTexts.length <= 1) {
      alert('Phải giữ lại ít nhất 1 chữ chạy!');
      return;
    }
    const updatedTexts = settingsForm.marqueeTexts.filter((_, i) => i !== index);
    const updated = { ...settingsForm, marqueeTexts: updatedTexts };
    setSettingsForm(updated);
    onSaveSiteSettings(updated);
    showToast('Đã xóa thông điệp Marquee!');
  };

  // ====================================================
  // STORY SECTION HANDLERS
  // ====================================================
  const handleSaveStory = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSiteSettings(settingsForm);
    showToast('Đã lưu Câu Chuyện Thương Hiệu & Ảnh Minh Họa!');
  };

  // ====================================================
  // CATEGORIES SHOWCASE HANDLERS
  // ====================================================
  const handleSaveCategory = (cat: CategoryShowcaseItem) => {
    const updated = categoriesForm.map((c) => (c.id === cat.id ? cat : c));
    setCategoriesForm(updated);
    onSaveCategoryShowcase(updated);
    setEditingCategory(null);
    showToast(`Đã cập nhật danh mục "${cat.name}"!`);
  };

  // ====================================================
  // LOOKBOOK HANDLERS
  // ====================================================
  const handleSaveLookbook = (lb: LookbookItem) => {
    const updated = lookbooksForm.map((l) => (l.id === lb.id ? lb : l));
    setLookbooksForm(updated);
    onSaveLookbooks(updated);
    setEditingLookbook(null);
    showToast(`Đã cập nhật Lookbook "${lb.title}"!`);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header Banner for Site Studio */}
      <div className="bg-white p-5 rounded-sm border border-neutral-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <h2 className="text-base sm:text-lg font-black uppercase font-heading tracking-wider text-neutral-900">
              TRUNG TÂM QUẢN LÝ BANNERS, HÌNH ẢNH & NỘI DUNG WEB
            </h2>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            Toàn quyền điều chỉnh Banner trang chủ, slogan, hình ảnh minh họa, danh mục và câu chuyện thương hiệu
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-bold px-3 py-1 bg-amber-50 text-amber-800 rounded-full border border-amber-200">
            Tải ảnh trực tiếp từ Máy tính & Điện thoại
          </span>
        </div>
      </div>

      {/* Sub Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-neutral-200 text-xs font-bold">
        <button
          onClick={() => setSubTab('hero')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-sm border transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'hero'
              ? 'bg-neutral-950 text-white border-neutral-950 shadow-xs'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
          }`}
        >
          <Camera className="w-3.5 h-3.5 text-amber-400" />
          <span>1. Hero Banners ({slidesForm.length})</span>
        </button>

        <button
          onClick={() => setSubTab('banking')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-sm border transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'banking'
              ? 'bg-neutral-950 text-white border-neutral-950 shadow-xs'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
          }`}
        >
          <Landmark className="w-3.5 h-3.5 text-amber-400" />
          <span>2. Tài Khoản Ngân Hàng & VietQR</span>
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
        </button>

        <button
          onClick={() => setSubTab('general')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-sm border transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'general'
              ? 'bg-neutral-950 text-white border-neutral-950 shadow-xs'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
          }`}
        >
          <Store className="w-3.5 h-3.5 text-amber-400" />
          <span>3. Thông Tin Web & Liên Hệ</span>
        </button>

        <button
          onClick={() => setSubTab('ticker')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-sm border transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'ticker'
              ? 'bg-neutral-950 text-white border-neutral-950 shadow-xs'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
          }`}
        >
          <Megaphone className="w-3.5 h-3.5 text-amber-400" />
          <span>4. Thông Báo & Chữ Chạy</span>
        </button>

        <button
          onClick={() => setSubTab('story')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-sm border transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'story'
              ? 'bg-neutral-950 text-white border-neutral-950 shadow-xs'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-400" />
          <span>5. Câu Chuyện & 2 Ảnh Bìa</span>
        </button>

        <button
          onClick={() => setSubTab('categories')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-sm border transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'categories'
              ? 'bg-neutral-950 text-white border-neutral-950 shadow-xs'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
          }`}
        >
          <Grid className="w-3.5 h-3.5 text-amber-400" />
          <span>6. Ảnh Danh Mục ({categoriesForm.length})</span>
        </button>

        <button
          onClick={() => setSubTab('lookbook')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-sm border transition-all cursor-pointer whitespace-nowrap ${
            subTab === 'lookbook'
              ? 'bg-neutral-950 text-white border-neutral-950 shadow-xs'
              : 'bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-100'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>7. Lookbook Streetwear ({lookbooksForm.length})</span>
        </button>
      </div>

      {/* ==================================================== */}
      {/* SUB-TAB 1: HERO BANNERS & SLIDER */}
      {/* ==================================================== */}
      {subTab === 'hero' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-sm border border-neutral-200 shadow-xs">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                <Camera className="w-4 h-4 text-amber-500" />
                <span>Danh Sách Banner Chính Trang Chủ (Hero Slider)</span>
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                Các Banner lớn hiển thị đầu trang web khi khách hàng truy cập
              </p>
            </div>

            <button
              onClick={() => {
                const newSlideTemplate: HeroSlide = {
                  id: `slide-${Date.now().toString().slice(-4)}`,
                  badge: 'NEW COLLECTION 2026',
                  title: 'STREET CULTURE VIBE',
                  subtitle: 'PHONG CÁCH ĐƯỜNG PHỐ NGUYÊN BẢN',
                  description: 'Khám phá các thiết kế thời thượng, chất vải dệt dày dặn và phom dáng thời trang.',
                  image: BANNER_PRESETS[0].url,
                  collectionSlug: 'wear-your-story',
                  ctaText: 'KHÁM PHÁ NGAY',
                };
                setEditingSlide(newSlideTemplate);
                setIsNewSlide(true);
              }}
              className="flex items-center justify-center gap-2 bg-neutral-950 hover:bg-black text-white px-4 py-2 rounded-sm text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>Thêm Banner Mới</span>
            </button>
          </div>

          {/* Banner Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {slidesForm.map((slide, idx) => (
              <div
                key={slide.id}
                className="bg-white rounded-sm border border-neutral-200 shadow-xs overflow-hidden flex flex-col group"
              >
                {/* Banner Image Preview with Overlay */}
                <div className="relative aspect-[16/9] w-full bg-neutral-900 overflow-hidden">
                  <img
                    src={slide.image}
                    alt={slide.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-between p-3 text-white">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-widest bg-amber-400 text-black px-2 py-0.5 rounded-2xs font-mono">
                        SLIDE #{idx + 1}
                      </span>
                      <span className="text-[10px] font-bold bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded-2xs text-neutral-200">
                        {slide.collectionSlug}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold text-amber-300 tracking-wider uppercase block">
                        {slide.badge}
                      </span>
                      <h4 className="text-base font-black uppercase font-heading tracking-tight drop-shadow-sm">
                        {slide.title}
                      </h4>
                      <p className="text-[11px] text-neutral-300 line-clamp-1">
                        {slide.subtitle}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Banner Details & Controls */}
                <div className="p-3.5 flex-1 flex flex-col justify-between space-y-3">
                  <p className="text-xs text-neutral-600 line-clamp-2 italic">
                    "{slide.description}"
                  </p>

                  <div className="pt-2 border-t border-neutral-100 flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={idx === 0}
                        onClick={() => handleMoveSlide(idx, 'up')}
                        className={`p-1.5 rounded-2xs border ${
                          idx === 0
                            ? 'opacity-30 cursor-not-allowed border-neutral-200'
                            : 'hover:bg-neutral-100 border-neutral-300 text-neutral-700 cursor-pointer'
                        }`}
                        title="Đưa lên trên"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={idx === slidesForm.length - 1}
                        onClick={() => handleMoveSlide(idx, 'down')}
                        className={`p-1.5 rounded-2xs border ${
                          idx === slidesForm.length - 1
                            ? 'opacity-30 cursor-not-allowed border-neutral-200'
                            : 'hover:bg-neutral-100 border-neutral-300 text-neutral-700 cursor-pointer'
                        }`}
                        title="Đưa xuống dưới"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setEditingSlide(slide);
                          setIsNewSlide(false);
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 bg-neutral-900 hover:bg-black text-white text-xs font-bold rounded-sm transition-colors cursor-pointer"
                      >
                        <Edit3 className="w-3 h-3 text-amber-400" />
                        <span>Chỉnh Sửa & Đổi Ảnh</span>
                      </button>
                      <button
                        onClick={() => handleDeleteHeroSlide(slide.id)}
                        className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-sm hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Xóa Banner này"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 2: BANK ACCOUNT & VIETQR SETTINGS */}
      {/* ==================================================== */}
      {subTab === 'banking' && (
        <div className="space-y-6">
          {/* Header Banner */}
          <div className="bg-white p-5 sm:p-6 rounded-sm border border-neutral-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Landmark className="w-5 h-5 text-amber-500" />
                <h3 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider text-neutral-900">
                  CÀI ĐẶT TÀI KHOẢN NGÂN HÀNG & MÃ VIETQR (24/7)
                </h3>
              </div>
              <p className="text-xs text-neutral-500 mt-1">
                Tùy chỉnh thông tin Tên tài khoản, Số tài khoản, Ngân hàng và Chi nhánh để khách hàng quét mã chuyển khoản khi mua sắm
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold px-3 py-1.5 bg-emerald-50 text-emerald-800 rounded-full border border-emerald-200 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Tương thích 100% App Ngân Hàng & Ví Điện Tử VN
              </span>
            </div>
          </div>

          {/* Quick Bank Presets */}
          <div className="bg-neutral-50 p-3.5 rounded-sm border border-neutral-200 flex flex-wrap items-center gap-2 text-xs">
            <span className="font-bold text-neutral-600 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-amber-500" />
              <span>Gợi ý chọn nhanh ngân hàng:</span>
            </span>
            {[
              { name: 'MB Bank (Quân Đội)', code: 'MB' },
              { name: 'Vietcombank', code: 'VCB' },
              { name: 'Techcombank', code: 'TCB' },
              { name: 'ACB', code: 'ACB' },
              { name: 'VPBank', code: 'VPB' },
              { name: 'BIDV', code: 'BIDV' },
              { name: 'VietinBank', code: 'ICB' },
              { name: 'TPBank', code: 'TPB' },
            ].map((bank) => (
              <button
                key={bank.code}
                type="button"
                onClick={() => {
                  const fullBank = VIETNAMESE_BANKS.find((b) => b.code === bank.code);
                  if (fullBank) {
                    setSettingsForm((prev) => ({
                      ...prev,
                      bankName: fullBank.name,
                    }));
                    showToast(`Đã chọn ngân hàng ${fullBank.shortName}`);
                  }
                }}
                className="px-2.5 py-1 bg-white hover:bg-neutral-900 hover:text-white border border-neutral-300 rounded-sm text-[11px] font-bold text-neutral-800 transition-all cursor-pointer shadow-2xs"
              >
                {bank.name}
              </button>
            ))}
          </div>

          {/* Main 2-Column Layout: Form & Live Bank Card Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: Bank Settings Form */}
            <div className="lg:col-span-7">
              <form onSubmit={handleSaveBankingSettings} className="bg-white p-5 sm:p-6 rounded-sm border border-neutral-200 shadow-xs space-y-5">
                <div className="border-b pb-3 flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-amber-500" />
                    <span>Thông Tin Tài Khoản Nhận Chuyển Khoản</span>
                  </h4>
                  <span className="text-[11px] text-amber-600 font-bold">* Bắt buộc</span>
                </div>

                <div className="space-y-4 text-xs">
                  {/* Bank Selector */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-neutral-800 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-neutral-500" />
                        <span>1. Ngân Hàng Thụ Hưởng (Chọn từ danh sách) *</span>
                      </span>
                    </label>
                    <select
                      value={
                        VIETNAMESE_BANKS.find(
                          (b) =>
                            b.code !== 'OTHER' &&
                            (settingsForm.bankName.toLowerCase().includes(b.shortName.toLowerCase()) ||
                              settingsForm.bankName.toLowerCase().includes(b.code.toLowerCase()))
                        )?.code || 'OTHER'
                      }
                      onChange={(e) => {
                        const selected = VIETNAMESE_BANKS.find((b) => b.code === e.target.value);
                        if (selected) {
                          if (selected.code !== 'OTHER') {
                            setSettingsForm({ ...settingsForm, bankName: selected.name });
                          }
                        }
                      }}
                      className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 cursor-pointer"
                    >
                      {VIETNAMESE_BANKS.map((b) => (
                        <option key={b.code} value={b.code}>
                          {b.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Bank Name Custom input */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-neutral-800 flex items-center justify-between">
                      <span>Tên Ngân Hàng hiển thị chi tiết:</span>
                      <span className="text-[11px] text-neutral-400 font-normal">Có thể chỉnh sửa văn bản tùy ý</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="VD: MB Bank (Ngân hàng TMCP Quân Đội)"
                      value={settingsForm.bankName}
                      onChange={(e) => setSettingsForm({ ...settingsForm, bankName: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
                    />
                  </div>

                  {/* Account Number */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-neutral-800 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <CreditCard className="w-3.5 h-3.5 text-neutral-500" />
                        <span>2. Số Tài Khoản Ngân Hàng (STK) *</span>
                      </span>
                      <span className="text-[11px] text-neutral-400 font-normal">Chỉ gồm các chữ số liền nhau</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="VD: 0988668899"
                      value={settingsForm.bankAccountNumber}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          bankAccountNumber: e.target.value.replace(/\s+/g, ''),
                        })
                      }
                      className="w-full px-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-sm font-mono text-base font-black text-neutral-900 tracking-wider focus:bg-white focus:outline-none focus:border-neutral-900"
                    />
                  </div>

                  {/* Account Holder Name */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-neutral-800 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-neutral-500" />
                        <span>3. Tên Chủ Tài Khoản (In Hoa) *</span>
                      </span>
                      <span className="text-[11px] text-emerald-700 font-bold">Tự động in hoa chuẩn ngân hàng</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="VD: NGUYEN VAN A hoặc BONG STORE VIETNAM"
                      value={settingsForm.bankAccountName}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          bankAccountName: e.target.value.toUpperCase(),
                        })
                      }
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 tracking-wide uppercase focus:bg-white focus:outline-none focus:border-neutral-900"
                    />
                  </div>

                  {/* Bank Branch */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-neutral-800 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                        <span>4. Chi Nhánh Mở Tài Khoản (Tùy chọn)</span>
                      </span>
                      <span className="text-[11px] text-neutral-400 font-normal">Hiển thị cho khách hàng tham khảo</span>
                    </label>
                    <input
                      type="text"
                      placeholder="VD: Chi nhánh Sài Gòn (TP.HCM)"
                      value={settingsForm.bankBranch || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, bankBranch: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                    />
                  </div>

                  {/* QR Code Mode & Custom Upload */}
                  <div className="pt-3 border-t border-neutral-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                        <QrCode className="w-3.5 h-3.5 text-amber-500" />
                        <span>5. Tùy Chọn Mã QR Thanh Toán</span>
                      </label>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          id="qr-auto"
                          name="qr-mode"
                          checked={!settingsForm.bankQrCodeUrl}
                          onChange={() => setSettingsForm({ ...settingsForm, bankQrCodeUrl: '' })}
                          className="accent-neutral-900 cursor-pointer"
                        />
                        <label htmlFor="qr-auto" className="cursor-pointer font-bold text-neutral-800 flex items-center gap-1.5">
                          <span>Tự động tạo mã VietQR 24/7 theo Số Tài Khoản</span>
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">Khuyên Dùng</span>
                        </label>
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          id="qr-custom"
                          name="qr-mode"
                          checked={Boolean(settingsForm.bankQrCodeUrl)}
                          onChange={() => {
                            if (!settingsForm.bankQrCodeUrl) {
                              bankQrInputRef.current?.click();
                            }
                          }}
                          className="accent-neutral-900 cursor-pointer"
                        />
                        <label htmlFor="qr-custom" className="cursor-pointer font-medium text-neutral-700">
                          Tải lên ảnh mã QR riêng của cửa hàng (từ máy tính / điện thoại)
                        </label>
                      </div>
                    </div>

                    {/* Custom QR upload controls */}
                    <div className="bg-neutral-50 p-3 rounded-sm border border-neutral-200 space-y-2.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <input
                          ref={bankQrInputRef}
                          type="file"
                          accept="image/*"
                          onChange={handleBankQrUpload}
                          className="hidden"
                        />
                        <button
                          type="button"
                          disabled={isUploadingBankQr}
                          onClick={() => bankQrInputRef.current?.click()}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 hover:bg-black text-white rounded-sm text-xs font-bold transition-colors cursor-pointer"
                        >
                          <Upload className="w-3.5 h-3.5 text-amber-400" />
                          <span>{isUploadingBankQr ? 'Đang xử lý ảnh...' : 'Tải Ảnh Mã QR Từ Máy'}</span>
                        </button>

                        {settingsForm.bankQrCodeUrl && (
                          <button
                            type="button"
                            onClick={() => {
                              setSettingsForm({ ...settingsForm, bankQrCodeUrl: '' });
                              showToast('Đã chuyển về chế độ tự tạo VietQR 24/7');
                            }}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-sm text-xs font-medium transition-colors cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Quay lại dùng VietQR Tự Động</span>
                          </button>
                        )}
                      </div>

                      {settingsForm.bankQrCodeUrl ? (
                        <div className="flex items-center gap-3 bg-white p-2 rounded border border-neutral-200">
                          <img
                            src={settingsForm.bankQrCodeUrl}
                            alt="Custom Bank QR"
                            className="w-12 h-12 object-contain rounded border border-neutral-200 bg-white"
                          />
                          <div className="text-[11px]">
                            <p className="font-bold text-emerald-700">Đang sử dụng ảnh mã QR tùy chỉnh đã tải lên</p>
                            <p className="text-neutral-500">Khách hàng sẽ quét ảnh mã QR này khi thanh toán</p>
                          </div>
                        </div>
                      ) : (
                        <p className="text-[11px] text-neutral-500">
                          Hệ thống sẽ tự động ghép Tên Ngân Hàng, STK và Tên Chủ TK để sinh mã VietQR chuẩn Napas 24/7 tự động.
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Form Action Buttons */}
                <div className="pt-4 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setSettingsForm((prev) => ({
                        ...prev,
                        bankName: 'MB Bank (Ngân hàng TMCP Quân Đội)',
                        bankAccountNumber: '0988668899',
                        bankAccountName: 'BONG STORE VIETNAM',
                        bankBranch: 'Chi nhánh Sài Gòn (TP.HCM)',
                        bankQrCodeUrl: '',
                      }));
                      showToast('Đã nạp dữ liệu mẫu ban đầu');
                    }}
                    className="text-xs font-bold text-neutral-500 hover:text-neutral-900 transition-colors cursor-pointer"
                  >
                    Khôi phục tài khoản mẫu Bông Store
                  </button>

                  <button
                    type="submit"
                    className="w-full sm:w-auto px-6 py-2.5 bg-neutral-950 hover:bg-black text-white rounded-sm font-black uppercase tracking-wider text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer"
                  >
                    <Save className="w-4 h-4 text-amber-400" />
                    <span>Lưu Cài Đặt Tài Khoản Ngân Hàng</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Right Column: Live Banking Card & VietQR Preview */}
            <div className="lg:col-span-5 space-y-4">
              
              {/* Virtual Black Bank Card */}
              <div className="bg-linear-to-br from-neutral-950 via-neutral-900 to-neutral-950 text-white p-5 rounded-lg border border-neutral-800 shadow-xl relative overflow-hidden space-y-4">
                
                {/* Card Background Watermark */}
                <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-amber-400/5 rounded-full blur-2xl pointer-events-none" />
                <div className="absolute top-2 right-2 text-[60px] font-black text-white/5 font-heading pointer-events-none select-none">
                  BÔNG
                </div>

                {/* Card Top Row: Brand & Napas Logo */}
                <div className="flex items-center justify-between relative z-10">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
                    <span className="font-heading font-black tracking-widest text-sm text-white">
                      {settingsForm.storeName || 'BÔNG STORE'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-neutral-800/80 px-2 py-0.5 rounded text-[10px] font-black text-neutral-200 border border-neutral-700 tracking-wider">
                    <span>NAPAS 24/7</span>
                    <span className="text-amber-400">VietQR</span>
                  </div>
                </div>

                {/* Chip & Bank Name */}
                <div className="space-y-1 relative z-10 pt-2">
                  <div className="flex items-center justify-between">
                    <div className="w-8 h-6 bg-linear-to-tr from-amber-400 to-amber-200 rounded-xs flex items-center justify-center shadow-xs">
                      <div className="w-5 h-3 border border-neutral-900/40 rounded-2xs" />
                    </div>
                    <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                      TÀI KHOẢN CHÍNH THỨC
                    </span>
                  </div>
                  <p className="text-xs font-bold text-neutral-300 pt-1">
                    {settingsForm.bankName || 'Ngân hàng chưa chọn'}
                  </p>
                </div>

                {/* Account Number Display */}
                <div className="space-y-1 relative z-10">
                  <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">
                    Số tài khoản nhận tiền
                  </span>
                  <div className="flex items-center justify-between bg-neutral-900/90 px-3 py-2 rounded border border-neutral-800">
                    <span className="font-mono text-base sm:text-lg font-black text-amber-400 tracking-widest">
                      {settingsForm.bankAccountNumber || 'CHƯA NHẬP SỐ TK'}
                    </span>
                    {settingsForm.bankAccountNumber && (
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(settingsForm.bankAccountNumber);
                          setCopiedBankAcc(true);
                          setTimeout(() => setCopiedBankAcc(false), 2000);
                        }}
                        className="p-1 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                        title="Sao chép số tài khoản"
                      >
                        {copiedBankAcc ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    )}
                  </div>
                </div>

                {/* Account Name & Branch */}
                <div className="grid grid-cols-2 gap-2 text-xs relative z-10 pt-1 border-t border-neutral-800">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-neutral-400 block">
                      Chủ tài khoản
                    </span>
                    <span className="font-bold text-white font-mono tracking-wide uppercase truncate block">
                      {settingsForm.bankAccountName || 'TÊN CHỦ TÀI KHOẢN'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-neutral-400 block">
                      Chi nhánh
                    </span>
                    <span className="text-neutral-300 text-[11px] truncate block">
                      {settingsForm.bankBranch || 'Toàn quốc'}
                    </span>
                  </div>
                </div>
              </div>

              {/* VietQR Live QR Code Box */}
              <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b pb-2">
                  <div className="flex items-center gap-1.5">
                    <QrCode className="w-4 h-4 text-neutral-800" />
                    <span className="text-xs font-black uppercase text-neutral-900">
                      Xem Trước Mã QR Khách Hàng Sẽ Quét
                    </span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-50 text-amber-800 rounded border border-amber-200">
                    Live Preview
                  </span>
                </div>

                <div className="flex flex-col items-center justify-center p-3 bg-neutral-50 rounded-sm border border-neutral-200">
                  {settingsForm.bankQrCodeUrl ? (
                    <img
                      src={settingsForm.bankQrCodeUrl}
                      alt="Custom QR Code"
                      className="w-44 h-44 object-contain rounded bg-white p-2 border border-neutral-200 shadow-sm"
                    />
                  ) : settingsForm.bankAccountNumber ? (
                    <img
                      src={generateVietQrUrl(
                        settingsForm.bankName,
                        settingsForm.bankAccountNumber,
                        settingsForm.bankAccountName,
                        499000,
                        'BONGSTORE SAMPLE'
                      )}
                      alt="VietQR 24/7 Preview"
                      className="w-44 h-44 object-contain rounded bg-white p-1 border border-neutral-200 shadow-sm"
                      onError={(e) => {
                        // fallback if vietqr service is slow
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <div className="w-44 h-44 rounded border border-dashed border-neutral-300 flex flex-col items-center justify-center text-center p-3 text-neutral-400 text-xs">
                      <QrCode className="w-8 h-8 mb-2 opacity-40" />
                      <span>Nhập Số tài khoản để hiển thị mã VietQR</span>
                    </div>
                  )}

                  <div className="mt-3 text-center space-y-1 max-w-xs">
                    <p className="text-xs font-bold text-neutral-900">
                      Mã VietQR tự động điền Số Tiền & Nội Dung
                    </p>
                    <p className="text-[11px] text-neutral-500">
                      Khách hàng chỉ cần dùng App ngân hàng bất kỳ để quét, không sợ gõ nhầm số tài khoản.
                    </p>
                  </div>
                </div>

                {/* Example Transfer Syntax */}
                <div className="bg-amber-50/70 p-3 rounded border border-amber-200/80 space-y-1 text-xs">
                  <p className="font-bold text-amber-900 flex items-center gap-1">
                    <span>💡 Cú pháp chuyển khoản tự động:</span>
                  </p>
                  <p className="font-mono text-neutral-800 text-[11px] bg-white px-2 py-1 rounded border border-amber-200">
                    BONGSTORE [MÃ_ĐƠN_HÀNG] (VD: BONGSTORE BS-9876)
                  </p>
                  <p className="text-[10px] text-amber-800">
                    Khi khách đặt hàng, hệ thống sẽ tự động tạo mã QR có sẵn mã đơn hàng của khách!
                  </p>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 3: GENERAL WEBSITE INFO & CONTACT */}
      {/* ==================================================== */}
      {subTab === 'general' && (
        <form onSubmit={handleSaveGeneralSettings} className="bg-white p-5 sm:p-6 rounded-sm border border-neutral-200 shadow-xs space-y-6">
          <div className="border-b pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                <Store className="w-4 h-4 text-amber-500" />
                <span>Thông Tin Nhận Diện Thương Hiệu & Liên Hệ Khách Hàng</span>
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                Được tự động đồng bộ trên Header Logo, Footer, Hóa đơn và các trang thanh toán
              </p>
            </div>

            <button
              type="button"
              onClick={() => setSubTab('banking')}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-sm text-xs font-bold cursor-pointer transition-colors"
            >
              <Landmark className="w-3.5 h-3.5 text-amber-600" />
              <span>Chỉnh Tài Khoản Ngân Hàng &gt;</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* Store Name */}
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                <Store className="w-3.5 h-3.5 text-neutral-500" />
                <span>Tên Cửa Hàng / Thương Hiệu *</span>
              </label>
              <input
                type="text"
                required
                value={settingsForm.storeName}
                onChange={(e) => setSettingsForm({ ...settingsForm, storeName: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 font-heading text-sm"
              />
            </div>

            {/* Slogan */}
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Khẩu Hiệu Chính (Slogan) *</span>
              </label>
              <input
                type="text"
                required
                value={settingsForm.slogan}
                onChange={(e) => setSettingsForm({ ...settingsForm, slogan: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            {/* Hotline */}
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-neutral-500" />
                <span>Hotline CSKH / Đặt Hàng *</span>
              </label>
              <input
                type="text"
                required
                value={settingsForm.hotline}
                onChange={(e) => setSettingsForm({ ...settingsForm, hotline: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            {/* Support Email */}
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-neutral-500" />
                <span>Email Hỗ Trợ Khách Hàng *</span>
              </label>
              <input
                type="email"
                required
                value={settingsForm.email}
                onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            {/* Main Showroom Address */}
            <div className="sm:col-span-2 space-y-1.5">
              <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                <span>Địa Chỉ Showroom Flagship Chính *</span>
              </label>
              <input
                type="text"
                required
                value={settingsForm.address}
                onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            {/* Operating Hours */}
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-neutral-500" />
                <span>Giờ Mở Cửa / Hoạt Động</span>
              </label>
              <input
                type="text"
                value={settingsForm.operatingHours}
                onChange={(e) => setSettingsForm({ ...settingsForm, operatingHours: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            {/* Free Shipping Threshold */}
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Mức Đơn Miễn Phí Vận Chuyển (VNĐ)</span>
              </label>
              <input
                type="number"
                min={0}
                step={10000}
                value={settingsForm.freeShippingThreshold}
                onChange={(e) => setSettingsForm({ ...settingsForm, freeShippingThreshold: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            {/* Social Links */}
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800">Link Facebook</label>
              <input
                type="text"
                value={settingsForm.facebookUrl || ''}
                onChange={(e) => setSettingsForm({ ...settingsForm, facebookUrl: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800">Link Instagram</label>
              <input
                type="text"
                value={settingsForm.instagramUrl || ''}
                onChange={(e) => setSettingsForm({ ...settingsForm, instagramUrl: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800">Link TikTok</label>
              <input
                type="text"
                value={settingsForm.tiktokUrl || ''}
                onChange={(e) => setSettingsForm({ ...settingsForm, tiktokUrl: e.target.value })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-200 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 bg-neutral-950 hover:bg-black text-white rounded-sm font-black uppercase tracking-wider text-xs flex items-center gap-2 shadow-md cursor-pointer"
            >
              <Save className="w-4 h-4 text-amber-400" />
              <span>Lưu Thông Tin Website</span>
            </button>
          </div>
        </form>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 3: ANNOUNCEMENT BAR & MARQUEE TICKER */}
      {/* ==================================================== */}
      {subTab === 'ticker' && (
        <div className="space-y-6">
          
          {/* Top Announcement Bar Editor */}
          <div className="bg-white p-5 sm:p-6 rounded-sm border border-neutral-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                  <Megaphone className="w-4 h-4 text-amber-500" />
                  <span>1. Thanh Thông Báo Chạy Trên Cùng (Top Announcement Bar)</span>
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Các thông điệp luân phiên xoay vòng ở thanh màu đen đầu website
                </p>
              </div>

              <button
                type="button"
                onClick={handleAddAnnouncement}
                className="flex items-center gap-1.5 bg-neutral-950 hover:bg-black text-white px-3 py-1.5 rounded-sm text-xs font-bold uppercase transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400" />
                <span>Thêm Câu Mới</span>
              </button>
            </div>

            <div className="space-y-2">
              {settingsForm.announcementTexts.map((text, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-neutral-50 rounded-sm border border-neutral-200 text-xs font-medium text-neutral-800"
                >
                  <div className="flex items-center gap-2.5 flex-1 pr-3">
                    <span className="w-5 h-5 rounded-full bg-neutral-900 text-amber-400 text-[10px] font-black flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <input
                      type="text"
                      value={text}
                      onChange={(e) => {
                        const updated = [...settingsForm.announcementTexts];
                        updated[idx] = e.target.value;
                        setSettingsForm({ ...settingsForm, announcementTexts: updated });
                      }}
                      className="w-full bg-transparent border-b border-dashed border-neutral-300 focus:border-neutral-900 focus:outline-none py-1 font-medium"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleRemoveAnnouncement(idx)}
                      className="text-neutral-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                      title="Xóa thông báo này"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  onSaveSiteSettings(settingsForm);
                  showToast('Đã lưu các câu thông báo đầu trang!');
                }}
                className="px-5 py-2 bg-neutral-900 hover:bg-black text-white text-xs font-bold uppercase rounded-sm flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Check className="w-3.5 h-3.5 text-amber-400" />
                <span>Lưu Thanh Thông Báo</span>
              </button>
            </div>
          </div>

          {/* Marquee Banner Ticker Editor */}
          <div className="bg-white p-5 sm:p-6 rounded-sm border border-neutral-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-500" />
                  <span>2. Dải Chữ Chạy Vô Tận (Streetwear Marquee Ticker)</span>
                </h3>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Dải chữ chạy ngang tạo phong cách đường phố giữa phần Hero và Danh mục
                </p>
              </div>

              <button
                type="button"
                onClick={handleAddMarquee}
                className="flex items-center gap-1.5 bg-neutral-950 hover:bg-black text-white px-3 py-1.5 rounded-sm text-xs font-bold uppercase transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400" />
                <span>Thêm Từ Khóa</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {settingsForm.marqueeTexts.map((text, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 px-3 py-1.5 bg-neutral-900 text-white rounded-sm text-xs font-mono font-bold"
                >
                  <span>{text}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveMarquee(idx)}
                    className="text-neutral-400 hover:text-rose-400 cursor-pointer"
                    title="Xóa"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  onSaveSiteSettings(settingsForm);
                  showToast('Đã lưu dải chữ chạy Marquee!');
                }}
                className="px-5 py-2 bg-neutral-900 hover:bg-black text-white text-xs font-bold uppercase rounded-sm flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Check className="w-3.5 h-3.5 text-amber-400" />
                <span>Lưu Dải Chữ Marquee</span>
              </button>
            </div>
          </div>

        </div>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 4: STORY SECTION & BRAND IMAGES */}
      {/* ==================================================== */}
      {subTab === 'story' && (
        <form onSubmit={handleSaveStory} className="bg-white p-5 sm:p-6 rounded-sm border border-neutral-200 shadow-xs space-y-6">
          <div className="border-b pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-amber-500" />
                <span>Chỉnh Sửa Câu Chuyện Thương Hiệu & 2 Hình Ảnh Giới Thiệu</span>
              </h3>
              <p className="text-xs text-neutral-500 mt-0.5">
                Nội dung phần "Câu Chuyện Bông Store" định vị chất lượng và giá trị cốt lõi
              </p>
            </div>

            <button
              type="submit"
              className="px-5 py-2 bg-neutral-950 hover:bg-black text-white rounded-sm font-black uppercase text-xs flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Save className="w-3.5 h-3.5 text-amber-400" />
              <span>Lưu Câu Chuyện</span>
            </button>
          </div>

          {/* 2 Brand Showcase Images (Direct Device Upload from PC / Phone) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-neutral-50 p-4 sm:p-5 rounded-sm border border-neutral-200">
            {/* Story Image 1 */}
            <DeviceSingleImageField
              label="Ảnh Giới Thiệu 1 (Ảnh Dọc Trái)"
              badge="STORY PHOTO 1"
              imageUrl={settingsForm.story.image1}
              onUpload={async (file) => {
                try {
                  const base64 = await processDeviceImage(file);
                  setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, image1: base64 },
                  });
                  showToast('Đã tải ảnh câu chuyện 1 từ thiết bị!');
                } catch (err: any) {
                  alert(err.message || 'Lỗi tải ảnh');
                }
              }}
              onRemove={() => {
                setSettingsForm({
                  ...settingsForm,
                  story: { ...settingsForm.story, image1: BANNER_PRESETS[2].url },
                });
              }}
              onOpenPresets={() => {
                setPresetModal({
                  isOpen: true,
                  title: 'Chọn ảnh mẫu cho Câu Chuyện Thương Hiệu 1',
                  presets: BANNER_PRESETS,
                  onSelect: (url) => {
                    setSettingsForm({
                      ...settingsForm,
                      story: { ...settingsForm.story, image1: url },
                    });
                    setPresetModal((prev) => ({ ...prev, isOpen: false }));
                    showToast('Đã chọn ảnh mẫu!');
                  },
                });
              }}
            />

            {/* Story Image 2 */}
            <DeviceSingleImageField
              label="Ảnh Giới Thiệu 2 (Ảnh Dọc Phải)"
              badge="STORY PHOTO 2"
              imageUrl={settingsForm.story.image2}
              onUpload={async (file) => {
                try {
                  const base64 = await processDeviceImage(file);
                  setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, image2: base64 },
                  });
                  showToast('Đã tải ảnh câu chuyện 2 từ thiết bị!');
                } catch (err: any) {
                  alert(err.message || 'Lỗi tải ảnh');
                }
              }}
              onRemove={() => {
                setSettingsForm({
                  ...settingsForm,
                  story: { ...settingsForm.story, image2: BANNER_PRESETS[0].url },
                });
              }}
              onOpenPresets={() => {
                setPresetModal({
                  isOpen: true,
                  title: 'Chọn ảnh mẫu cho Câu Chuyện Thương Hiệu 2',
                  presets: BANNER_PRESETS,
                  onSelect: (url) => {
                    setSettingsForm({
                      ...settingsForm,
                      story: { ...settingsForm.story, image2: url },
                    });
                    setPresetModal((prev) => ({ ...prev, isOpen: false }));
                    showToast('Đã chọn ảnh mẫu!');
                  },
                });
              }}
            />
          </div>

          {/* Story Texts */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800">Huy hiệu Badge (vd: CÂU CHUYỆN THƯƠNG HIỆU)</label>
              <input
                type="text"
                value={settingsForm.story.badge}
                onChange={(e) => setSettingsForm({
                  ...settingsForm,
                  story: { ...settingsForm.story, badge: e.target.value },
                })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-neutral-800">Slogan tiêu đề (vd: WEAR YOUR STORY.)</label>
              <input
                type="text"
                value={settingsForm.story.slogan}
                onChange={(e) => setSettingsForm({
                  ...settingsForm,
                  story: { ...settingsForm.story, slogan: e.target.value },
                })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
              />
            </div>

            <div className="sm:col-span-2 space-y-1.5">
              <label className="font-bold text-neutral-800">Đoạn văn mở đầu (Intro Paragraph)</label>
              <textarea
                rows={3}
                value={settingsForm.story.introParagraph}
                onChange={(e) => setSettingsForm({
                  ...settingsForm,
                  story: { ...settingsForm.story, introParagraph: e.target.value },
                })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
              />
            </div>

            <div className="sm:col-span-2 space-y-1.5">
              <label className="font-bold text-neutral-800">Đoạn văn chi tiết (Detail Paragraph)</label>
              <textarea
                rows={3}
                value={settingsForm.story.detailParagraph}
                onChange={(e) => setSettingsForm({
                  ...settingsForm,
                  story: { ...settingsForm.story, detailParagraph: e.target.value },
                })}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 font-medium"
              />
            </div>
          </div>

          {/* 2 Stats Metrics */}
          <div className="border-t pt-4 space-y-3">
            <h4 className="text-xs font-black uppercase text-neutral-900">2 Số Liệu Nổi Bật</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-neutral-50 rounded-sm border border-neutral-200 space-y-2">
                <label className="font-bold text-neutral-800 block">Số liệu 1</label>
                <input
                  type="text"
                  placeholder="100.000+"
                  value={settingsForm.story.stat1Number}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, stat1Number: e.target.value },
                  })}
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-sm font-mono font-bold"
                />
                <input
                  type="text"
                  placeholder="Khách hàng yêu thích"
                  value={settingsForm.story.stat1Label}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, stat1Label: e.target.value },
                  })}
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-sm"
                />
              </div>

              <div className="p-3 bg-neutral-50 rounded-sm border border-neutral-200 space-y-2">
                <label className="font-bold text-neutral-800 block">Số liệu 2</label>
                <input
                  type="text"
                  placeholder="260-380"
                  value={settingsForm.story.stat2Number}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, stat2Number: e.target.value },
                  })}
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-sm font-mono font-bold"
                />
                <input
                  type="text"
                  placeholder="GSM Vải siêu dày dặn"
                  value={settingsForm.story.stat2Label}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, stat2Label: e.target.value },
                  })}
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-sm"
                />
              </div>
            </div>
          </div>

          {/* 3 Quality Pillars */}
          <div className="border-t pt-4 space-y-3">
            <h4 className="text-xs font-black uppercase text-neutral-900">3 Trụ Cột Chất Lượng Cốt Lõi</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-neutral-50 rounded-sm border border-neutral-200 space-y-2">
                <label className="font-bold text-neutral-800 block">Trụ cột 1</label>
                <input
                  type="text"
                  value={settingsForm.story.pillar1Title}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, pillar1Title: e.target.value },
                  })}
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded-sm font-bold"
                />
                <textarea
                  rows={3}
                  value={settingsForm.story.pillar1Desc}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, pillar1Desc: e.target.value },
                  })}
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded-sm text-[11px]"
                />
              </div>

              <div className="p-3 bg-neutral-50 rounded-sm border border-neutral-200 space-y-2">
                <label className="font-bold text-neutral-800 block">Trụ cột 2</label>
                <input
                  type="text"
                  value={settingsForm.story.pillar2Title}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, pillar2Title: e.target.value },
                  })}
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded-sm font-bold"
                />
                <textarea
                  rows={3}
                  value={settingsForm.story.pillar2Desc}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, pillar2Desc: e.target.value },
                  })}
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded-sm text-[11px]"
                />
              </div>

              <div className="p-3 bg-neutral-50 rounded-sm border border-neutral-200 space-y-2">
                <label className="font-bold text-neutral-800 block">Trụ cột 3</label>
                <input
                  type="text"
                  value={settingsForm.story.pillar3Title}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, pillar3Title: e.target.value },
                  })}
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded-sm font-bold"
                />
                <textarea
                  rows={3}
                  value={settingsForm.story.pillar3Desc}
                  onChange={(e) => setSettingsForm({
                    ...settingsForm,
                    story: { ...settingsForm.story, pillar3Desc: e.target.value },
                  })}
                  className="w-full px-2.5 py-1.5 bg-white border border-neutral-300 rounded-sm text-[11px]"
                />
              </div>
            </div>
          </div>

          <div className="pt-3 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 bg-neutral-950 hover:bg-black text-white rounded-sm font-black uppercase text-xs flex items-center gap-2 shadow-md cursor-pointer"
            >
              <Save className="w-4 h-4 text-amber-400" />
              <span>Lưu Toàn Bộ Câu Chuyện Thương Hiệu</span>
            </button>
          </div>
        </form>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 5: CATEGORIES SHOWCASE */}
      {/* ==================================================== */}
      {subTab === 'categories' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs">
            <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
              <Grid className="w-4 h-4 text-amber-500" />
              <span>Ảnh Bìa & Thông Tin Danh Mục Nổi Bật (Category Showcase)</span>
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              Thay đổi ảnh đại diện cho từng danh mục thời trang bằng cách tải ảnh trực tiếp từ máy tính/điện thoại
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categoriesForm.map((cat) => (
              <div
                key={cat.id}
                className="bg-white rounded-sm border border-neutral-200 shadow-xs overflow-hidden flex flex-col group"
              >
                {/* Category Cover Image */}
                <div className="relative aspect-[3/4] w-full bg-neutral-900 overflow-hidden">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-3 text-white">
                    <span className="text-[10px] font-bold text-amber-400">{cat.count}</span>
                    <h4 className="text-xs font-black uppercase tracking-wider">{cat.name}</h4>
                  </div>
                </div>

                <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                  <p className="text-[11px] text-neutral-500 line-clamp-2">{cat.desc}</p>
                  <button
                    type="button"
                    onClick={() => setEditingCategory(cat)}
                    className="w-full py-1.5 bg-neutral-900 hover:bg-black text-white rounded-sm text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Edit3 className="w-3 h-3 text-amber-400" />
                    <span>Đổi Ảnh & Tên</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* SUB-TAB 6: LOOKBOOK STREETWEAR */}
      {/* ==================================================== */}
      {subTab === 'lookbook' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs">
            <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Ảnh Người Mẫu & Outfit Lookbook 2026</span>
            </h3>
            <p className="text-xs text-neutral-500 mt-0.5">
              Tải ảnh lookbook outfit mới từ thiết bị để mang đến cảm hứng phối đồ trực quan cho khách hàng
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {lookbooksForm.map((lb) => (
              <div
                key={lb.id}
                className="bg-white rounded-sm border border-neutral-200 shadow-xs overflow-hidden flex flex-col md:flex-row group"
              >
                <div className="relative md:w-1/2 aspect-[4/5] bg-neutral-900 overflow-hidden">
                  <img
                    src={lb.image}
                    alt={lb.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <span className="absolute top-2 left-2 bg-black/80 text-amber-400 text-[10px] font-mono font-bold px-2 py-0.5 rounded-2xs">
                    {lb.collectionSlug}
                  </span>
                </div>

                <div className="p-4 md:w-1/2 flex flex-col justify-between space-y-3">
                  <div>
                    <h4 className="text-sm font-black uppercase font-heading text-neutral-900">
                      {lb.title}
                    </h4>
                    <p className="text-xs text-neutral-600 mt-1 italic">
                      "{lb.subtitle}"
                    </p>
                    <p className="text-[11px] text-neutral-400 mt-2">
                      Gắn {lb.hotspots.length} điểm chạm sản phẩm mua nhanh
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setEditingLookbook(lb)}
                    className="w-full py-2 bg-neutral-950 hover:bg-black text-white rounded-sm text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Đổi Ảnh Lookbook & Tiêu Đề</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL 1: EDIT HERO SLIDE */}
      {/* ==================================================== */}
      {editingSlide && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-2xl bg-white text-neutral-900 rounded-sm shadow-2xl overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
            <div className="p-4 bg-neutral-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-amber-400" />
                <h3 className="font-black uppercase text-sm font-heading tracking-wider">
                  {isNewSlide ? 'THÊM BANNER HERO MỚI' : 'CHỈNH SỬA BANNER TRANG CHỦ'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingSlide(null)}
                className="text-neutral-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveHeroSlide(editingSlide);
              }}
              className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs flex-1"
            >
              {/* Banner Image Uploader */}
              <DeviceSingleImageField
                label="Ảnh Nền Banner (Kích thước khuyến nghị: 1920x1080 hoặc 1800x1200)"
                badge="HERO BACKGROUND"
                imageUrl={editingSlide.image}
                onUpload={async (file) => {
                  try {
                    const base64 = await processDeviceImage(file);
                    setEditingSlide({ ...editingSlide, image: base64 });
                    showToast('Đã tải ảnh banner từ thiết bị!');
                  } catch (err: any) {
                    alert(err.message || 'Lỗi tải ảnh');
                  }
                }}
                onRemove={() => setEditingSlide({ ...editingSlide, image: BANNER_PRESETS[0].url })}
                onOpenPresets={() => {
                  setPresetModal({
                    isOpen: true,
                    title: 'Chọn ảnh Banner Streetwear có sẵn',
                    presets: BANNER_PRESETS,
                    onSelect: (url) => {
                      setEditingSlide({ ...editingSlide, image: url });
                      setPresetModal((prev) => ({ ...prev, isOpen: false }));
                      showToast('Đã chọn ảnh banner mẫu!');
                    },
                  });
                }}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {/* Badge */}
                <div className="space-y-1">
                  <label className="font-bold text-neutral-800">Huy hiệu nhỏ (Badge) *</label>
                  <input
                    type="text"
                    required
                    value={editingSlide.badge}
                    onChange={(e) => setEditingSlide({ ...editingSlide, badge: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 uppercase"
                  />
                </div>

                {/* Target Collection */}
                <div className="space-y-1">
                  <label className="font-bold text-neutral-800">Liên kết Bộ Sưu Tập</label>
                  <select
                    value={editingSlide.collectionSlug}
                    onChange={(e) => setEditingSlide({ ...editingSlide, collectionSlug: e.target.value as CollectionSlug })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-medium text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 cursor-pointer"
                  >
                    <option value="wear-your-story">WEAR YOUR STORY 2026</option>
                    <option value="urban-chronicle">URBAN CHRONICLE</option>
                    <option value="raw-story">RAW STORY</option>
                    <option value="signature-bloom">SIGNATURE BLOOM</option>
                  </select>
                </div>

                {/* Main Title */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-neutral-800">Tiêu Đề Banner Chính *</label>
                  <input
                    type="text"
                    required
                    value={editingSlide.title}
                    onChange={(e) => setEditingSlide({ ...editingSlide, title: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-black text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 uppercase font-heading text-sm"
                  />
                </div>

                {/* Subtitle */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-neutral-800">Phụ Đề / Slogan Phụ *</label>
                  <input
                    type="text"
                    required
                    value={editingSlide.subtitle}
                    onChange={(e) => setEditingSlide({ ...editingSlide, subtitle: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                  />
                </div>

                {/* Description */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="font-bold text-neutral-800">Mô Tả Chi Tiết</label>
                  <textarea
                    rows={2}
                    value={editingSlide.description}
                    onChange={(e) => setEditingSlide({ ...editingSlide, description: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                  />
                </div>

                {/* CTA Button Text */}
                <div className="space-y-1">
                  <label className="font-bold text-neutral-800">Chữ Trên Nút Bấm (CTA) *</label>
                  <input
                    type="text"
                    required
                    value={editingSlide.ctaText}
                    onChange={(e) => setEditingSlide({ ...editingSlide, ctaText: e.target.value })}
                    className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 uppercase"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingSlide(null)}
                  className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-sm font-bold"
                >
                  Hủy Bỏ
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-neutral-950 hover:bg-black text-white font-black uppercase rounded-sm flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4 text-amber-400" />
                  <span>Lưu Banner Này</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL 2: EDIT CATEGORY SHOWCASE */}
      {/* ==================================================== */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-lg bg-white text-neutral-900 rounded-sm shadow-2xl overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-neutral-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Grid className="w-4 h-4 text-amber-400" />
                <h3 className="font-black uppercase text-sm font-heading tracking-wider">
                  ĐỔI ẢNH BÌA & THÔNG TIN DANH MỤC
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingCategory(null)}
                className="text-neutral-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveCategory(editingCategory);
              }}
              className="p-5 space-y-4 text-xs"
            >
              {/* Category Image Uploader */}
              <DeviceSingleImageField
                label="Ảnh Đại Diện Danh Mục (Tải từ máy tính/điện thoại)"
                badge="CATEGORY COVER"
                imageUrl={editingCategory.image}
                onUpload={async (file) => {
                  try {
                    const base64 = await processDeviceImage(file);
                    setEditingCategory({ ...editingCategory, image: base64 });
                    showToast('Đã tải ảnh danh mục từ thiết bị!');
                  } catch (err: any) {
                    alert(err.message || 'Lỗi tải ảnh');
                  }
                }}
                onRemove={() => setEditingCategory({ ...editingCategory, image: CATEGORY_IMAGE_PRESETS[0].url })}
                onOpenPresets={() => {
                  setPresetModal({
                    isOpen: true,
                    title: 'Chọn ảnh danh mục thời trang có sẵn',
                    presets: CATEGORY_IMAGE_PRESETS,
                    onSelect: (url) => {
                      setEditingCategory({ ...editingCategory, image: url });
                      setPresetModal((prev) => ({ ...prev, isOpen: false }));
                      showToast('Đã chọn ảnh mẫu!');
                    },
                  });
                }}
              />

              <div className="space-y-1">
                <label className="font-bold text-neutral-800">Tên hiển thị danh mục *</label>
                <input
                  type="text"
                  required
                  value={editingCategory.name}
                  onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 uppercase"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-neutral-800">Mô tả đặc trưng chất liệu/phom dáng</label>
                <input
                  type="text"
                  value={editingCategory.desc}
                  onChange={(e) => setEditingCategory({ ...editingCategory, desc: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-neutral-800">Số lượng mẫu hiển thị (vd: 15+ Mẫu)</label>
                <input
                  type="text"
                  value={editingCategory.count}
                  onChange={(e) => setEditingCategory({ ...editingCategory, count: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-sm font-bold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-neutral-950 hover:bg-black text-white font-black uppercase rounded-sm flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4 text-amber-400" />
                  <span>Cập Nhật Danh Mục</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL 3: EDIT LOOKBOOK */}
      {/* ==================================================== */}
      {editingLookbook && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-lg bg-white text-neutral-900 rounded-sm shadow-2xl overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-neutral-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <h3 className="font-black uppercase text-sm font-heading tracking-wider">
                  ĐỔI ẢNH OUTFIT LOOKBOOK
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingLookbook(null)}
                className="text-neutral-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveLookbook(editingLookbook);
              }}
              className="p-5 space-y-4 text-xs"
            >
              {/* Lookbook Image Uploader */}
              <DeviceSingleImageField
                label="Ảnh Người Mẫu / Outfit Lookbook (Tải từ máy tính/điện thoại)"
                badge="LOOKBOOK MODEL"
                imageUrl={editingLookbook.image}
                onUpload={async (file) => {
                  try {
                    const base64 = await processDeviceImage(file);
                    setEditingLookbook({ ...editingLookbook, image: base64 });
                    showToast('Đã tải ảnh lookbook từ thiết bị!');
                  } catch (err: any) {
                    alert(err.message || 'Lỗi tải ảnh');
                  }
                }}
                onRemove={() => setEditingLookbook({ ...editingLookbook, image: BANNER_PRESETS[1].url })}
                onOpenPresets={() => {
                  setPresetModal({
                    isOpen: true,
                    title: 'Chọn ảnh Lookbook có sẵn',
                    presets: BANNER_PRESETS,
                    onSelect: (url) => {
                      setEditingLookbook({ ...editingLookbook, image: url });
                      setPresetModal((prev) => ({ ...prev, isOpen: false }));
                      showToast('Đã chọn ảnh mẫu!');
                    },
                  });
                }}
              />

              <div className="space-y-1">
                <label className="font-bold text-neutral-800">Tiêu đề Lookbook *</label>
                <input
                  type="text"
                  required
                  value={editingLookbook.title}
                  onChange={(e) => setEditingLookbook({ ...editingLookbook, title: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-black text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900 uppercase font-heading"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-neutral-800">Thông điệp cảm hứng / Phụ đề</label>
                <textarea
                  rows={2}
                  value={editingLookbook.subtitle}
                  onChange={(e) => setEditingLookbook({ ...editingLookbook, subtitle: e.target.value })}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                />
              </div>

              <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingLookbook(null)}
                  className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-sm font-bold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-neutral-950 hover:bg-black text-white font-black uppercase rounded-sm flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4 text-amber-400" />
                  <span>Cập Nhật Lookbook</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL 4: PRESET IMAGES PICKER */}
      {/* ==================================================== */}
      {presetModal.isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="relative w-full max-w-2xl bg-white text-neutral-900 rounded-sm shadow-2xl overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-neutral-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-amber-400" />
                <h3 className="font-black uppercase text-sm font-heading tracking-wider">
                  {presetModal.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPresetModal((prev) => ({ ...prev, isOpen: false }))}
                className="text-neutral-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {presetModal.presets.map((preset, idx) => (
                  <div
                    key={idx}
                    onClick={() => presetModal.onSelect(preset.url)}
                    className="group border border-neutral-200 hover:border-amber-400 rounded-sm overflow-hidden cursor-pointer transition-all hover:shadow-md bg-neutral-50 flex flex-col"
                  >
                    <div className="aspect-[4/3] overflow-hidden bg-neutral-900 relative">
                      <img
                        src={preset.url}
                        alt={preset.label}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="bg-amber-400 text-black text-[10px] font-black uppercase px-2.5 py-1 rounded-sm shadow-sm">
                          Chọn ảnh này
                        </span>
                      </div>
                    </div>
                    <div className="p-2 text-center">
                      <p className="text-xs font-bold text-neutral-800 line-clamp-1">{preset.label}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

// ====================================================
// HELPER COMPONENT: DEVICE SINGLE IMAGE FIELD
// ====================================================
interface DeviceSingleImageFieldProps {
  label: string;
  badge: string;
  imageUrl: string;
  onUpload: (file: File) => void;
  onRemove: () => void;
  onOpenPresets?: () => void;
}

const DeviceSingleImageField: React.FC<DeviceSingleImageFieldProps> = ({
  label,
  badge,
  imageUrl,
  onUpload,
  onRemove,
  onOpenPresets,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUpload(e.target.files[0]);
      e.target.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onUpload(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="font-bold text-neutral-800 flex items-center gap-1.5 text-xs">
          <Upload className="w-3.5 h-3.5 text-amber-600" />
          <span>{label}</span>
        </label>
        {onOpenPresets && (
          <button
            type="button"
            onClick={onOpenPresets}
            className="text-[11px] text-amber-700 hover:text-amber-900 font-bold underline cursor-pointer"
          >
            Mẫu có sẵn
          </button>
        )}
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        className={`relative w-full rounded-sm border-2 transition-all overflow-hidden flex flex-col items-center justify-center ${
          isDragOver
            ? 'border-amber-500 bg-amber-50/60 ring-2 ring-amber-400/30'
            : imageUrl
            ? 'border-neutral-300 bg-neutral-900'
            : 'border-dashed border-neutral-300 bg-white hover:border-neutral-700 hover:bg-neutral-50'
        } min-h-[160px] p-2.5 text-center`}
      >
        {imageUrl ? (
          <div className="relative w-full h-44 rounded-xs overflow-hidden bg-neutral-900 group">
            <img
              src={imageUrl}
              alt={label}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            />
            <span className="absolute top-2 left-2 bg-black/80 text-white text-[10px] font-bold px-2 py-0.5 rounded-2xs backdrop-blur-xs">
              {badge}
            </span>

            {/* Hover Actions */}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-3">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full max-w-[200px] py-2 bg-amber-400 hover:bg-amber-300 text-black text-xs font-black uppercase rounded-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
              >
                <FolderUp className="w-4 h-4" />
                <span>Đổi Ảnh Máy Tính / ĐT</span>
              </button>
              <button
                type="button"
                onClick={onRemove}
                className="w-full max-w-[200px] py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Khôi Phục Ảnh Mẫu</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="py-4 px-3 space-y-2 flex flex-col items-center">
            <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-800">
                Kéo thả file ảnh hoặc tải từ thiết bị
              </p>
              <p className="text-[10px] text-neutral-500 mt-0.5">
                Hỗ trợ ảnh từ Máy tính, Album ảnh & Camera trên Điện thoại
              </p>
            </div>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="mt-1 px-4 py-1.5 bg-neutral-900 hover:bg-black text-amber-400 text-xs font-black uppercase rounded-sm inline-flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Laptop className="w-3.5 h-3.5" />
              <Smartphone className="w-3.5 h-3.5" />
              <span>Tải Ảnh Từ Thiết Bị</span>
            </button>
          </div>
        )}
      </div>

      {imageUrl && (
        <div className="flex items-center justify-between text-[11px] pt-1">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="text-neutral-700 hover:text-black font-bold flex items-center gap-1 underline cursor-pointer"
          >
            <FolderUp className="w-3 h-3 text-amber-600" />
            <span>Tải ảnh mới từ máy tính / điện thoại</span>
          </button>
        </div>
      )}
    </div>
  );
};
