import React, { useState, useEffect } from 'react';
import { 
  Search, 
  ShoppingBag, 
  Heart, 
  Menu, 
  X, 
  Sparkles, 
  ChevronDown, 
  Award,
  Flame,
  ArrowRight
} from 'lucide-react';
import { ProductCategory, CollectionSlug, SiteSettings } from '../types';
import { COLLECTIONS, DEFAULT_SITE_SETTINGS } from '../data/mockData';

interface NavbarProps {
  siteSettings?: SiteSettings;
  cartCount: number;
  wishlistCount: number;
  selectedCategory: ProductCategory;
  onSelectCategory: (cat: ProductCategory) => void;
  selectedCollection: CollectionSlug | 'all';
  onSelectCollection: (col: CollectionSlug | 'all') => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
  onOpenAiStylist: () => void;
  onOpenVipClub: () => void;
  onOpenStoreLocator: () => void;
  onNavigateSection: (sectionId: string) => void;
  onOpenAdmin?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  siteSettings = DEFAULT_SITE_SETTINGS,
  cartCount,
  wishlistCount,
  selectedCategory,
  onSelectCategory,
  selectedCollection,
  onSelectCollection,
  onOpenCart,
  onOpenWishlist,
  onOpenSearch,
  onOpenAiStylist,
  onOpenVipClub,
  onOpenStoreLocator,
  onNavigateSection,
  onOpenAdmin,
}) => {
  const settings = siteSettings || DEFAULT_SITE_SETTINGS;
  const [isScrolled, setIsScrolled] = useState(false);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [collectionDropdownOpen, setCollectionDropdownOpen] = useState(false);
  const [productDropdownOpen, setProductDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const categories: { label: string; value: ProductCategory; count?: string }[] = [
    { label: 'TẤT CẢ SẢN PHẨM', value: 'all' },
    { label: 'ÁO THUN / TEE', value: 'tee' },
    { label: 'HOODIE & SWEATER', value: 'hoodie-sweater' },
    { label: 'ÁO KHOÁC / JACKET', value: 'jacket' },
    { label: 'QUẦN / PANTS', value: 'pants' },
    { label: 'POLO & SƠ MI', value: 'polo-shirt' },
    { label: 'PHỤ KIỆN / ACCESSORIES', value: 'accessories' },
  ];

  return (
    <header 
      id="main-header"
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md shadow-xs py-3.5 border-b border-neutral-100' 
          : 'bg-white py-4.5 border-b border-neutral-100'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
        
        {/* Left: Mobile burger & Desktop Nav */}
        <div className="flex items-center gap-6">
          <button 
            id="mobile-menu-btn"
            onClick={() => setMobileMenuOpen(true)}
            className="lg:hidden p-1.5 text-neutral-800 hover:text-black focus:outline-hidden"
            aria-label="Open menu"
          >
            <Menu className="w-6 h-6" />
          </button>

          <nav className="hidden lg:flex items-center space-x-6 text-[13px] font-semibold tracking-wider text-neutral-800">
            {/* New drops */}
            <button 
              onClick={() => {
                onSelectCategory('all');
                onSelectCollection('all');
                onNavigateSection('products-section');
              }}
              className="flex items-center gap-1 hover:text-black py-2 cursor-pointer transition-colors group"
            >
              <span>NEW DROPS</span>
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 group-hover:scale-125 transition-transform" />
            </button>

            {/* Collections Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setCollectionDropdownOpen(true)}
              onMouseLeave={() => setCollectionDropdownOpen(false)}
            >
              <button 
                onClick={() => onNavigateSection('collections-section')}
                className="flex items-center gap-1 hover:text-black py-2 cursor-pointer transition-colors"
              >
                <span>BỘ SƯU TẬP</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${collectionDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {collectionDropdownOpen && (
                <div className="absolute top-full left-0 w-80 bg-white shadow-xl border border-neutral-100 py-3 px-2 rounded-xs z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest px-3 py-1">
                    Featured Collections
                  </div>
                  {COLLECTIONS.map((col) => (
                    <button
                      key={col.id}
                      onClick={() => {
                        onSelectCollection(col.slug);
                        onNavigateSection('products-section');
                        setCollectionDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2.5 rounded-xs transition-colors flex items-center justify-between group ${
                        selectedCollection === col.slug ? 'bg-neutral-100 text-black font-bold' : 'hover:bg-neutral-50 text-neutral-700'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs group-hover:text-black">{col.name}</div>
                        <div className="text-[11px] text-neutral-400 line-clamp-1">{col.tagline}</div>
                      </div>
                      <span className="text-[10px] text-neutral-400 group-hover:translate-x-1 transition-transform">→</span>
                    </button>
                  ))}
                  <div className="border-t border-neutral-100 mt-2 pt-2 px-3">
                    <button 
                      onClick={() => {
                        onSelectCollection('all');
                        onNavigateSection('products-section');
                        setCollectionDropdownOpen(false);
                      }}
                      className="text-[11px] text-black font-bold flex items-center gap-1 hover:underline"
                    >
                      Xem tất cả bộ sưu tập <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Products Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setProductDropdownOpen(true)}
              onMouseLeave={() => setProductDropdownOpen(false)}
            >
              <button 
                onClick={() => {
                  onSelectCategory('all');
                  onNavigateSection('products-section');
                }}
                className="flex items-center gap-1 hover:text-black py-2 cursor-pointer transition-colors"
              >
                <span>SẢN PHẨM</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${productDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {productDropdownOpen && (
                <div className="absolute top-full left-0 w-64 bg-white shadow-xl border border-neutral-100 py-2 rounded-xs z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  {categories.map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => {
                        onSelectCategory(cat.value);
                        onNavigateSection('products-section');
                        setProductDropdownOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-xs transition-colors flex items-center justify-between ${
                        selectedCategory === cat.value ? 'bg-neutral-100 text-black font-bold' : 'hover:bg-neutral-50 text-neutral-700'
                      }`}
                    >
                      <span>{cat.label}</span>
                      {selectedCategory === cat.value && <span className="w-1.5 h-1.5 rounded-full bg-black" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Lookbook link */}
            <button 
              onClick={() => onNavigateSection('lookbook-section')}
              className="hover:text-black py-2 cursor-pointer transition-colors"
            >
              LOOKBOOK
            </button>

            {/* About / Story link */}
            <button 
              onClick={() => onNavigateSection('story-section')}
              className="hover:text-black py-2 cursor-pointer transition-colors"
            >
              CÂU CHUYỆN BÔNG
            </button>
          </nav>
        </div>

        {/* Center: Brand Logo */}
        <div className="text-center">
          <button 
            onClick={() => {
              onSelectCategory('all');
              onSelectCollection('all');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex flex-col items-center group cursor-pointer"
          >
            <span className="text-xl sm:text-2xl md:text-3xl font-black tracking-[-0.04em] uppercase font-heading text-neutral-900 group-hover:opacity-80 transition-opacity">
              {settings.storeName}
            </span>
            <span className="text-[9px] sm:text-[10px] font-bold tracking-[0.25em] text-neutral-500 uppercase -mt-0.5 group-hover:text-black transition-colors">
              {settings.slogan}
            </span>
          </button>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          {/* AI Stylist button */}
          <button 
            id="ai-stylist-btn"
            onClick={onOpenAiStylist}
            className="hidden md:flex items-center gap-1.5 bg-neutral-900 hover:bg-black text-white text-xs font-semibold py-1.5 px-3 rounded-full transition-all shadow-xs hover:scale-105 cursor-pointer"
            title="Wear Your Story Stylist"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden lg:inline">Phối Đồ</span>
          </button>

          {/* Search Trigger */}
          <button 
            id="search-btn"
            onClick={onOpenSearch}
            className="p-2 text-neutral-700 hover:text-black hover:bg-neutral-100 rounded-full transition-colors cursor-pointer"
            aria-label="Tìm kiếm sản phẩm"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* VIP Club button */}
          <button 
            id="vip-club-btn"
            onClick={onOpenVipClub}
            className="hidden sm:flex p-2 text-neutral-700 hover:text-black hover:bg-neutral-100 rounded-full transition-colors cursor-pointer"
            title="Bông Club & Điểm Thưởng"
            aria-label="Bông Club"
          >
            <Award className="w-5 h-5" />
          </button>

          {/* Wishlist */}
          <button 
            id="wishlist-btn"
            onClick={onOpenWishlist}
            className="relative p-2 text-neutral-700 hover:text-black hover:bg-neutral-100 rounded-full transition-colors cursor-pointer"
            aria-label="Danh sách yêu thích"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 text-white font-bold text-[9px] rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Cart Bag */}
          <button 
            id="cart-btn"
            onClick={onOpenCart}
            className="relative p-2 bg-neutral-900 hover:bg-black text-white rounded-full transition-transform active:scale-95 cursor-pointer flex items-center justify-center"
            aria-label="Giỏ hàng"
          >
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 bg-amber-400 text-black font-extrabold text-[10px] rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileMenuOpen(false)} 
          />

          <div className="relative w-4/5 max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 overflow-y-auto">
            {/* Header */}
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
              <div>
                <span className="text-lg font-black tracking-tight font-heading">BÔNG STORE</span>
                <p className="text-[10px] text-neutral-500 font-bold tracking-widest">WEAR YOUR STORY</p>
              </div>
              <button 
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 text-neutral-500 hover:text-black rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Links */}
            <div className="p-4 space-y-6 flex-1">
              <div>
                <p className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase mb-2">Danh mục sản phẩm</p>
                <div className="space-y-1">
                  {categories.map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => {
                        onSelectCategory(cat.value);
                        onNavigateSection('products-section');
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full text-left py-2 px-3 rounded-xs text-sm font-semibold flex items-center justify-between ${
                        selectedCategory === cat.value ? 'bg-neutral-900 text-white' : 'text-neutral-700 hover:bg-neutral-100'
                      }`}
                    >
                      <span>{cat.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase mb-2">Bộ sưu tập nổi bật</p>
                <div className="space-y-1">
                  {COLLECTIONS.map((col) => (
                    <button
                      key={col.id}
                      onClick={() => {
                        onSelectCollection(col.slug);
                        onNavigateSection('products-section');
                        setMobileMenuOpen(false);
                      }}
                      className="w-full text-left py-2 px-3 text-xs font-medium text-neutral-700 hover:bg-neutral-100 rounded-xs flex items-center justify-between"
                    >
                      <span>{col.name}</span>
                      <span className="text-[10px] text-neutral-400">{col.year}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-neutral-100 space-y-2">
                <button
                  onClick={() => {
                    onOpenAiStylist();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 px-3 bg-neutral-100 hover:bg-neutral-200 text-neutral-900 rounded-xs text-xs font-bold flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Wear Your Story - AI Stylist</span>
                </button>
                <button
                  onClick={() => {
                    onOpenStoreLocator();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 px-3 text-left text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-xs"
                >
                  Hệ thống 5 cửa hàng
                </button>
                <button
                  onClick={() => {
                    onOpenVipClub();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 px-3 text-left text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-xs"
                >
                  Bông Membership VIP
                </button>
                <button
                  onClick={() => {
                    onNavigateSection('story-section');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 px-3 text-left text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-xs"
                >
                  Về Bông Store & Slogan
                </button>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-neutral-50 border-t border-neutral-100 text-xs text-neutral-500">
              <p className="font-semibold text-neutral-800">Hotline hỗ trợ:</p>
              <p className="text-sm font-mono font-bold text-neutral-900">1900 6868</p>
              <p className="text-[11px] mt-1 text-neutral-400">09:00 - 22:30 hàng ngày</p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
