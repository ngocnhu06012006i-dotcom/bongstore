import React, { useState, useEffect } from 'react';
import { ArrowRight, Sparkles, ChevronLeft, ChevronRight } from 'lucide-react';
import { CollectionSlug, HeroSlide } from '../types';
import { DEFAULT_HERO_SLIDES } from '../data/mockData';

interface HeroSliderProps {
  slides?: HeroSlide[];
  onExploreCollection: (slug: CollectionSlug) => void;
  onExploreAll: () => void;
  onOpenAiStylist: () => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({
  slides = DEFAULT_HERO_SLIDES,
  onExploreCollection,
  onExploreAll,
  onOpenAiStylist,
}) => {
  const activeSlides = slides && slides.length > 0 ? slides : DEFAULT_HERO_SLIDES;
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (current >= activeSlides.length) {
      setCurrent(0);
    }
  }, [activeSlides.length, current]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % activeSlides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [activeSlides.length]);

  const prevSlide = () => {
    setCurrent((prev) => (prev - 1 + activeSlides.length) % activeSlides.length);
  };

  const nextSlide = () => {
    setCurrent((prev) => (prev + 1) % activeSlides.length);
  };

  const slide = activeSlides[current] || activeSlides[0];


  return (
    <section id="hero-slider" className="relative w-full overflow-hidden bg-neutral-950 text-white min-h-[520px] sm:min-h-[600px] lg:min-h-[680px] flex items-center">
      {/* Background Images with smooth fade */}
      {slides.map((s, index) => (
        <div
          key={s.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === current ? 'opacity-100 scale-100' : 'opacity-0 scale-105 pointer-events-none'
          }`}
          style={{ transitionProperty: 'opacity, transform', transitionDuration: '1.2s' }}
        >
          <img
            src={s.image}
            alt={s.title}
            className="w-full h-full object-cover object-center brightness-[0.62] contrast-[1.05]"
          />
          {/* Subtle gradient overlays for text contrast */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
        </div>
      ))}

      {/* Content Container */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20 w-full z-10">
        <div className="max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md border border-white/20 rounded-full text-xs font-bold tracking-widest text-amber-300 uppercase mb-4 animate-in fade-in slide-in-from-bottom-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{slide.badge}</span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black font-heading tracking-tight leading-[0.95] uppercase mb-3">
            {slide.title}
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-base font-semibold tracking-widest text-neutral-300 uppercase mb-4">
            {slide.subtitle}
          </p>

          {/* Description */}
          <p className="text-neutral-300 text-sm sm:text-base leading-relaxed mb-8 max-w-lg">
            {slide.description}
          </p>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4">
            <button
              id="hero-primary-cta"
              onClick={() => onExploreCollection(slide.collectionSlug)}
              className="bg-white hover:bg-amber-400 text-black font-extrabold text-xs sm:text-sm tracking-wider uppercase px-6 sm:px-8 py-3.5 rounded-xs transition-all flex items-center gap-2 group cursor-pointer shadow-lg active:scale-95"
            >
              <span>{slide.ctaText}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              id="hero-secondary-cta"
              onClick={onOpenAiStylist}
              className="bg-black/40 hover:bg-black/70 backdrop-blur-md border border-white/30 text-white font-bold text-xs sm:text-sm tracking-wider uppercase px-5 sm:px-6 py-3.5 rounded-xs transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>GỢI Ý PHỐI ĐỒ</span>
            </button>
          </div>
        </div>
      </div>

      {/* Slider Controls */}
      <div className="absolute bottom-6 right-6 sm:right-12 z-20 flex items-center space-x-3">
        <button
          onClick={prevSlide}
          className="p-2.5 rounded-full bg-black/40 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white transition-all hover:scale-110 active:scale-90"
          aria-label="Previous slide"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex space-x-1.5 px-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className={`h-1.5 transition-all duration-300 rounded-full ${
                i === current ? 'w-8 bg-amber-400' : 'w-2 bg-white/40'
              }`}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>
        <button
          onClick={nextSlide}
          className="p-2.5 rounded-full bg-black/40 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white transition-all hover:scale-110 active:scale-90"
          aria-label="Next slide"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Brand Watermark */}
      <div className="absolute bottom-6 left-6 hidden md:block text-[11px] font-mono tracking-widest text-neutral-400 uppercase opacity-60">
        BÔNG STORE © 2026 • VIETNAM STREETWEAR CULTURE
      </div>
    </section>
  );
};
