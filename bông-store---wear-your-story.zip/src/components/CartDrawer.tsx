import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  Truck, 
  Tag, 
  Check, 
  Plus, 
  ShieldCheck, 
  Sparkles 
} from 'lucide-react';
import { CartItem, Product, ProductColor, ProductSize, Voucher } from '../types';
import { formatVND, FREE_SHIPPING_THRESHOLD, STANDARD_SHIPPING_FEE } from '../utils/formatters';
import { VOUCHERS, PRODUCTS } from '../data/mockData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (itemId: string, qty: number) => void;
  onRemoveItem: (itemId: string) => void;
  appliedVoucher: Voucher | null;
  onApplyVoucher: (voucher: Voucher | null) => void;
  onProceedToCheckout: () => void;
  onAddToCart: (product: Product, color: ProductColor, size: ProductSize) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  appliedVoucher,
  onApplyVoucher,
  onProceedToCheckout,
  onAddToCart,
}) => {
  const [voucherCodeInput, setVoucherCodeInput] = useState('');
  const [voucherError, setVoucherError] = useState('');
  const [showVouchersList, setShowVouchersList] = useState(false);

  if (!isOpen) return null;

  // Subtotal
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  // Free shipping calculation
  const amountNeededForFreeShip = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const freeShipProgress = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  // Discount calculation
  let discountAmount = 0;
  if (appliedVoucher) {
    if (subtotal >= appliedVoucher.minOrderValue) {
      if (appliedVoucher.discountPercent) {
        discountAmount = (subtotal * appliedVoucher.discountPercent) / 100;
      } else if (appliedVoucher.discountAmount) {
        discountAmount = appliedVoucher.discountAmount;
      }
    }
  }

  const shippingFee = subtotal >= FREE_SHIPPING_THRESHOLD || (appliedVoucher?.code === 'FREESHIP') ? 0 : STANDARD_SHIPPING_FEE;
  const finalTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleApplyVoucherCode = (codeToApply?: string) => {
    const code = (codeToApply || voucherCodeInput).trim().toUpperCase();
    if (!code) return;

    const matched = VOUCHERS.find((v) => v.code.toUpperCase() === code);
    if (!matched) {
      setVoucherError('Mã giảm giá không hợp lệ');
      return;
    }

    if (subtotal < matched.minOrderValue) {
      setVoucherError(`Đơn hàng tối thiểu ${formatVND(matched.minOrderValue)} để áp dụng mã này`);
      return;
    }

    onApplyVoucher(matched);
    setVoucherError('');
    setVoucherCodeInput('');
    setShowVouchersList(false);
  };

  // Upsell item (Accessories that aren't in cart yet)
  const upsellProduct = PRODUCTS.find((p) => p.category === 'accessories' && !items.some(it => it.product.id === p.id)) || PRODUCTS[6];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
          
          {/* Drawer Header */}
          <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-neutral-900" />
              <h2 className="text-base font-extrabold font-heading uppercase tracking-tight text-neutral-900">
                GIỎ HÀNG CỦA BẠN ({items.reduce((s, i) => s + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-black rounded-full transition-colors cursor-pointer"
              aria-label="Đóng giỏ hàng"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Bar */}
          <div className="bg-neutral-900 text-white p-3 text-xs">
            {amountNeededForFreeShip > 0 ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-amber-400" />
                    <span>Mua thêm <strong className="text-amber-400">{formatVND(amountNeededForFreeShip)}</strong> để FREESHIP</span>
                  </span>
                  <span>{Math.round(freeShipProgress)}%</span>
                </div>
                <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-amber-400 h-full transition-all duration-500 rounded-full"
                    style={{ width: `${freeShipProgress}%` }}
                  />
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                <Check className="w-4 h-4 bg-emerald-500/20 rounded-full p-0.5" />
                <span>CHÚC MỪNG! BẠN ĐÃ ĐƯỢC MIỄN PHÍ VẬN CHUYỂN</span>
              </div>
            )}
          </div>

          {/* Item List or Empty */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {items.length > 0 ? (
              <>
                <div className="divide-y divide-neutral-100">
                  {items.map((item) => (
                    <div key={item.id} className="py-3.5 flex gap-3.5 first:pt-0">
                      {/* Product Thumbnail */}
                      <img
                        src={item.selectedColor.image}
                        alt={item.product.name}
                        className="w-18 h-22 object-cover object-center rounded-xs bg-neutral-100 shrink-0 border border-neutral-200"
                      />

                      {/* Item Info */}
                      <div className="flex-1 flex flex-col justify-between min-w-0">
                        <div>
                          <div className="flex justify-between items-start gap-1">
                            <h4 className="text-xs font-bold text-neutral-900 truncate">
                              {item.product.name}
                            </h4>
                            <button
                              onClick={() => onRemoveItem(item.id)}
                              className="text-neutral-400 hover:text-red-500 transition-colors p-0.5"
                              title="Xóa khỏi giỏ"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-neutral-500 mt-1">
                            <span className="flex items-center gap-1">
                              <span 
                                className="w-2.5 h-2.5 rounded-full inline-block border border-neutral-300"
                                style={{ backgroundColor: item.selectedColor.hex }}
                              />
                              <span className="truncate max-w-[90px]">{item.selectedColor.name}</span>
                            </span>
                            <span>•</span>
                            <span className="font-bold text-neutral-800">Size: {item.selectedSize}</span>
                          </div>
                        </div>

                        {/* Price & Quantity Stepper */}
                        <div className="flex items-center justify-between pt-2">
                          <span className="text-xs sm:text-sm font-extrabold text-neutral-900 font-mono-num">
                            {formatVND(item.product.price * item.quantity)}
                          </span>

                          <div className="flex items-center border border-neutral-200 rounded-xs bg-neutral-50 text-xs">
                            <button
                              onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                              className="px-2 py-1 text-neutral-600 hover:bg-neutral-200 cursor-pointer font-bold"
                            >
                              -
                            </button>
                            <span className="px-2 py-1 font-mono font-bold min-w-6 text-center">{item.quantity}</span>
                            <button
                              onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                              className="px-2 py-1 text-neutral-600 hover:bg-neutral-200 cursor-pointer font-bold"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Upsell Suggestion Card */}
                {upsellProduct && (
                  <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-xs mt-4">
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-neutral-600 uppercase mb-2">
                      <Sparkles className="w-3 h-3 text-amber-500" />
                      <span>Gợi ý phối thêm cùng outfit:</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <img
                        src={upsellProduct.colors[0]?.image}
                        alt={upsellProduct.name}
                        className="w-12 h-14 object-cover rounded-xs"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold text-neutral-900 truncate">{upsellProduct.name}</div>
                        <div className="text-xs font-black font-mono-num text-neutral-800">{formatVND(upsellProduct.price)}</div>
                      </div>
                      <button
                        onClick={() => onAddToCart(upsellProduct, upsellProduct.colors[0], upsellProduct.sizes[0])}
                        className="px-2.5 py-1.5 bg-neutral-900 hover:bg-black text-white text-[10px] font-bold rounded-xs flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Thêm</span>
                      </button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              /* Empty Cart State */
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-neutral-800">Giỏ hàng của bạn đang trống</h3>
                <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                  Hãy khám phá ngay những thiết kế áo thun, hoodie và phụ kiện mới nhất từ Bông Store!
                </p>
                <button
                  onClick={onClose}
                  className="bg-black hover:bg-neutral-800 text-white text-xs font-extrabold uppercase px-6 py-3 rounded-xs transition-colors cursor-pointer"
                >
                  Khám phá ngay
                </button>
              </div>
            )}
          </div>

          {/* Drawer Footer / Checkout Summary */}
          {items.length > 0 && (
            <div className="p-4 border-t border-neutral-200 bg-white space-y-3">
              
              {/* Voucher Code Input */}
              <div>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-400" />
                    <input
                      type="text"
                      placeholder="Nhập mã ưu đãi (Voucher)..."
                      value={voucherCodeInput}
                      onChange={(e) => {
                        setVoucherCodeInput(e.target.value);
                        setVoucherError('');
                      }}
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-xs pl-8 pr-3 py-2 text-xs uppercase font-mono font-bold focus:outline-hidden focus:border-black"
                    />
                  </div>
                  <button
                    onClick={() => handleApplyVoucherCode()}
                    className="px-4 py-2 bg-neutral-900 hover:bg-black text-white text-xs font-bold rounded-xs cursor-pointer"
                  >
                    Áp Dụng
                  </button>
                </div>

                <div className="flex justify-between items-center mt-1.5">
                  {voucherError ? (
                    <span className="text-[11px] text-rose-600 font-medium">{voucherError}</span>
                  ) : (
                    <span className="text-[10px] text-neutral-400">Thử: <strong>BONGSTORE10</strong>, <strong>WEARYOURSTORY</strong></span>
                  )}
                  <button
                    onClick={() => setShowVouchersList(!showVouchersList)}
                    className="text-[11px] font-bold text-amber-700 hover:underline cursor-pointer"
                  >
                    {showVouchersList ? 'Ẩn mã' : 'Xem mã ưu đãi'}
                  </button>
                </div>

                {/* Available Vouchers dropdown list */}
                {showVouchersList && (
                  <div className="mt-2 p-2 bg-neutral-50 border border-neutral-200 rounded-xs space-y-1.5 max-h-36 overflow-y-auto">
                    {VOUCHERS.map((v) => (
                      <div 
                        key={v.code} 
                        className="flex items-center justify-between p-1.5 bg-white rounded-xs border border-neutral-100 text-xs"
                      >
                        <div>
                          <div className="font-mono font-bold text-neutral-900">{v.code}</div>
                          <div className="text-[10px] text-neutral-500">{v.description}</div>
                        </div>
                        <button
                          onClick={() => handleApplyVoucherCode(v.code)}
                          className="px-2 py-1 bg-amber-400 text-black text-[10px] font-extrabold rounded-xs hover:bg-amber-300"
                        >
                          Dùng
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Applied voucher badge */}
                {appliedVoucher && (
                  <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded-xs flex items-center justify-between text-xs text-emerald-900">
                    <div className="flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Đã áp dụng: <strong>{appliedVoucher.code}</strong> (-{formatVND(discountAmount)})</span>
                    </div>
                    <button 
                      onClick={() => onApplyVoucher(null)}
                      className="text-emerald-700 hover:text-emerald-900 font-bold p-1"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-neutral-600 pt-2 border-t border-neutral-100">
                <div className="flex justify-between">
                  <span>Tạm tính:</span>
                  <span className="font-mono font-bold text-neutral-900">{formatVND(subtotal)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Giảm giá:</span>
                    <span className="font-mono font-bold">-{formatVND(discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Phí vận chuyển:</span>
                  <span className="font-mono font-bold text-neutral-900">
                    {shippingFee === 0 ? <span className="text-emerald-600 uppercase">Miễn Phí</span> : formatVND(shippingFee)}
                  </span>
                </div>
                <div className="flex justify-between items-baseline pt-2 border-t border-neutral-200 text-sm font-extrabold text-neutral-900">
                  <span>TỔNG CỘNG:</span>
                  <span className="text-lg text-black font-mono-num font-black">{formatVND(finalTotal)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={onProceedToCheckout}
                className="w-full py-3.5 bg-black hover:bg-neutral-800 text-white font-extrabold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition-all shadow-lg active:scale-98 cursor-pointer"
              >
                <span>TIẾN HÀNH THANH TOÁN</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="text-[10px] text-neutral-400 text-center flex items-center justify-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Bảo mật thông tin thanh toán 100%</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
