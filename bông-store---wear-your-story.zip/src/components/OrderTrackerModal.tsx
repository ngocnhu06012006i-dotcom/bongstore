import React, { useState } from 'react';
import { X, Search, Package, Truck, CheckCircle2, Clock, MapPin } from 'lucide-react';
import { OrderInfo } from '../types';
import { formatVND } from '../utils/formatters';

interface OrderTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  recentOrders: OrderInfo[];
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  isOpen,
  onClose,
  recentOrders,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedOrder, setSearchedOrder] = useState<OrderInfo | null>(recentOrders[0] || null);
  const [errorNotice, setErrorNotice] = useState('');

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim().toUpperCase();
    if (!query) return;

    const found = recentOrders.find(
      (o) => o.orderId.toUpperCase() === query || o.phone.includes(query)
    );

    if (found) {
      setSearchedOrder(found);
      setErrorNotice('');
    } else {
      // Mock generated fallback lookup for demo
      if (query.startsWith('BS-')) {
        const mockGenerated: OrderInfo = {
          orderId: query,
          customerName: 'Khách hàng Bông Store',
          phone: '090****888',
          email: 'order@bongstore.vn',
          address: 'Quận 1, TP. Hồ Chí Minh',
          city: 'TP. Hồ Chí Minh',
          district: 'Quận 1',
          paymentMethod: 'cod',
          items: [],
          subtotal: 520000,
          discount: 50000,
          shippingFee: 0,
          total: 470000,
          status: 'shipping',
          createdAt: 'Hôm nay, 10:30',
          estimatedDelivery: '1 - 2 ngày tới'
        };
        setSearchedOrder(mockGenerated);
        setErrorNotice('');
      } else {
        setErrorNotice(`Không tìm thấy đơn hàng với mã hoặc số điện thoại "${searchQuery}"`);
      }
    }
  };

  const steps = [
    { title: 'Đã Tiếp Nhận', desc: 'Hệ thống đã xác nhận đơn hàng', icon: Clock, active: true },
    { title: 'Đang Đóng Gói', desc: 'Kiểm tra chất lượng & niêm phong hộp', icon: Package, active: true },
    { title: 'Đang Vận Chuyển', desc: 'Giao Hàng Tiết Kiệm (GHTK)', icon: Truck, active: searchedOrder?.status === 'shipping' || searchedOrder?.status === 'delivered' },
    { title: 'Giao Thành Công', desc: 'Nhận hàng & kiểm tra', icon: CheckCircle2, active: searchedOrder?.status === 'delivered' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-2xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-amber-400">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider">
                TRA CỨU HÀNH TRÌNH ĐƠN HÀNG
              </h3>
              <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase">BÔNG STORE EXPRESS TRACKING</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6">
          {/* Search Input Form */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                type="text"
                placeholder="Nhập mã đơn (VD: BS-889123) hoặc số điện thoại..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setErrorNotice('');
                }}
                className="w-full pl-9 pr-3 py-2.5 bg-neutral-50 border border-neutral-300 rounded-xs text-xs font-mono font-bold uppercase focus:outline-hidden focus:border-black"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 bg-black hover:bg-neutral-800 text-white text-xs font-bold uppercase rounded-xs transition-colors cursor-pointer"
            >
              Tra cứu
            </button>
          </form>

          {errorNotice && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xs">
              {errorNotice}
            </div>
          )}

          {/* Result Order Details */}
          {searchedOrder ? (
            <div className="space-y-6">
              
              {/* Order Header Summary */}
              <div className="bg-neutral-50 border border-neutral-200 p-4 rounded-xs flex flex-wrap justify-between items-center gap-3">
                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase">Mã vận đơn:</span>
                  <div className="text-sm font-mono font-black text-neutral-900">{searchedOrder.orderId}</div>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase">Thời gian đặt:</span>
                  <div className="text-xs font-bold text-neutral-800">{searchedOrder.createdAt}</div>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase">Dự kiến giao:</span>
                  <div className="text-xs font-extrabold text-amber-700">{searchedOrder.estimatedDelivery}</div>
                </div>
              </div>

              {/* Progress Steps Timeline */}
              <div className="py-2">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {steps.map((step, idx) => {
                    const Icon = step.icon;
                    return (
                      <div 
                        key={idx}
                        className={`p-3 rounded-xs border transition-all ${
                          step.active
                            ? 'bg-amber-50/70 border-amber-300 text-neutral-900 ring-1 ring-amber-300/50'
                            : 'bg-neutral-50 border-neutral-200 text-neutral-400 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 mb-1.5">
                          <Icon className={`w-4 h-4 ${step.active ? 'text-amber-600' : 'text-neutral-400'}`} />
                          <span className="text-xs font-black uppercase">{step.title}</span>
                        </div>
                        <p className="text-[10px] leading-tight text-neutral-600">{step.desc}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Customer & Address Details */}
              <div className="border-t border-neutral-200 pt-4 text-xs space-y-2">
                <div className="flex items-center gap-2 text-neutral-700">
                  <MapPin className="w-4 h-4 text-neutral-500 shrink-0" />
                  <span>Giao tới: <strong>{searchedOrder.customerName}</strong> ({searchedOrder.phone}) - {searchedOrder.address}, {searchedOrder.district}, {searchedOrder.city}</span>
                </div>
                <div className="flex justify-between items-center pt-2">
                  <span className="text-neutral-500">Hình thức thanh toán: <strong>{searchedOrder.paymentMethod.toUpperCase()}</strong></span>
                  <span className="text-sm font-black font-mono-num text-neutral-900">Tổng tiền: {formatVND(searchedOrder.total)}</span>
                </div>
              </div>

            </div>
          ) : (
            <div className="text-center py-8 text-neutral-400 text-xs">
              Nhập mã đơn hàng từ tin nhắn xác nhận hoặc số điện thoại đặt hàng để xem lộ trình giao hàng.
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
