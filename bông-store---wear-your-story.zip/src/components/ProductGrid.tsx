import React, { useState, useMemo } from 'react';
import { Product, ProductCategory, CollectionSlug, ProductColor, ProductSize } from '../types';
import { ProductCard } from './ProductCard';
import { COLLECTIONS } from '../data/mockData';
import { SlidersHorizontal, ArrowUpDown, X, Sparkles, Check, ChevronDown } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  selectedCategory: ProductCategory;
  onSelectCategory: (cat: ProductCategory) => void;
  selectedCollection: CollectionSlug | 'all';
  onSelectCollection: (col: CollectionSlug | 'all') => void;
  searchQuery: string;
  onClearSearch: () => void;
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, color: ProductColor, size: ProductSize) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  selectedCollection,
  onSelectCollection,
  searchQuery,
  onClearSearch,
  wishlistIds,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
}) => {
  const [sortBy, setSortBy] = useState<'featured' | 'newest' | 'price-asc' | 'price-desc' | 'best-seller'>('featured');
  const [selectedSizeFilter, setSelectedSizeFilter] = useState<ProductSize | 'all'>('all');
  const [showOnlyDiscount, setShowOnlyDiscount] = useState(false);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  const categories: { label: string; value: ProductCategory }[] = [
    { label: 'Tất Cả', value: 'all' },
    { label: 'Áo Thun', value: 'tee' },
    { label: 'Hoodie & Nỉ', value: 'hoodie-sweater' },
    { label: 'Áo Khoác', value: 'jacket' },
    { label: 'Quần & Cargo', value: 'pants' },
    { label: 'Polo & Sơ Mi', value: 'polo-shirt' },
    { label: 'Phụ Kiện', value: 'accessories' },
  ];

  const sizes: ProductSize[] = ['S', 'M', 'L', 'XL', 'XXL'];

  // Filtered & Sorted products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category filter
      if (selectedCategory !== 'all' && p.category !== selectedCategory) {
        return false;
      }
      // Collection filter
      if (selectedCollection !== 'all' && p.collection !== selectedCollection) {
        return false;
      }
      // Size filter
      if (selectedSizeFilter !== 'all') {
        if (!p.sizes.includes(selectedSizeFilter) || (p.inStockSizes[selectedSizeFilter] || 0) <= 0) {
          return false;
        }
      }
      // Discount filter
      if (showOnlyDiscount && (!p.discountPercent || p.discountPercent <= 0)) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = p.name.toLowerCase().includes(q);
        const matchCode = p.code.toLowerCase().includes(q);
        const matchDesc = p.description.toLowerCase().includes(q);
        const matchMaterial = p.material.toLowerCase().includes(q);
        if (!matchName && !matchCode && !matchDesc && !matchMaterial) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'best-seller') return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0) || b.reviewCount - a.reviewCount;
      return 0; // featured default
    });
  }, [products, selectedCategory, selectedCollection, selectedSizeFilter, showOnlyDiscount, searchQuery, sortBy]);

  const activeCollectionObj = COLLECTIONS.find(c => c.slug === selectedCollection);

  const resetAllFilters = () => {
    onSelectCategory('all');
    onSelectCollection('all');
    setSelectedSizeFilter('all');
    setShowOnlyDiscount(false);
    onClearSearch();
  };

  const hasActiveFilters = selectedCategory !== 'all' || selectedCollection !== 'all' || selectedSizeFilter !== 'all' || showOnlyDiscount || searchQuery !== '';

  return (
    <section id="products-section" className="py-12 sm:py-16 bg-[#FAFAFA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Banner if Collection is selected */}
        {activeCollectionObj && (
          <div className="relative mb-10 overflow-hidden rounded-xs bg-neutral-900 text-white p-6 sm:p-10">
            <img
              src={activeCollectionObj.heroImage}
              alt={activeCollectionObj.name}
              className="absolute inset-0 w-full h-full object-cover object-center opacity-35"
            />
            <div className="relative z-10 max-w-2xl">
              <div className="inline-block bg-white/20 backdrop-blur-md px-3 py-0.5 rounded-xs text-[10px] font-bold tracking-widest uppercase mb-2">
                COLLECTION {activeCollectionObj.year}
              </div>
              <h2 className="text-2xl sm:text-4xl font-black font-heading tracking-tight uppercase mb-2">
                {activeCollectionObj.name}
              </h2>
              <p className="text-neutral-300 text-xs sm:text-sm leading-relaxed mb-4">
                {activeCollectionObj.description}
              </p>
              <button
                onClick={() => onSelectCollection('all')}
                className="text-xs font-bold text-amber-300 hover:text-white flex items-center gap-1 underline"
              >
                ← Xem tất cả các bộ sưu tập khác
              </button>
            </div>
          </div>
        )}

        {/* Section Title & Subtitle */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold tracking-widest text-neutral-400 uppercase">
                {selectedCategory === 'all' ? 'CATALOG 2026' : 'DANH MỤC'}
              </span>
              {searchQuery && (
                <span className="bg-amber-100 text-amber-900 text-xs px-2 py-0.5 rounded-full font-bold">
                  Tìm kiếm: "{searchQuery}"
                </span>
              )}
            </div>
            <h2 className="text-2xl sm:text-3xl font-black font-heading tracking-tight uppercase text-neutral-900 mt-1">
              {activeCollectionObj ? activeCollectionObj.name : 'TẤT CẢ SẢN PHẨM BÔNG STORE'}
            </h2>
          </div>

          <div className="text-xs text-neutral-500 mt-2 md:mt-0 font-medium">
            Hiển thị <span className="font-bold text-neutral-900">{filteredProducts.length}</span> sản phẩm chất lượng cao
          </div>
        </div>

        {/* Category Pills & Controls Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6 pb-4 border-b border-neutral-200">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => onSelectCategory(cat.value)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat.value
                    ? 'bg-neutral-900 text-white shadow-xs'
                    : 'bg-white text-neutral-600 hover:bg-neutral-200 border border-neutral-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Right Toolbar: Size, Discount, Sort */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Size Filter Dropdown */}
            <div className="flex items-center bg-white border border-neutral-200 rounded-xs px-2.5 py-1.5 text-xs">
              <span className="text-neutral-400 font-medium mr-1.5">Size:</span>
              <select
                value={selectedSizeFilter}
                onChange={(e) => setSelectedSizeFilter(e.target.value as ProductSize | 'all')}
                className="bg-transparent font-bold text-neutral-800 focus:outline-hidden cursor-pointer"
              >
                <option value="all">Tất cả</option>
                {sizes.map((s) => (
                  <option key={s} value={s}>Size {s}</option>
                ))}
              </select>
            </div>

            {/* Discount filter chip */}
            <button
              onClick={() => setShowOnlyDiscount(!showOnlyDiscount)}
              className={`px-2.5 py-1.5 rounded-xs text-xs font-bold border transition-colors flex items-center gap-1 cursor-pointer ${
                showOnlyDiscount 
                  ? 'bg-rose-50 border-rose-300 text-rose-700' 
                  : 'bg-white border-neutral-200 text-neutral-600 hover:border-neutral-400'
              }`}
            >
              <span>Giảm giá</span>
              {showOnlyDiscount && <Check className="w-3 h-3" />}
            </button>

            {/* Sort Select */}
            <div className="flex items-center bg-white border border-neutral-200 rounded-xs px-2.5 py-1.5 text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400 mr-1.5" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent font-bold text-neutral-800 focus:outline-hidden cursor-pointer"
              >
                <option value="featured">Nổi bật nhất</option>
                <option value="newest">Mới ra mắt</option>
                <option value="best-seller">Bán chạy nhất</option>
                <option value="price-asc">Giá: Thấp đến Cao</option>
                <option value="price-desc">Giá: Cao đến Thấp</option>
              </select>
            </div>

            {/* Clear Filters Button if any */}
            {hasActiveFilters && (
              <button
                onClick={resetAllFilters}
                className="text-xs font-bold text-neutral-500 hover:text-red-600 flex items-center gap-1 px-2 py-1 transition-colors cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
                <span>Xóa lọc</span>
              </button>
            )}
          </div>
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isWishlisted={wishlistIds.includes(product.id)}
                onToggleWishlist={onToggleWishlist}
                onQuickView={onQuickView}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-20 bg-white rounded-xs border border-neutral-200 p-8 max-w-md mx-auto">
            <div className="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mx-auto mb-4 text-neutral-400">
              <SlidersHorizontal className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-neutral-900 mb-1">Không tìm thấy sản phẩm phù hợp</h3>
            <p className="text-xs text-neutral-500 mb-6">
              Vui lòng thử điều chỉnh lại bộ lọc danh mục, kích thước hoặc từ khóa tìm kiếm.
            </p>
            <button
              onClick={resetAllFilters}
              className="bg-neutral-900 hover:bg-black text-white text-xs font-bold px-5 py-2.5 rounded-xs transition-colors"
            >
              Xem tất cả sản phẩm
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
