import React, { useState, useEffect, useRef } from 'react';
import { 
  Package, 
  ShoppingBag, 
  Tag, 
  Plus, 
  Edit3, 
  Trash2, 
  Eye, 
  Copy, 
  Check, 
  Search, 
  Save, 
  X, 
  RotateCcw, 
  Sparkles, 
  Layers, 
  ExternalLink,
  Store,
  Clock,
  Phone,
  MapPin,
  Percent,
  CheckCircle2,
  AlertCircle,
  Truck,
  Box,
  Lock,
  Unlock,
  KeyRound,
  ShieldCheck,
  ShieldAlert,
  LogOut,
  Upload,
  UploadCloud,
  Camera,
  Laptop,
  Smartphone,
  FolderUp,
  Image as ImageIcon
} from 'lucide-react';
import { Product, ProductColor, ProductSize, ProductCategory, CollectionSlug, OrderInfo, Voucher, SiteSettings, HeroSlide, CategoryShowcaseItem, LookbookItem } from '../types';
import { COLLECTIONS, DEFAULT_SITE_SETTINGS, DEFAULT_HERO_SLIDES, DEFAULT_CATEGORIES, LOOKBOOKS } from '../data/mockData';
import { AdminSiteSettingsManager } from './AdminSiteSettingsManager';

/**
 * Optimizes and processes uploaded image files from computer or phone:
 * Resizes if larger than 1200x1600 to optimize performance and localStorage capacity,
 * and converts to a high quality base64 image data URL.
 */
export const processDeviceImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Vui lòng chọn file hình ảnh (JPG, PNG, WEBP, GIF, HEIC...)'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1200;
        const MAX_HEIGHT = 1600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.88));
        } else {
          resolve(result);
        }
      };
      img.onerror = () => resolve(result);
      img.src = result;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
};

// Curated high quality streetwear photo presets for instant 1-click preview and editing
export const PRESET_IMAGES = [
  { label: 'Tee - Đen Boxy', url: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=900&auto=format&fit=crop' },
  { label: 'Tee - Kem Butter', url: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=900&auto=format&fit=crop' },
  { label: 'Tee - Xanh Sage', url: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=900&auto=format&fit=crop' },
  { label: 'Tee - Trắng Graphic', url: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=900&auto=format&fit=crop' },
  { label: 'Tee - Xám Khói', url: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=900&auto=format&fit=crop' },
  { label: 'Hoodie - Đen Cyber', url: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=900&auto=format&fit=crop' },
  { label: 'Hoodie - Xám Heather', url: 'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?q=80&w=900&auto=format&fit=crop' },
  { label: 'Hoodie - Nâu Earth', url: 'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?q=80&w=900&auto=format&fit=crop' },
  { label: 'Jacket - Dù Parachute', url: 'https://images.unsplash.com/photo-1548883354-7622d03aca27?q=80&w=900&auto=format&fit=crop' },
  { label: 'Jacket - Bomber Varsity', url: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=900&auto=format&fit=crop' },
  { label: 'Jacket - Da Biker', url: 'https://images.unsplash.com/photo-1520975954732-35dd22299614?q=80&w=900&auto=format&fit=crop' },
  { label: 'Quần - Parachute Đen', url: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=900&auto=format&fit=crop' },
  { label: 'Quần - Cargo Be', url: 'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?q=80&w=900&auto=format&fit=crop' },
  { label: 'Quần - Denim Rách Raw', url: 'https://images.unsplash.com/photo-1542272604-780c96856592?q=80&w=900&auto=format&fit=crop' },
  { label: 'Polo - Zip Cổ Đen', url: 'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?q=80&w=900&auto=format&fit=crop' },
  { label: 'Phụ kiện - Túi Mini Bag', url: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=900&auto=format&fit=crop' },
  { label: 'Phụ kiện - Mũ Nón Bông', url: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=900&auto=format&fit=crop' },
];

const CATEGORY_OPTIONS: { value: ProductCategory; label: string }[] = [
  { value: 'tee', label: 'Áo Thun (T-Shirt)' },
  { value: 'hoodie-sweater', label: 'Hoodie & Sweater' },
  { value: 'jacket', label: 'Áo Khoác (Jacket)' },
  { value: 'pants', label: 'Quần (Pants & Cargo)' },
  { value: 'polo-shirt', label: 'Polo & Sơ Mi' },
  { value: 'accessories', label: 'Phụ Kiện (Accessories)' },
];

const COLLECTION_OPTIONS: { value: CollectionSlug; label: string }[] = [
  { value: 'wear-your-story', label: 'WEAR YOUR STORY 2026' },
  { value: 'urban-chronicle', label: 'URBAN CHRONICLE' },
  { value: 'raw-story', label: 'RAW STORY' },
  { value: 'signature-bloom', label: 'SIGNATURE BLOOM' },
];

interface AdminPortalProps {
  products: Product[];
  onSaveProducts: (products: Product[]) => void;
  orders: OrderInfo[];
  onUpdateOrderStatus: (orderId: string, status: OrderInfo['status']) => void;
  onDeleteOrder: (orderId: string) => void;
  vouchers: Voucher[];
  onSaveVouchers: (vouchers: Voucher[]) => void;
  siteSettings?: SiteSettings;
  onSaveSiteSettings?: (settings: SiteSettings) => void;
  heroSlides?: HeroSlide[];
  onSaveHeroSlides?: (slides: HeroSlide[]) => void;
  categoryShowcase?: CategoryShowcaseItem[];
  onSaveCategoryShowcase?: (categories: CategoryShowcaseItem[]) => void;
  lookbooks?: LookbookItem[];
  onSaveLookbooks?: (lookbooks: LookbookItem[]) => void;
  onResetToDefault: () => void;
  onExitAdmin: () => void;
  onQuickView: (product: Product) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  products,
  onSaveProducts,
  orders,
  onUpdateOrderStatus,
  onDeleteOrder,
  vouchers,
  onSaveVouchers,
  siteSettings = DEFAULT_SITE_SETTINGS,
  onSaveSiteSettings = () => {},
  heroSlides = DEFAULT_HERO_SLIDES,
  onSaveHeroSlides = () => {},
  categoryShowcase = DEFAULT_CATEGORIES,
  onSaveCategoryShowcase = () => {},
  lookbooks = LOOKBOOKS,
  onSaveLookbooks = () => {},
  onResetToDefault,
  onExitAdmin,
  onQuickView,
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'vouchers' | 'marketing'>('products');
  const [copiedLink, setCopiedLink] = useState(false);

  // Authentication & Security State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('bongstore_admin_auth') === 'true';
    } catch {
      return false;
    }
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [changePassOpen, setChangePassOpen] = useState(false);
  const [currentAdminPassword, setCurrentAdminPassword] = useState<string>(() => {
    try {
      return localStorage.getItem('bongstore_admin_pass') || 'bongstore2026';
    } catch {
      return 'bongstore2026';
    }
  });
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passChangeSuccess, setPassChangeSuccess] = useState('');

  // Handle Login Verification
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput.trim() === currentAdminPassword) {
      setIsAuthenticated(true);
      setLoginError('');
      try {
        sessionStorage.setItem('bongstore_admin_auth', 'true');
      } catch {}
      showAdminToast('Đăng nhập Quản Trị Viên thành công!');
    } else {
      setLoginError('Mật khẩu không chính xác! Vui lòng thử lại.');
    }
  };

  // Handle Logout
  const handleLogout = () => {
    setIsAuthenticated(false);
    setPasswordInput('');
    try {
      sessionStorage.removeItem('bongstore_admin_auth');
    } catch {}
    onExitAdmin();
  };

  // Handle Change Password
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) {
      setPassChangeSuccess('Mật khẩu mới phải có ít nhất 4 ký tự.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPassChangeSuccess('Mật khẩu xác nhận không trùng khớp.');
      return;
    }
    setCurrentAdminPassword(newPassword);
    try {
      localStorage.setItem('bongstore_admin_pass', newPassword);
    } catch {}
    setPassChangeSuccess('Đã đổi mật khẩu thành công! Hãy ghi nhớ mật khẩu mới.');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => {
      setChangePassOpen(false);
      setPassChangeSuccess('');
    }, 2000);
    showAdminToast('Mật khẩu Admin đã được cập nhật thành công!');
  };

  // Product Filter and Search in Admin
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedCollection, setSelectedCollection] = useState<string>('all');

  // Editing Product Modal State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // Success Toast state
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const showAdminToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const adminUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}/admin`
    : 'https://bongstore.vn/admin';

  const handleCopyAdminLink = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(adminUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
      showAdminToast('Đã sao chép link trang Admin vào clipboard!');
    }
  };

  // Filtered Products
  const filteredProducts = products.filter((p) => {
    const matchSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.material.toLowerCase().includes(searchQuery.toLowerCase());
    const matchCat = selectedCategory === 'all' || p.category === selectedCategory;
    const matchCol = selectedCollection === 'all' || p.collection === selectedCollection;
    return matchSearch && matchCat && matchCol;
  });

  // Calculate quick stats
  const totalProducts = products.length;
  const totalStock = products.reduce((sum: number, p) => {
    const values = Object.values(p.inStockSizes || {}) as number[];
    const pStock = values.reduce((s: number, num: number) => s + (Number(num) || 0), 0);
    return sum + pStock;
  }, 0);
  const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0);
  const pendingOrders = orders.filter((o) => o.status === 'confirmed' || o.status === 'packing').length;

  // Handle Save Product (Create or Update)
  const handleSaveProductForm = (updatedProduct: Product) => {
    if (isCreatingNew) {
      onSaveProducts([updatedProduct, ...products]);
      showAdminToast(`Đã thêm thành công sản phẩm "${updatedProduct.name}"!`);
    } else {
      onSaveProducts(products.map((p) => (p.id === updatedProduct.id ? updatedProduct : p)));
      showAdminToast(`Đã cập nhật chi tiết & hình ảnh sản phẩm "${updatedProduct.name}"!`);
    }
    setEditingProduct(null);
    setIsCreatingNew(false);
  };

  // Handle Delete Product
  const handleDeleteProduct = (productId: string, productName: string) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa sản phẩm "${productName}"?`)) {
      onSaveProducts(products.filter((p) => p.id !== productId));
      showAdminToast(`Đã xóa sản phẩm "${productName}"`);
    }
  };

  // Handle Duplicate Product
  const handleDuplicateProduct = (product: Product) => {
    const newId = `prod-${Date.now().toString().slice(-4)}`;
    const duplicated: Product = {
      ...product,
      id: newId,
      name: `${product.name} (Bản sao)`,
      code: `${product.code}-COPY`,
      createdAt: new Date().toISOString(),
    };
    onSaveProducts([duplicated, ...products]);
    showAdminToast(`Đã nhân bản sản phẩm "${product.name}"`);
  };

  // Open Create New Product Form
  const handleOpenCreateNew = () => {
    const newProductTemplate: Product = {
      id: `prod-${Date.now().toString().slice(-4)}`,
      name: 'Áo Thun Bông Store Graphic Streetwear',
      code: `BS-TEE-${Math.floor(100 + Math.random() * 900)}`,
      price: 390000,
      originalPrice: 490000,
      category: 'tee',
      collection: 'wear-your-story',
      colors: [
        {
          name: 'Onyx Black (Đen)',
          hex: '#111111',
          image: PRESET_IMAGES[0].url,
          secondaryImage: PRESET_IMAGES[3].url,
          gallery: [PRESET_IMAGES[0].url, PRESET_IMAGES[3].url, PRESET_IMAGES[4].url],
        },
        {
          name: 'Ivory Cream (Kem)',
          hex: '#F4EEDB',
          image: PRESET_IMAGES[1].url,
          secondaryImage: PRESET_IMAGES[3].url,
          gallery: [PRESET_IMAGES[1].url, PRESET_IMAGES[3].url],
        }
      ],
      sizes: ['S', 'M', 'L', 'XL'],
      inStockSizes: { S: 20, M: 35, L: 25, XL: 15, XXL: 0 },
      description: 'Mẫu thiết kế đường phố phong cách Boxy Oversized mới từ BÔNG STORE. Chất vải Compact Cotton cao cấp dệt 260GSM thoáng mát, phom đứng chuẩn form.',
      material: '100% Premium Compact Cotton',
      gsm: '260 GSM Heavyweight',
      fit: 'Boxy Oversized Fit - Tôn dáng cả nam & nữ',
      features: [
        'Xử lý bề mặt Bio-Polishing hạn chế đổ lông',
        'In lụa thủ công Plastisol siêu bền không nứt',
        'Tag dệt thêu vi tính BÔNG STORE cao cấp',
        'Đường may Double-Needle gia cố chống bai dão',
      ],
      isNew: true,
      isBestSeller: false,
      isLimited: false,
      rating: 5.0,
      reviewCount: 1,
      createdAt: new Date().toISOString(),
    };
    setIsCreatingNew(true);
    setEditingProduct(newProductTemplate);
  };

  // IF NOT AUTHENTICATED, RENDER HIGH-SECURITY ADMIN LOGIN SCREEN
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0E0E10] text-white flex items-center justify-center p-4 selection:bg-amber-400 selection:text-black">
        <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-sm shadow-2xl overflow-hidden">
          
          {/* Header Banner */}
          <div className="bg-neutral-950 px-6 py-6 border-b border-neutral-800 text-center relative">
            <div className="w-12 h-12 rounded-sm bg-amber-400 text-black flex items-center justify-center font-black text-xl tracking-tighter mx-auto mb-3 shadow-lg shadow-amber-400/20">
              BÔNG
            </div>
            <h2 className="text-base font-black uppercase tracking-wider text-white font-heading">
              BÔNG STORE ADMIN PORTAL
            </h2>
            <p className="text-xs text-neutral-400 font-mono mt-1">
              TRANG QUẢN TRỊ NỘI BỘ DÀNH CHO BAN QUẢN LÝ
            </p>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-400 text-[10px] font-mono mt-2.5">
              <Lock className="w-3 h-3" />
              <span>YÊU CẦU XÁC THỰC MẬT KHẨU</span>
            </div>
          </div>

          {/* Form Content */}
          <div className="p-6 sm:p-8 space-y-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-2">
                  Mật khẩu Quản Trị Viên (Admin Password)
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={passwordInput}
                    onChange={(e) => {
                      setPasswordInput(e.target.value);
                      if (loginError) setLoginError('');
                    }}
                    placeholder="Nhập mật khẩu quản trị..."
                    autoFocus
                    required
                    className={`w-full px-4 py-3 bg-neutral-950 border ${
                      loginError ? 'border-rose-500 text-rose-300' : 'border-neutral-700 text-white'
                    } rounded-sm text-sm focus:outline-none focus:border-amber-400 pr-10 font-mono transition-colors`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white transition-colors cursor-pointer text-xs font-mono"
                  >
                    {showPassword ? 'ẨN' : 'HIỆN'}
                  </button>
                </div>
                {loginError && (
                  <p className="text-rose-400 text-xs mt-2 flex items-center gap-1.5 font-medium">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{loginError}</span>
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-black font-black uppercase text-xs tracking-wider rounded-sm transition-all shadow-lg shadow-amber-400/10 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Unlock className="w-4 h-4" />
                <span>Mở Khóa Bảng Điều Khiển</span>
              </button>
            </form>

            <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
              <button
                onClick={onExitAdmin}
                className="text-xs text-neutral-400 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Store className="w-3.5 h-3.5" />
                <span>Quay lại trang mua sắm</span>
              </button>
              <span className="text-[10px] text-neutral-600 font-mono">BÔNG STORE v2.4</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F4F4F5] text-neutral-900 flex flex-col font-sans">
      
      {/* Top Admin Navigation Header */}
      <header className="bg-neutral-950 text-white border-b border-neutral-800 sticky top-0 z-40 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo & Portal Badge */}
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-sm bg-amber-400 text-black flex items-center justify-center font-black text-sm tracking-tighter">
                BÔNG
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-black uppercase tracking-wider font-heading">
                    BÔNG STORE ADMIN
                  </h1>
                  <span className="text-[10px] font-black uppercase bg-amber-400/20 text-amber-400 px-2 py-0.5 rounded-full border border-amber-400/30">
                    PORTAL
                  </span>
                </div>
                <p className="text-[10px] text-neutral-400 font-mono">HỆ THỐNG QUẢN TRỊ SẢN PHẨM & ĐƠN HÀNG</p>
              </div>
            </div>

            {/* Direct Admin Link Share Button & Actions */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Copy Admin Link Button */}
              <button
                onClick={handleCopyAdminLink}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-sm text-xs font-bold transition-all cursor-pointer border ${
                  copiedLink 
                    ? 'bg-emerald-500 text-white border-emerald-400' 
                    : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border-neutral-700'
                }`}
                title="Sao chép link web admin"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{copiedLink ? 'Đã sao chép link' : 'Copy link Admin'}</span>
                <span className="sm:hidden">Link</span>
              </button>

              {/* Change Password Button */}
              <button
                onClick={() => setChangePassOpen(true)}
                className="flex items-center gap-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 px-3 py-1.5 rounded-sm text-xs font-bold transition-colors cursor-pointer"
                title="Đổi mật khẩu trang Admin"
              >
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline">Đổi mật khẩu</span>
              </button>

              {/* View Storefront Link */}
              <button
                onClick={onExitAdmin}
                className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-black px-3 sm:px-4 py-1.5 rounded-sm text-xs font-black uppercase tracking-wider transition-all shadow-md cursor-pointer"
              >
                <Store className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Về Cửa Hàng</span>
                <span className="sm:hidden">Cửa hàng</span>
                <ExternalLink className="w-3 h-3 ml-0.5 opacity-70" />
              </button>

              {/* Logout Button */}
              <button
                onClick={handleLogout}
                className="p-1.5 text-neutral-400 hover:text-rose-400 transition-colors cursor-pointer"
                title="Đăng xuất khỏi Admin"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 sm:gap-4 -mb-px overflow-x-auto text-xs font-bold pt-1">
            <button
              onClick={() => setActiveTab('products')}
              className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'products'
                  ? 'border-amber-400 text-amber-400'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Quản Lý Sản Phẩm & Hình Ảnh ({products.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'orders'
                  ? 'border-amber-400 text-amber-400'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Quản Lý Đơn Hàng ({orders.length})</span>
              {pendingOrders > 0 && (
                <span className="w-4 h-4 rounded-full bg-amber-400 text-black text-[10px] font-black flex items-center justify-center">
                  {pendingOrders}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('vouchers')}
              className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'vouchers'
                  ? 'border-amber-400 text-amber-400'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Tag className="w-4 h-4" />
              <span>Mã Giảm Giá & Voucher ({vouchers.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('marketing')}
              className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'marketing'
                  ? 'border-amber-400 text-amber-400'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Banners, Ngân Hàng & Nội Dung Web</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Body Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        
        {/* Quick Stats Bar */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Tổng sản phẩm</p>
              <h2 className="text-xl sm:text-2xl font-black text-neutral-900 font-mono mt-0.5">{totalProducts}</h2>
              <p className="text-[11px] text-emerald-600 font-medium">Đang mở bán online</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-neutral-100 flex items-center justify-center text-neutral-800">
              <Package className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Tổng kho tồn</p>
              <h2 className="text-xl sm:text-2xl font-black text-neutral-900 font-mono mt-0.5">{totalStock} <span className="text-xs font-normal text-neutral-500">sp</span></h2>
              <p className="text-[11px] text-neutral-500">Đầy đủ các size S - XXL</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
              <Box className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Đơn hàng mới</p>
              <h2 className="text-xl sm:text-2xl font-black text-neutral-900 font-mono mt-0.5">{orders.length} <span className="text-xs font-normal text-neutral-500">đơn</span></h2>
              <p className="text-[11px] text-amber-600 font-medium">{pendingOrders} đơn cần xử lý</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-amber-50 flex items-center justify-center text-amber-600">
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Doanh thu tạm tính</p>
              <h2 className="text-lg sm:text-xl font-black text-neutral-900 font-mono mt-0.5">
                {totalRevenue.toLocaleString('vi-VN')} đ
              </h2>
              <p className="text-[11px] text-emerald-600 font-medium">Từ các đơn hoàn tất</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* TAB 1: PRODUCT MANAGEMENT */}
        {activeTab === 'products' && (
          <div className="space-y-4">
            
            {/* Top Toolbar: Search, Filters & Add Product */}
            <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              
              {/* Search Bar */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Tìm theo tên, mã SKU, chất liệu vải..."
                  className="w-full pl-9 pr-4 py-2 bg-neutral-50 border border-neutral-200 rounded-sm text-xs focus:outline-none focus:border-neutral-900 focus:bg-white transition-all"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-black cursor-pointer text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Filter Selects */}
              <div className="flex items-center gap-2 overflow-x-auto">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-sm text-xs font-medium focus:outline-none focus:border-neutral-900 cursor-pointer"
                >
                  <option value="all">Tất cả danh mục ({products.length})</option>
                  {CATEGORY_OPTIONS.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>

                <select
                  value={selectedCollection}
                  onChange={(e) => setSelectedCollection(e.target.value)}
                  className="px-3 py-2 bg-neutral-50 border border-neutral-200 rounded-sm text-xs font-medium focus:outline-none focus:border-neutral-900 cursor-pointer"
                >
                  <option value="all">Tất cả bộ sưu tập</option>
                  {COLLECTION_OPTIONS.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>

                {/* Add New Product Button */}
                <button
                  onClick={handleOpenCreateNew}
                  className="flex items-center gap-1.5 bg-neutral-950 hover:bg-black text-white px-4 py-2 rounded-sm text-xs font-black uppercase tracking-wider transition-all shadow-xs cursor-pointer whitespace-nowrap"
                >
                  <Plus className="w-4 h-4 text-amber-400" />
                  <span>Thêm Sản Phẩm Mới</span>
                </button>
              </div>
            </div>

            {/* Products Table List */}
            <div className="bg-white rounded-sm border border-neutral-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-neutral-100/70 border-b border-neutral-200 text-neutral-600 font-extrabold uppercase tracking-wider text-[11px]">
                      <th className="py-3 px-4">Ảnh & Sản phẩm</th>
                      <th className="py-3 px-3">Mã SKU</th>
                      <th className="py-3 px-3">Phân loại & BST</th>
                      <th className="py-3 px-3">Giá bán</th>
                      <th className="py-3 px-3">Màu sắc & Ảnh</th>
                      <th className="py-3 px-3">Tồn kho các size</th>
                      <th className="py-3 px-3">Nhãn</th>
                      <th className="py-3 px-4 text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-200">
                    {filteredProducts.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="text-center py-12 text-neutral-500">
                          <Package className="w-8 h-8 mx-auto mb-2 text-neutral-300" />
                          <p className="font-bold">Không tìm thấy sản phẩm nào phù hợp</p>
                          <p className="text-[11px] text-neutral-400 mt-0.5">Thử xóa bộ lọc hoặc tìm kiếm từ khóa khác</p>
                        </td>
                      </tr>
                    ) : (
                      filteredProducts.map((product) => {
                        const mainColor = product.colors[0] || { image: '', name: 'Default', hex: '#000' };
                        const values = Object.values(product.inStockSizes || {}) as number[];
                        const stockSum: number = values.reduce((s: number, n: number) => s + (Number(n) || 0), 0);

                        return (
                          <tr key={product.id} className="hover:bg-neutral-50/80 transition-colors">
                            {/* Product Image & Name */}
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-12 h-14 rounded-xs overflow-hidden bg-neutral-100 border border-neutral-200 shrink-0 relative group">
                                  <img
                                    src={mainColor.image}
                                    alt={product.name}
                                    className="w-full h-full object-cover object-center"
                                  />
                                </div>
                                <div className="max-w-[220px]">
                                  <h3 className="font-bold text-neutral-900 line-clamp-1 hover:text-amber-600 transition-colors">
                                    {product.name}
                                  </h3>
                                  <p className="text-[10px] text-neutral-500 line-clamp-1 mt-0.5">
                                    {product.material} • {product.gsm}
                                  </p>
                                </div>
                              </div>
                            </td>

                            {/* SKU Code */}
                            <td className="py-3 px-3 font-mono font-bold text-neutral-700 text-[11px]">
                              {product.code}
                            </td>

                            {/* Category & Collection */}
                            <td className="py-3 px-3">
                              <span className="inline-block px-1.5 py-0.5 bg-neutral-100 text-neutral-800 rounded-xs text-[10px] font-bold uppercase mb-0.5">
                                {CATEGORY_OPTIONS.find(c => c.value === product.category)?.label.split(' ')[0] || product.category}
                              </span>
                              <p className="text-[10px] text-neutral-500 truncate max-w-[120px]">
                                {COLLECTIONS.find(col => col.slug === product.collection)?.name || product.collection}
                              </p>
                            </td>

                            {/* Price */}
                            <td className="py-3 px-3 font-mono">
                              <div className="font-bold text-neutral-900">
                                {product.price.toLocaleString('vi-VN')} đ
                              </div>
                              {product.originalPrice && product.originalPrice > product.price && (
                                <div className="text-[10px] text-neutral-400 line-through">
                                  {product.originalPrice.toLocaleString('vi-VN')} đ
                                </div>
                              )}
                            </td>

                            {/* Colors & Gallery */}
                            <td className="py-3 px-3">
                              <div className="flex items-center gap-1.5">
                                {product.colors.map((c, idx) => (
                                  <div
                                    key={idx}
                                    className="w-4 h-4 rounded-full border border-neutral-300 shadow-2xs"
                                    style={{ backgroundColor: c.hex }}
                                    title={`${c.name} (${c.gallery?.length || 1} ảnh)`}
                                  />
                                ))}
                                <span className="text-[10px] text-neutral-400 font-mono">
                                  ({product.colors.length} màu)
                                </span>
                              </div>
                            </td>

                            {/* In Stock by Size */}
                            <td className="py-3 px-3 font-mono">
                              <div className="flex items-center gap-1 text-[10px]">
                                {Object.entries(product.inStockSizes || {}).map(([sz, qty]) => {
                                  const numQty = Number(qty) || 0;
                                  return (
                                    <span
                                      key={sz}
                                      className={`px-1 py-0.2 rounded-2xs ${
                                        numQty > 0 
                                          ? 'bg-neutral-100 text-neutral-700' 
                                          : 'bg-rose-50 text-rose-400 line-through'
                                      }`}
                                    >
                                      {sz}:{numQty}
                                    </span>
                                  );
                                })}
                              </div>
                              <p className="text-[10px] text-neutral-500 mt-0.5">
                                Tổng kho: <strong className={stockSum < 10 ? 'text-amber-600' : 'text-neutral-800'}>{stockSum}</strong> cái
                              </p>
                            </td>

                            {/* Badges */}
                            <td className="py-3 px-3">
                              <div className="flex flex-wrap gap-1">
                                {product.isNew && (
                                  <span className="text-[9px] font-black uppercase px-1 py-0.2 bg-black text-amber-400 rounded-2xs">
                                    NEW
                                  </span>
                                )}
                                {product.isBestSeller && (
                                  <span className="text-[9px] font-black uppercase px-1 py-0.2 bg-amber-400 text-black rounded-2xs">
                                    HOT
                                  </span>
                                )}
                                {product.isLimited && (
                                  <span className="text-[9px] font-black uppercase px-1 py-0.2 bg-neutral-800 text-white rounded-2xs">
                                    LTD
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* Actions: Edit, Preview, Duplicate, Delete */}
                            <td className="py-3 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                
                                {/* Quick Preview Button */}
                                <button
                                  onClick={() => onQuickView(product)}
                                  className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-xs transition-colors cursor-pointer"
                                  title="Xem giao diện Quick View"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>

                                {/* Edit Product Button */}
                                <button
                                  onClick={() => {
                                    setIsCreatingNew(false);
                                    setEditingProduct(JSON.parse(JSON.stringify(product)));
                                  }}
                                  className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-xs transition-colors cursor-pointer flex items-center gap-1 font-bold text-xs"
                                  title="Chỉnh sửa chi tiết & ảnh sản phẩm"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                  <span className="hidden xl:inline">Sửa</span>
                                </button>

                                {/* Duplicate Product Button */}
                                <button
                                  onClick={() => handleDuplicateProduct(product)}
                                  className="p-1.5 text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 rounded-xs transition-colors cursor-pointer"
                                  title="Nhân bản sản phẩm"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>

                                {/* Delete Product Button */}
                                <button
                                  onClick={() => handleDeleteProduct(product.id, product.name)}
                                  className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-xs transition-colors cursor-pointer"
                                  title="Xóa sản phẩm"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
              
              {/* Table Footer */}
              <div className="p-3 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between text-xs text-neutral-500">
                <span>Hiển thị <strong>{filteredProducts.length}</strong> / <strong>{products.length}</strong> sản phẩm</span>
                <button
                  onClick={() => {
                    if (window.confirm('Khôi phục danh mục sản phẩm về dữ liệu mặc định ban đầu?')) {
                      onResetToDefault();
                      showAdminToast('Đã khôi phục dữ liệu sản phẩm gốc thành công!');
                    }
                  }}
                  className="flex items-center gap-1 text-neutral-500 hover:text-rose-600 font-bold transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Khôi phục dữ liệu gốc</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ORDERS MANAGEMENT */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-extrabold uppercase font-heading tracking-wide">
                  DANH SÁCH ĐƠN HÀNG TRỰC TUYẾN
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Quản lý và cập nhật tiến độ vận chuyển đơn hàng từ khách
                </p>
              </div>
              <span className="text-xs font-mono bg-neutral-100 px-3 py-1.5 rounded-sm font-bold">
                Tổng cộng: {orders.length} đơn
              </span>
            </div>

            {orders.length === 0 ? (
              <div className="bg-white p-12 text-center rounded-sm border border-neutral-200 shadow-xs">
                <ShoppingBag className="w-10 h-10 mx-auto mb-3 text-neutral-300" />
                <h3 className="text-base font-bold text-neutral-800">Chưa có đơn hàng nào</h3>
                <p className="text-xs text-neutral-500 max-w-md mx-auto mt-1">
                  Khi khách hàng đặt hàng trên Storefront, đơn hàng sẽ lập tức xuất hiện tại đây để xử lý.
                </p>
                <button
                  onClick={onExitAdmin}
                  className="mt-4 inline-flex items-center gap-1.5 bg-neutral-900 text-white px-4 py-2 rounded-sm text-xs font-bold uppercase tracking-wider"
                >
                  <span>Mở Storefront đặt thử nghiệm</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {orders.map((order) => (
                  <div key={order.orderId} className="bg-white rounded-sm border border-neutral-200 shadow-xs p-4 sm:p-5 space-y-4">
                    
                    {/* Order Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-neutral-100 gap-2">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-neutral-900 text-white flex items-center justify-center font-mono font-bold text-xs">
                          #
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-black text-sm text-neutral-900">{order.orderId}</span>
                            <span className="text-[11px] text-neutral-400 font-mono">
                              {new Date(order.createdAt).toLocaleString('vi-VN')}
                            </span>
                          </div>
                          <p className="text-xs text-neutral-600 font-bold flex items-center gap-2 mt-0.5">
                            <span>{order.customerName}</span>
                            <span>•</span>
                            <span className="font-mono">{order.phone}</span>
                          </p>
                        </div>
                      </div>

                      {/* Status Selector */}
                      <div className="flex items-center gap-2">
                        <label className="text-xs font-bold text-neutral-500">Trạng thái:</label>
                        <select
                          value={order.status}
                          onChange={(e) => onUpdateOrderStatus(order.orderId, e.target.value as OrderInfo['status'])}
                          className={`text-xs font-bold px-3 py-1.5 rounded-sm border cursor-pointer focus:outline-none ${
                            order.status === 'delivered' 
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                              : order.status === 'shipping'
                              ? 'bg-blue-50 text-blue-700 border-blue-200'
                              : order.status === 'packing'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-neutral-100 text-neutral-800 border-neutral-300'
                          }`}
                        >
                          <option value="confirmed">Đã xác nhận</option>
                          <option value="packing">Đang đóng gói</option>
                          <option value="shipping">Đang giao hàng</option>
                          <option value="delivered">Đã giao thành công</option>
                        </select>

                        <button
                          onClick={() => {
                            if (window.confirm(`Xóa đơn hàng ${order.orderId}?`)) {
                              onDeleteOrder(order.orderId);
                              showAdminToast(`Đã xóa đơn ${order.orderId}`);
                            }
                          }}
                          className="p-1.5 text-neutral-400 hover:text-rose-600 rounded-xs transition-colors cursor-pointer"
                          title="Xóa đơn hàng"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Customer Delivery Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-neutral-50 p-3 rounded-xs">
                      <div>
                        <p className="text-neutral-500 font-bold flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-amber-600" />
                          <span>Địa chỉ giao hàng:</span>
                        </p>
                        <p className="text-neutral-900 font-medium mt-0.5">
                          {order.address}, {order.district}, {order.city}
                        </p>
                        {order.note && (
                          <p className="text-[11px] text-amber-800 italic mt-1 bg-amber-100/50 p-1.5 rounded-2xs">
                            Ghi chú: {order.note}
                          </p>
                        )}
                      </div>

                      <div className="space-y-1">
                        <p className="text-neutral-500 font-bold flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-amber-600" />
                          <span>Thanh toán & Liên hệ:</span>
                        </p>
                        <p className="text-neutral-900">
                          Hình thức: <span className="font-bold uppercase font-mono">{order.paymentMethod}</span>
                          {order.paymentMethod === 'cod' ? ' (Thanh toán khi nhận hàng)' : ' (Đã chuyển khoản/ví điện tử)'}
                        </p>
                        <p className="text-neutral-500 text-[11px]">
                          Email: <span className="font-mono text-neutral-800">{order.email || 'Không cung cấp'}</span>
                        </p>
                      </div>
                    </div>

                    {/* Items Purchased List */}
                    <div className="space-y-2">
                      <p className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider">
                        Sản phẩm đã mua ({order.items.length} món):
                      </p>
                      <div className="divide-y divide-neutral-100">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="py-2 flex items-center justify-between text-xs gap-3">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={item.selectedColor.image}
                                alt={item.product.name}
                                className="w-10 h-12 object-cover rounded-2xs border border-neutral-200"
                              />
                              <div>
                                <h4 className="font-bold text-neutral-900">{item.product.name}</h4>
                                <p className="text-[11px] text-neutral-500">
                                  Màu: {item.selectedColor.name} • Size: <strong className="text-neutral-900">{item.selectedSize}</strong> • SL: <strong>x{item.quantity}</strong>
                                </p>
                              </div>
                            </div>
                            <div className="font-mono font-bold text-neutral-900">
                              {(item.product.price * item.quantity).toLocaleString('vi-VN')} đ
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Financial Summary */}
                    <div className="pt-3 border-t border-neutral-100 flex flex-wrap items-center justify-between text-xs font-mono">
                      <div className="text-neutral-500 flex items-center gap-3 text-[11px]">
                        <span>Tạm tính: {order.subtotal?.toLocaleString('vi-VN')} đ</span>
                        {order.discount > 0 && <span className="text-emerald-600">- Giảm giá: {order.discount?.toLocaleString('vi-VN')} đ</span>}
                        <span>Phí ship: {order.shippingFee === 0 ? 'Miễn phí' : `${order.shippingFee?.toLocaleString('vi-VN')} đ`}</span>
                      </div>
                      <div className="text-sm font-black text-neutral-950">
                        Tổng thanh toán: <span className="text-base text-amber-600">{order.total?.toLocaleString('vi-VN')} đ</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: VOUCHERS MANAGEMENT */}
        {activeTab === 'vouchers' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs flex items-center justify-between">
              <div>
                <h2 className="text-base font-extrabold uppercase font-heading tracking-wide">
                  MÃ ƯU ĐÃI & KHUYẾN MẠI
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Tạo và quản lý các mã giảm giá áp dụng tự động cho giỏ hàng
                </p>
              </div>
              <button
                onClick={() => {
                  const code = prompt('Nhập mã voucher mới (ví dụ: BONG10K, STREET2026):')?.toUpperCase();
                  if (!code) return;
                  const discountPercent = Number(prompt('Nhập phần trăm giảm giá (%) (ví dụ: 10, 15, 20):', '10')) || 10;
                  const newVoucher: Voucher = {
                    code,
                    description: `Giảm ${discountPercent}% cho tất cả đơn hàng Bông Store`,
                    discountPercent,
                    minOrderValue: 300000,
                    badge: `GIẢM ${discountPercent}%`,
                  };
                  onSaveVouchers([...vouchers, newVoucher]);
                  showAdminToast(`Đã thêm mã ưu đãi ${code}!`);
                }}
                className="flex items-center gap-1.5 bg-neutral-950 text-white px-3 py-1.5 rounded-sm text-xs font-bold uppercase tracking-wider hover:bg-black transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4 text-amber-400" />
                <span>Tạo mã mới</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {vouchers.map((v) => (
                <div key={v.code} className="bg-white p-4 rounded-sm border border-neutral-200 shadow-xs relative overflow-hidden space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-black text-sm bg-amber-400 text-black px-2 py-0.5 rounded-2xs">
                      {v.code}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                      {v.badge}
                    </span>
                  </div>

                  <p className="text-xs text-neutral-700 font-medium">{v.description}</p>

                  <div className="text-[11px] text-neutral-500 font-mono pt-2 border-t border-neutral-100 flex items-center justify-between">
                    <span>Đơn tối thiểu: {(v.minOrderValue || 0).toLocaleString('vi-VN')} đ</span>
                    <button
                      onClick={() => {
                        if (window.confirm(`Xóa mã ưu đãi ${v.code}?`)) {
                          onSaveVouchers(vouchers.filter(item => item.code !== v.code));
                          showAdminToast(`Đã xóa voucher ${v.code}`);
                        }
                      }}
                      className="text-rose-500 hover:text-rose-700 font-bold transition-colors cursor-pointer"
                    >
                      Xóa
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: MARKETING, BANNERS & SITE CONTENT */}
        {activeTab === 'marketing' && (
          <AdminSiteSettingsManager
            siteSettings={siteSettings}
            onSaveSiteSettings={onSaveSiteSettings}
            heroSlides={heroSlides}
            onSaveHeroSlides={onSaveHeroSlides}
            categoryShowcase={categoryShowcase}
            onSaveCategoryShowcase={onSaveCategoryShowcase}
            lookbooks={lookbooks}
            onSaveLookbooks={onSaveLookbooks}
            showToast={showAdminToast}
          />
        )}

      </main>

      {/* EDIT PRODUCT MODAL (COMPREHENSIVE PRODUCT EDITOR) */}
      {editingProduct && (
        <ProductEditorModal
          product={editingProduct}
          isNew={isCreatingNew}
          onClose={() => {
            setEditingProduct(null);
            setIsCreatingNew(false);
          }}
          onSave={handleSaveProductForm}
          showToast={showAdminToast}
        />
      )}

      {/* Change Password Modal */}
      {changePassOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="relative w-full max-w-md bg-neutral-900 text-white rounded-sm shadow-2xl overflow-hidden border border-neutral-800 animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 sm:p-5 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-400" />
                <h3 className="font-black uppercase text-sm font-heading tracking-wider">
                  ĐỔI MẬT KHẨU QUẢN TRỊ ADMIN
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setChangePassOpen(false);
                  setPassChangeSuccess('');
                }}
                className="text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="p-5 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Mật khẩu mới
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Nhập mật khẩu mới (tối thiểu 4 ký tự)..."
                  required
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-sm text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300 mb-1.5">
                  Xác nhận lại mật khẩu mới
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Nhập lại mật khẩu mới..."
                  required
                  className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-sm text-sm text-white focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              {passChangeSuccess && (
                <p className={`text-xs ${passChangeSuccess.includes('thành công') ? 'text-emerald-400' : 'text-rose-400'} font-medium`}>
                  {passChangeSuccess}
                </p>
              )}

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setChangePassOpen(false);
                    setPassChangeSuccess('');
                  }}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-sm text-xs font-bold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-400 hover:bg-amber-300 text-black font-black uppercase text-xs rounded-sm tracking-wider shadow-md"
                >
                  Cập Nhật Mật Khẩu
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Global Admin Toast */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-neutral-950 text-white px-5 py-3 rounded-sm shadow-2xl text-xs font-bold border border-neutral-800 flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

    </div>
  );
};

// ==========================================
// SUB-COMPONENT: SINGLE DEVICE IMAGE UPLOADER
// ==========================================
interface DeviceSingleImageUploaderProps {
  label: string;
  badge: string;
  imageUrl: string;
  onUpload: (file: File) => void;
  onRemove: () => void;
  onOpenPresets?: () => void;
  isUploading?: boolean;
}

const DeviceSingleImageUploader: React.FC<DeviceSingleImageUploaderProps> = ({
  label,
  badge,
  imageUrl,
  onUpload,
  onRemove,
  onOpenPresets,
  isUploading,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUpload(e.target.files[0]);
      e.target.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onUpload(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="font-bold text-neutral-800 flex items-center gap-1.5 text-xs">
          <Upload className="w-3.5 h-3.5 text-amber-600" />
          <span>{label}</span>
        </label>
        {onOpenPresets && (
          <button
            type="button"
            onClick={onOpenPresets}
            className="text-[11px] text-amber-700 hover:text-amber-900 font-bold underline cursor-pointer"
          >
            Mẫu có sẵn
          </button>
        )}
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Upload Zone & Preview Box */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        className={`relative w-full rounded-sm border-2 transition-all overflow-hidden flex flex-col items-center justify-center ${
          isDragOver
            ? 'border-amber-500 bg-amber-50/60 ring-2 ring-amber-400/30'
            : imageUrl
            ? 'border-neutral-300 bg-neutral-900'
            : 'border-dashed border-neutral-300 bg-white hover:border-neutral-700 hover:bg-neutral-50'
        } min-h-[200px] p-2.5 text-center`}
      >
        {imageUrl ? (
          <div className="relative w-full h-48 rounded-xs overflow-hidden bg-neutral-900 group">
            <img
              src={imageUrl}
              alt={label}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            />
            <span className="absolute top-2 left-2 bg-black/80 text-white text-[10px] font-bold px-2 py-0.5 rounded-2xs backdrop-blur-xs">
              {badge}
            </span>

            {/* Hover Action Overlay */}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-3">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full max-w-[200px] py-2 bg-amber-400 hover:bg-amber-300 text-black text-xs font-black uppercase rounded-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
              >
                <FolderUp className="w-4 h-4" />
                <span>Đổi Ảnh Máy Tính / ĐT</span>
              </button>
              <button
                type="button"
                onClick={onRemove}
                className="w-full max-w-[200px] py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Xóa Ảnh Này</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="py-5 px-3 space-y-2.5 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
              <UploadCloud className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-800">
                Kéo thả file ảnh vào đây hoặc bấm nút dưới
              </p>
              <p className="text-[10px] text-neutral-500 mt-1 max-w-xs">
                Tải ảnh trực tiếp từ Máy tính hoặc Album ảnh / Camera trên Điện thoại
              </p>
            </div>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="mt-1 px-4 py-2 bg-neutral-900 hover:bg-black text-amber-400 text-xs font-black uppercase tracking-wider rounded-sm inline-flex items-center gap-2 shadow-sm cursor-pointer"
            >
              <Laptop className="w-3.5 h-3.5" />
              <Smartphone className="w-3.5 h-3.5" />
              <span>Tải Ảnh Từ Thiết Bị</span>
            </button>
          </div>
        )}
      </div>

      {/* Quick Action Footer */}
      {imageUrl && (
        <div className="flex items-center justify-between pt-1 text-xs">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="text-[11px] font-bold text-neutral-700 hover:text-black flex items-center gap-1 cursor-pointer"
          >
            <FolderUp className="w-3.5 h-3.5 text-amber-600" />
            <span>Chọn ảnh khác từ máy tính / điện thoại</span>
          </button>
          <button
            type="button"
            onClick={onRemove}
            className="text-[11px] font-bold text-rose-600 hover:text-rose-800 flex items-center gap-1 cursor-pointer"
          >
            <Trash2 className="w-3 h-3" />
            <span>Xóa ảnh</span>
          </button>
        </div>
      )}
    </div>
  );
};

// ==========================================
// SUB-COMPONENT: MULTI-IMAGE GALLERY UPLOADER
// ==========================================
interface DeviceGalleryUploaderProps {
  gallery: string[];
  onUploadFiles: (files: FileList | File[]) => void;
  onRemoveImage: (index: number) => void;
  onOpenPresets?: () => void;
}

const DeviceGalleryUploader: React.FC<DeviceGalleryUploaderProps> = ({
  gallery,
  onUploadFiles,
  onRemoveImage,
  onOpenPresets,
}) => {
  const multiFileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onUploadFiles(e.target.files);
      e.target.value = '';
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onUploadFiles(e.dataTransfer.files);
    }
  };

  return (
    <div className="space-y-3 pt-2">
      <div className="flex items-center justify-between">
        <label className="font-bold text-neutral-800 flex items-center gap-1.5 text-xs">
          <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
          <span>Bộ sưu tập ảnh chi tiết (Đã tải {gallery?.length || 0} ảnh)</span>
        </label>
        {onOpenPresets && (
          <button
            type="button"
            onClick={onOpenPresets}
            className="text-[11px] text-amber-700 hover:text-amber-900 font-bold underline cursor-pointer"
          >
            Mẫu có sẵn
          </button>
        )}
      </div>

      <input
        type="file"
        ref={multiFileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        multiple
        className="hidden"
      />

      {/* Drag & Drop Upload Zone for Multiple Files */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-sm p-4 text-center transition-all ${
          isDragOver
            ? 'border-amber-500 bg-amber-50/60 ring-2 ring-amber-400/30'
            : 'border-neutral-300 bg-white hover:border-neutral-700'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-neutral-800">
                Tải ảnh chi tiết từ Thiết Bị (Máy tính / Điện thoại)
              </p>
              <p className="text-[10px] text-neutral-500">
                Có thể chọn cùng lúc nhiều ảnh từ thư viện ảnh hoặc kéo thả nhiều file vào đây
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => multiFileInputRef.current?.click()}
            className="px-4 py-2.5 bg-neutral-900 hover:bg-black text-amber-400 text-xs font-black uppercase rounded-sm flex items-center gap-2 shrink-0 cursor-pointer shadow-sm"
          >
            <Laptop className="w-3.5 h-3.5" />
            <Smartphone className="w-3.5 h-3.5" />
            <span>Chọn Nhiều Ảnh Từ Thiết Bị</span>
          </button>
        </div>
      </div>

      {/* Gallery Thumbnail Grid */}
      {gallery && gallery.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2.5 pt-1">
          {gallery.map((imgUrl, gIdx) => (
            <div
              key={gIdx}
              className="relative group rounded-sm overflow-hidden border border-neutral-300 h-24 bg-neutral-900 shadow-xs"
            >
              <img
                src={imgUrl}
                alt={`Chi tiết ${gIdx + 1}`}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
              />
              <span className="absolute bottom-1 left-1 bg-black/75 text-white text-[9px] font-mono px-1.5 py-0.2 rounded-2xs">
                #{gIdx + 1}
              </span>
              <button
                type="button"
                onClick={() => onRemoveImage(gIdx)}
                className="absolute top-1 right-1 w-5 h-5 bg-rose-600 hover:bg-rose-500 text-white rounded-full flex items-center justify-center opacity-90 hover:opacity-100 transition-opacity cursor-pointer text-xs shadow-md"
                title="Xóa ảnh này"
              >
                ✕
              </button>
            </div>
          ))}

          {/* Quick Add More Tile */}
          <button
            type="button"
            onClick={() => multiFileInputRef.current?.click()}
            className="h-24 border-2 border-dashed border-neutral-300 hover:border-neutral-900 rounded-sm flex flex-col items-center justify-center text-neutral-600 hover:text-neutral-900 transition-colors cursor-pointer bg-white"
          >
            <Plus className="w-5 h-5 text-amber-600" />
            <span className="text-[10px] font-bold mt-1">+ Thêm Ảnh</span>
          </button>
        </div>
      )}
    </div>
  );
};

// ==========================================
// SUB-COMPONENT: PRODUCT EDITOR MODAL
// ==========================================
interface ProductEditorModalProps {
  product: Product;
  isNew: boolean;
  onClose: () => void;
  onSave: (product: Product) => void;
  showToast: (msg: string) => void;
}

const ProductEditorModal: React.FC<ProductEditorModalProps> = ({
  product,
  isNew,
  onClose,
  onSave,
  showToast,
}) => {
  const [formData, setFormData] = useState<Product>(JSON.parse(JSON.stringify(product)));
  const [activeColorTab, setActiveColorTab] = useState<number>(0);
  const [presetPickerOpen, setPresetPickerOpen] = useState(false);
  const [targetFieldForPreset, setTargetFieldForPreset] = useState<{ colorIndex: number; field: 'image' | 'secondary' | 'gallery' } | null>(null);

  const [isUploading, setIsUploading] = useState<boolean>(false);

  // Field updates
  const handleFieldChange = (field: keyof Product, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  // Color updates
  const handleColorChange = (index: number, field: keyof ProductColor, value: any) => {
    const newColors = [...formData.colors];
    newColors[index] = { ...newColors[index], [field]: value };
    setFormData((prev) => ({ ...prev, colors: newColors }));
  };

  // Upload single image from device (computer or phone)
  const handleDeviceUploadSingle = async (
    colorIdx: number,
    field: 'image' | 'secondaryImage',
    file: File
  ) => {
    try {
      setIsUploading(true);
      const dataUrl = await processDeviceImage(file);
      handleColorChange(colorIdx, field, dataUrl);
      showToast(`Đã tải ảnh lên thành công từ thiết bị!`);
    } catch (err: any) {
      alert(err.message || 'Lỗi khi đọc file ảnh từ thiết bị');
    } finally {
      setIsUploading(false);
    }
  };

  // Upload multiple gallery images from device
  const handleDeviceUploadGallery = async (colorIdx: number, files: FileList | File[]) => {
    try {
      setIsUploading(true);
      const fileArray = Array.from(files);
      const newUrls: string[] = [];

      for (const file of fileArray) {
        if (file.type.startsWith('image/')) {
          const dataUrl = await processDeviceImage(file);
          newUrls.push(dataUrl);
        }
      }

      if (newUrls.length > 0) {
        const newColors = [...formData.colors];
        const curGallery = newColors[colorIdx].gallery || [];
        newColors[colorIdx].gallery = [...curGallery, ...newUrls];
        setFormData((prev) => ({ ...prev, colors: newColors }));
        showToast(`Đã tải ${newUrls.length} ảnh vào bộ sưu tập!`);
      }
    } catch (err: any) {
      alert(err.message || 'Lỗi khi tải ảnh từ thiết bị');
    } finally {
      setIsUploading(false);
    }
  };

  // Add new colorway
  const handleAddColor = () => {
    const newColor: ProductColor = {
      name: 'Màu mới',
      hex: '#2B2B2B',
      image: PRESET_IMAGES[0].url,
      secondaryImage: PRESET_IMAGES[1].url,
      gallery: [PRESET_IMAGES[0].url, PRESET_IMAGES[1].url],
    };
    setFormData((prev) => ({ ...prev, colors: [...prev.colors, newColor] }));
    setActiveColorTab(formData.colors.length);
  };

  // Remove colorway
  const handleRemoveColor = (index: number) => {
    if (formData.colors.length <= 1) {
      alert('Sản phẩm cần ít nhất một màu sắc!');
      return;
    }
    const newColors = formData.colors.filter((_, i) => i !== index);
    setFormData((prev) => ({ ...prev, colors: newColors }));
    setActiveColorTab(Math.max(0, index - 1));
  };

  // Gallery URL add
  const handleAddGalleryUrl = (colorIdx: number, url: string) => {
    if (!url.trim()) return;
    const newColors = [...formData.colors];
    const curGallery = newColors[colorIdx].gallery || [];
    newColors[colorIdx].gallery = [...curGallery, url.trim()];
    setFormData((prev) => ({ ...prev, colors: newColors }));
  };

  // Gallery URL remove
  const handleRemoveGalleryUrl = (colorIdx: number, imgIdx: number) => {
    const newColors = [...formData.colors];
    newColors[colorIdx].gallery = newColors[colorIdx].gallery.filter((_, i) => i !== imgIdx);
    setFormData((prev) => ({ ...prev, colors: newColors }));
  };

  // Stock size updates
  const handleStockChange = (size: ProductSize, value: number) => {
    const qty = Math.max(0, isNaN(value) ? 0 : value);
    setFormData((prev) => ({
      ...prev,
      inStockSizes: {
        ...prev.inStockSizes,
        [size]: qty,
      },
    }));
  };

  // Features list
  const handleFeatureChange = (index: number, val: string) => {
    const newFeatures = [...(formData.features || [])];
    newFeatures[index] = val;
    setFormData((prev) => ({ ...prev, features: newFeatures }));
  };

  const handleAddFeature = () => {
    setFormData((prev) => ({
      ...prev,
      features: [...(prev.features || []), 'Đặc điểm thiết kế mới'],
    }));
  };

  const handleRemoveFeature = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      features: (prev.features || []).filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert('Vui lòng nhập tên sản phẩm!');
      return;
    }
    if (!formData.code.trim()) {
      alert('Vui lòng nhập mã sản phẩm SKU!');
      return;
    }
    if (formData.colors.length === 0) {
      alert('Vui lòng thêm ít nhất 1 màu cho sản phẩm!');
      return;
    }
    onSave(formData);
  };

  const currentColor = formData.colors[activeColorTab] || formData.colors[0];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="relative w-full max-w-4xl bg-white rounded-sm shadow-2xl overflow-hidden z-10 border border-neutral-300 my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[94vh] flex flex-col">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-sm bg-amber-400 text-black flex items-center justify-center font-bold">
              <Edit3 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider">
                {isNew ? 'THÊM MỚI SẢN PHẨM STREETWEAR' : 'CHỈNH SỬA CHI TIẾT & HÌNH ẢNH SẢN PHẨM'}
              </h2>
              <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase">
                MÃ SKU: {formData.code} • BÔNG STORE
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          
          {/* SECTION 1: BASIC INFORMATION */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-neutral-900 border-b pb-2 flex items-center gap-2">
              <Package className="w-4 h-4 text-amber-500" />
              <span>1. Thông Tin Cơ Bản & Giá Bán</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* Product Name */}
              <div className="sm:col-span-2 space-y-1">
                <label className="font-bold text-neutral-700">Tên sản phẩm *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => handleFieldChange('name', e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                />
              </div>

              {/* SKU Code */}
              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Mã SKU / Code *</label>
                <input
                  type="text"
                  required
                  value={formData.code}
                  onChange={(e) => handleFieldChange('code', e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                />
              </div>

              {/* Price */}
              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Giá bán (VNĐ) *</label>
                <input
                  type="number"
                  required
                  min={0}
                  step={10000}
                  value={formData.price}
                  onChange={(e) => handleFieldChange('price', Number(e.target.value))}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono font-bold text-neutral-900 focus:bg-white focus:outline-none focus:border-neutral-900"
                />
              </div>

              {/* Original Price */}
              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Giá gốc niêm yết (VNĐ)</label>
                <input
                  type="number"
                  min={0}
                  step={10000}
                  value={formData.originalPrice || ''}
                  onChange={(e) => handleFieldChange('originalPrice', e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-mono text-neutral-600 focus:bg-white focus:outline-none focus:border-neutral-900"
                  placeholder="Để tính % giảm giá"
                />
              </div>

              {/* Category */}
              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Danh mục sản phẩm</label>
                <select
                  value={formData.category}
                  onChange={(e) => handleFieldChange('category', e.target.value as ProductCategory)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-medium focus:bg-white focus:outline-none focus:border-neutral-900 cursor-pointer"
                >
                  {CATEGORY_OPTIONS.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>
              </div>

              {/* Collection */}
              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Bộ sưu tập</label>
                <select
                  value={formData.collection}
                  onChange={(e) => handleFieldChange('collection', e.target.value as CollectionSlug)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-medium focus:bg-white focus:outline-none focus:border-neutral-900 cursor-pointer"
                >
                  {COLLECTION_OPTIONS.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>
              </div>

              {/* Badges */}
              <div className="sm:col-span-2 flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-neutral-800">
                  <input
                    type="checkbox"
                    checked={Boolean(formData.isNew)}
                    onChange={(e) => handleFieldChange('isNew', e.target.checked)}
                    className="w-4 h-4 rounded-2xs text-black focus:ring-0"
                  />
                  <span>Hàng mới về (NEW)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold text-neutral-800">
                  <input
                    type="checkbox"
                    checked={Boolean(formData.isBestSeller)}
                    onChange={(e) => handleFieldChange('isBestSeller', e.target.checked)}
                    className="w-4 h-4 rounded-2xs text-black focus:ring-0"
                  />
                  <span>Bán chạy (BEST SELLER)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold text-neutral-800">
                  <input
                    type="checkbox"
                    checked={Boolean(formData.isLimited)}
                    onChange={(e) => handleFieldChange('isLimited', e.target.checked)}
                    className="w-4 h-4 rounded-2xs text-black focus:ring-0"
                  />
                  <span>Giới hạn (LIMITED)</span>
                </label>
              </div>
            </div>
          </div>

          {/* SECTION 2: IMAGES & COLORWAYS (CORE EDITING) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-neutral-900 flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-amber-500" />
                <span>2. Quản Lý Hình Ảnh & Màu Sắc Sản Phẩm ({formData.colors.length} màu)</span>
              </h3>
              <button
                type="button"
                onClick={handleAddColor}
                className="flex items-center gap-1 text-[11px] bg-neutral-100 hover:bg-neutral-200 text-neutral-800 px-2.5 py-1 rounded-sm font-bold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Thêm Màu Mới</span>
              </button>
            </div>

            {/* Color Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {formData.colors.map((c, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setActiveColorTab(idx)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-sm text-xs font-bold border transition-all cursor-pointer whitespace-nowrap ${
                    activeColorTab === idx
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : 'bg-neutral-50 text-neutral-600 border-neutral-200 hover:bg-neutral-100'
                  }`}
                >
                  <span
                    className="w-3 h-3 rounded-full border border-white/40"
                    style={{ backgroundColor: c.hex }}
                  />
                  <span>{c.name || `Màu ${idx + 1}`}</span>
                  {formData.colors.length > 1 && (
                    <span
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveColor(idx);
                      }}
                      className="hover:text-rose-400 ml-1 text-xs"
                      title="Xóa màu này"
                    >
                      ✕
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Current Active Color Details */}
            {currentColor && (
              <div className="bg-neutral-50 p-4 rounded-sm border border-neutral-200 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  
                  {/* Color Name */}
                  <div className="space-y-1">
                    <label className="font-bold text-neutral-700">Tên màu sắc (vd: Washed Black)</label>
                    <input
                      type="text"
                      value={currentColor.name}
                      onChange={(e) => handleColorChange(activeColorTab, 'name', e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-sm font-bold text-neutral-900 focus:outline-none focus:border-neutral-900"
                    />
                  </div>

                  {/* Color Hex Picker */}
                  <div className="space-y-1">
                    <label className="font-bold text-neutral-700">Mã màu HEX & Bảng màu</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={currentColor.hex || '#000000'}
                        onChange={(e) => handleColorChange(activeColorTab, 'hex', e.target.value)}
                        className="w-9 h-9 rounded-sm border border-neutral-300 p-0.5 cursor-pointer"
                      />
                      <input
                        type="text"
                        value={currentColor.hex}
                        onChange={(e) => handleColorChange(activeColorTab, 'hex', e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-neutral-300 rounded-sm font-mono text-neutral-900 focus:outline-none focus:border-neutral-900"
                        placeholder="#1E1E20"
                      />
                    </div>
                  </div>
                </div>

                {/* Device Image Uploaders for Primary and Secondary Photos */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  
                  {/* Primary Photo (Uploaded directly from PC/Phone) */}
                  <DeviceSingleImageUploader
                    label="Ảnh chính sản phẩm (Tải từ Thiết bị)"
                    badge="Ảnh đại diện chính"
                    imageUrl={currentColor.image}
                    onUpload={(file) => handleDeviceUploadSingle(activeColorTab, 'image', file)}
                    onRemove={() => handleColorChange(activeColorTab, 'image', '')}
                    onOpenPresets={() => {
                      setTargetFieldForPreset({ colorIndex: activeColorTab, field: 'image' });
                      setPresetPickerOpen(true);
                    }}
                    isUploading={isUploading}
                  />

                  {/* Secondary / Hover Photo (Uploaded directly from PC/Phone) */}
                  <DeviceSingleImageUploader
                    label="Ảnh phụ / Khi hover (Tải từ Thiết bị)"
                    badge="Ảnh đổi khi rê chuột"
                    imageUrl={currentColor.secondaryImage || ''}
                    onUpload={(file) => handleDeviceUploadSingle(activeColorTab, 'secondaryImage', file)}
                    onRemove={() => handleColorChange(activeColorTab, 'secondaryImage', '')}
                    onOpenPresets={() => {
                      setTargetFieldForPreset({ colorIndex: activeColorTab, field: 'secondary' });
                      setPresetPickerOpen(true);
                    }}
                    isUploading={isUploading}
                  />
                </div>

                {/* Color Gallery Array (Uploaded directly from PC/Phone) */}
                <DeviceGalleryUploader
                  gallery={currentColor.gallery || []}
                  onUploadFiles={(files) => handleDeviceUploadGallery(activeColorTab, files)}
                  onRemoveImage={(imgIdx) => handleRemoveGalleryUrl(activeColorTab, imgIdx)}
                  onOpenPresets={() => {
                    setTargetFieldForPreset({ colorIndex: activeColorTab, field: 'gallery' });
                    setPresetPickerOpen(true);
                  }}
                />

              </div>
            )}
          </div>

          {/* SECTION 3: INVENTORY STOCK PER SIZE */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-neutral-900 border-b pb-2 flex items-center gap-2">
              <Box className="w-4 h-4 text-amber-500" />
              <span>3. Quản Lý Tồn Kho Số Lượng Theo Size</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {(['S', 'M', 'L', 'XL', 'XXL'] as ProductSize[]).map((size) => (
                <div key={size} className="bg-neutral-50 p-3 rounded-sm border border-neutral-200 space-y-1">
                  <label className="font-mono font-bold text-xs text-neutral-800 flex items-center justify-between">
                    <span>Size {size}</span>
                    <span className="text-[10px] text-neutral-400">cái</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={formData.inStockSizes?.[size] ?? 0}
                    onChange={(e) => handleStockChange(size, Number(e.target.value))}
                    className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-sm font-mono font-bold text-center text-neutral-900 focus:outline-none focus:border-neutral-900"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* SECTION 4: MATERIAL & SPECS & DESCRIPTION */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-neutral-900 border-b pb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>4. Chất Liệu, Phom Dáng & Mô Tả Chi Tiết</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Chất liệu vải (Material)</label>
                <input
                  type="text"
                  value={formData.material}
                  onChange={(e) => handleFieldChange('material', e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
                  placeholder="vd: 100% Premium Compact Cotton"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Định lượng vải (GSM)</label>
                <input
                  type="text"
                  value={formData.gsm}
                  onChange={(e) => handleFieldChange('gsm', e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
                  placeholder="vd: 260 GSM Heavyweight"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-neutral-700">Phom dáng (Fit)</label>
                <input
                  type="text"
                  value={formData.fit}
                  onChange={(e) => handleFieldChange('fit', e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-medium focus:bg-white focus:outline-none focus:border-neutral-900"
                  placeholder="vd: Boxy Oversized Fit"
                />
              </div>
            </div>

            {/* Detailed Description */}
            <div className="space-y-1">
              <label className="font-bold text-neutral-700">Mô tả chi tiết sản phẩm</label>
              <textarea
                rows={3}
                value={formData.description}
                onChange={(e) => handleFieldChange('description', e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 border border-neutral-300 rounded-sm font-medium focus:bg-white focus:outline-none focus:border-neutral-900 leading-relaxed"
                placeholder="Nhập giới thiệu câu chuyện, đặc điểm thiết kế và phong cách phối..."
              />
            </div>

            {/* Bullet Features */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-neutral-700">Đặc điểm nổi bật gạch đầu dòng (Features)</label>
                <button
                  type="button"
                  onClick={handleAddFeature}
                  className="text-[11px] text-neutral-700 hover:text-black font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Thêm gạch đầu dòng</span>
                </button>
              </div>

              <div className="space-y-1.5">
                {(formData.features || []).map((feat, fIdx) => (
                  <div key={fIdx} className="flex items-center gap-2">
                    <span className="text-amber-500 font-bold">•</span>
                    <input
                      type="text"
                      value={feat}
                      onChange={(e) => handleFeatureChange(fIdx, e.target.value)}
                      className="flex-1 px-3 py-1.5 bg-neutral-50 border border-neutral-300 rounded-sm text-xs focus:bg-white focus:outline-none focus:border-neutral-900"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveFeature(fIdx)}
                      className="text-neutral-400 hover:text-rose-600 p-1 cursor-pointer"
                      title="Xóa dòng này"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </form>

        {/* Modal Footer Controls */}
        <div className="p-4 sm:p-5 bg-neutral-100 border-t border-neutral-300 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-neutral-200 text-neutral-700 border border-neutral-300 rounded-sm font-bold text-xs transition-colors cursor-pointer"
          >
            Hủy Bỏ
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleSubmit}
              className="flex items-center gap-2 bg-neutral-950 hover:bg-black text-white px-6 py-2.5 rounded-sm font-black text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer"
            >
              <Save className="w-4 h-4 text-amber-400" />
              <span>{isNew ? 'Lưu Sản Phẩm Mới' : 'Lưu Thay Đổi Sản Phẩm'}</span>
            </button>
          </div>
        </div>

      </div>

      {/* QUICK PRESET IMAGE PICKER MODAL */}
      {presetPickerOpen && targetFieldForPreset && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white max-w-2xl w-full rounded-sm p-4 sm:p-5 max-h-[85vh] flex flex-col space-y-4 border border-neutral-300">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h4 className="font-black uppercase text-sm font-heading">
                  CHỌN ẢNH THỜI TRANG STREETWEAR CÓ SẴN (PRESETS)
                </h4>
                <p className="text-[11px] text-neutral-500">Click 1 ảnh để gán trực tiếp vào sản phẩm</p>
              </div>
              <button
                type="button"
                onClick={() => setPresetPickerOpen(false)}
                className="text-neutral-400 hover:text-black"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 overflow-y-auto p-1">
              {PRESET_IMAGES.map((preset, pIdx) => (
                <div
                  key={pIdx}
                  onClick={() => {
                    const { colorIndex, field } = targetFieldForPreset;
                    if (field === 'image') {
                      handleColorChange(colorIndex, 'image', preset.url);
                    } else if (field === 'secondary') {
                      handleColorChange(colorIndex, 'secondaryImage', preset.url);
                    } else if (field === 'gallery') {
                      handleAddGalleryUrl(colorIndex, preset.url);
                    }
                    setPresetPickerOpen(false);
                    showToast(`Đã chọn ảnh: ${preset.label}`);
                  }}
                  className="group relative rounded-sm overflow-hidden border border-neutral-200 hover:border-amber-500 cursor-pointer shadow-2xs hover:shadow-md transition-all"
                >
                  <img
                    src={preset.url}
                    alt={preset.label}
                    className="w-full h-28 object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="p-1.5 bg-white text-[10px] font-bold text-neutral-900 truncate">
                    {preset.label}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-2 border-t">
              <button
                type="button"
                onClick={() => setPresetPickerOpen(false)}
                className="px-4 py-1.5 bg-neutral-200 hover:bg-neutral-300 text-neutral-800 rounded-sm font-bold text-xs"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
