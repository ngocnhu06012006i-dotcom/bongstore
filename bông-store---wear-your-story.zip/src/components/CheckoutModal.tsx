import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  X, 
  CheckCircle2, 
  CreditCard, 
  Truck, 
  QrCode, 
  Wallet, 
  ShieldCheck, 
  Copy, 
  ArrowRight,
  Sparkles,
  ShoppingBag,
  Building2,
  Check,
  Landmark
} from 'lucide-react';
import { CartItem, OrderInfo, Voucher, SiteSettings } from '../types';
import { formatVND, FREE_SHIPPING_THRESHOLD, STANDARD_SHIPPING_FEE } from '../utils/formatters';
import { DEFAULT_SITE_SETTINGS } from '../data/mockData';
import { generateVietQrUrl } from './AdminSiteSettingsManager';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  appliedVoucher: Voucher | null;
  siteSettings?: SiteSettings;
  onOrderSuccess: (order: OrderInfo) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  appliedVoucher,
  siteSettings = DEFAULT_SITE_SETTINGS,
  onOrderSuccess,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('TP. Hồ Chí Minh');
  const [district, setDistrict] = useState('');
  const [address, setAddress] = useState('');
  const [note, setNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'momo' | 'vnpay' | 'banking'>('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<OrderInfo | null>(null);
  const [copiedOrderId, setCopiedOrderId] = useState(false);
  const [copiedAcc, setCopiedAcc] = useState(false);
  const [copiedAccName, setCopiedAccName] = useState(false);
  const [copiedAmount, setCopiedAmount] = useState(false);
  const [copiedSyntax, setCopiedSyntax] = useState(false);

  if (!isOpen) return null;

  const currentSettings = siteSettings || DEFAULT_SITE_SETTINGS;

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  let discountAmount = 0;
  if (appliedVoucher) {
    if (subtotal >= appliedVoucher.minOrderValue) {
      if (appliedVoucher.discountPercent) {
        discountAmount = (subtotal * appliedVoucher.discountPercent) / 100;
      } else if (appliedVoucher.discountAmount) {
        discountAmount = appliedVoucher.discountAmount;
      }
    }
  }

  const shippingFee = subtotal >= (currentSettings.freeShippingThreshold || FREE_SHIPPING_THRESHOLD) || (appliedVoucher?.code === 'FREESHIP') ? 0 : STANDARD_SHIPPING_FEE;
  const total = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !address || !district) {
      alert('Vui lòng điền đầy đủ họ tên, số điện thoại và địa chỉ giao hàng.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const generatedId = `BS-${Math.floor(100000 + Math.random() * 900000)}`;
      const newOrder: OrderInfo = {
        orderId: generatedId,
        customerName: name,
        phone,
        email: email || 'khachhang@bongstore.vn',
        address,
        city,
        district,
        note,
        paymentMethod,
        items: [...items],
        subtotal,
        discount: discountAmount,
        shippingFee,
        total,
        status: 'confirmed',
        createdAt: new Date().toLocaleString('vi-VN'),
        estimatedDelivery: '2 - 3 ngày làm việc'
      };

      setConfirmedOrder(newOrder);
      setIsSubmitting(false);
      onOrderSuccess(newOrder);

      // Fire confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (err) {
        // ignore
      }
    }, 800);
  };

  const copyOrderId = () => {
    if (confirmedOrder) {
      navigator.clipboard.writeText(confirmedOrder.orderId);
      setCopiedOrderId(true);
      setTimeout(() => setCopiedOrderId(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={confirmedOrder ? onClose : undefined}
      />

      {/* Modal Box */}
      <div className="relative w-full max-w-3xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-amber-400">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider">
                {confirmedOrder ? 'ĐẶT HÀNG THÀNH CÔNG' : 'THANH TOÁN ĐƠN HÀNG'}
              </h2>
              <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase">BÔNG STORE • WEAR YOUR STORY</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1">
          {confirmedOrder ? (
            /* Order Success View */
            <div className="space-y-6 text-center py-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-xs font-bold text-emerald-600 tracking-wider uppercase bg-emerald-50 px-3 py-1 rounded-full">
                  Đã tiếp nhận đơn hàng
                </span>
                <h3 className="text-2xl font-black font-heading text-neutral-900 mt-2">
                  CẢM ƠN BẠN ĐÃ ĐỒNG HÀNH CÙNG BÔNG STORE!
                </h3>
                <p className="text-xs text-neutral-500 max-w-md mx-auto mt-1">
                  Đơn hàng của bạn đang được xưởng chuẩn bị và đóng gói chỉn chu kèm quà tặng từ Bông Store.
                </p>
              </div>

              {/* Order Info Card */}
              <div className="bg-neutral-50 border border-neutral-200 rounded-xs p-4 text-left max-w-lg mx-auto space-y-3">
                <div className="flex justify-between items-center pb-2 border-b border-neutral-200">
                  <span className="text-xs text-neutral-500 font-medium">Mã đơn hàng:</span>
                  <div className="flex items-center gap-1.5 font-mono font-black text-sm text-neutral-900">
                    <span>{confirmedOrder.orderId}</span>
                    <button
                      onClick={copyOrderId}
                      className="text-neutral-400 hover:text-black p-1"
                      title="Sao chép mã"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    {copiedOrderId && <span className="text-[10px] text-emerald-600 font-sans">Đã chép!</span>}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-neutral-400 block text-[10px]">Người nhận:</span>
                    <strong className="text-neutral-800">{confirmedOrder.customerName}</strong> ({confirmedOrder.phone})
                  </div>
                  <div>
                    <span className="text-neutral-400 block text-[10px]">Hình thức thanh toán:</span>
                    <strong className="text-neutral-800 uppercase">
                      {confirmedOrder.paymentMethod === 'cod' ? 'COD (Nhận hàng thanh toán)' : confirmedOrder.paymentMethod === 'banking' ? 'Chuyển Khoản Ngân Hàng (VietQR)' : confirmedOrder.paymentMethod.toUpperCase()}
                    </strong>
                  </div>
                </div>

                <div className="text-xs">
                  <span className="text-neutral-400 block text-[10px]">Địa chỉ nhận hàng:</span>
                  <p className="text-neutral-700">{confirmedOrder.address}, {confirmedOrder.district}, {confirmedOrder.city}</p>
                </div>

                <div className="pt-2 border-t border-neutral-200 flex justify-between items-baseline text-xs">
                  <span className="font-bold text-neutral-700">Tổng thanh toán:</span>
                  <span className="text-base font-black font-mono-num text-black">{formatVND(confirmedOrder.total)}</span>
                </div>
              </div>

              {/* VietQR Bank Transfer Card for Banking Payment */}
              {confirmedOrder.paymentMethod === 'banking' && (
                <div className="bg-neutral-900 text-white rounded-lg p-5 max-w-lg mx-auto text-left shadow-xl border border-neutral-800 space-y-4">
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                    <div className="flex items-center gap-2">
                      <Landmark className="w-5 h-5 text-amber-400" />
                      <div>
                        <h4 className="text-xs font-black uppercase tracking-wider text-white">
                          THÔNG TIN CHUYỂN KHOẢN VIETQR (NAPAS 24/7)
                        </h4>
                        <p className="text-[10px] text-neutral-400">Mở App Ngân hàng bất kỳ &gt; Chọn Quét Mã QR</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-400/20 text-amber-300 rounded border border-amber-400/30">
                      Tự động 24/7
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-4 bg-black/40 p-4 rounded border border-neutral-800">
                    {/* VietQR Image */}
                    <div className="bg-white p-2 rounded shrink-0 shadow-md">
                      <img
                        src={
                          currentSettings.bankQrCodeUrl ||
                          generateVietQrUrl(
                            currentSettings.bankName,
                            currentSettings.bankAccountNumber,
                            currentSettings.bankAccountName,
                            confirmedOrder.total,
                            `BONGSTORE ${confirmedOrder.orderId}`
                          )
                        }
                        alt="VietQR Transfer"
                        className="w-36 h-36 object-contain"
                      />
                    </div>

                    {/* Bank Details Table */}
                    <div className="flex-1 w-full space-y-2 text-xs">
                      <div>
                        <span className="text-[10px] text-neutral-400 block uppercase font-bold">Ngân Hàng:</span>
                        <span className="font-bold text-amber-400">{currentSettings.bankName}</span>
                      </div>

                      <div className="flex items-center justify-between bg-neutral-800/80 px-2.5 py-1.5 rounded">
                        <div>
                          <span className="text-[9px] text-neutral-400 block uppercase font-bold">Số tài khoản:</span>
                          <span className="font-mono font-black text-sm text-white tracking-wider">
                            {currentSettings.bankAccountNumber}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(currentSettings.bankAccountNumber);
                            setCopiedAcc(true);
                            setTimeout(() => setCopiedAcc(false), 2000);
                          }}
                          className="px-2 py-1 bg-white/10 hover:bg-white/20 text-neutral-200 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          {copiedAcc ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedAcc ? 'Đã chép' : 'Chép'}</span>
                        </button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-[9px] text-neutral-400 block uppercase font-bold">Chủ tài khoản:</span>
                          <span className="font-bold text-neutral-200 uppercase font-mono">
                            {currentSettings.bankAccountName}
                          </span>
                        </div>
                        {currentSettings.bankBranch && (
                          <span className="text-[10px] text-neutral-400">({currentSettings.bankBranch})</span>
                        )}
                      </div>

                      <div className="flex items-center justify-between bg-neutral-800/80 px-2.5 py-1.5 rounded">
                        <div>
                          <span className="text-[9px] text-neutral-400 block uppercase font-bold">Nội dung chuyển:</span>
                          <span className="font-mono font-black text-amber-400 text-xs tracking-wider">
                            BONGSTORE {confirmedOrder.orderId}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(`BONGSTORE ${confirmedOrder.orderId}`);
                            setCopiedSyntax(true);
                            setTimeout(() => setCopiedSyntax(false), 2000);
                          }}
                          className="px-2 py-1 bg-white/10 hover:bg-white/20 text-neutral-200 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          {copiedSyntax ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedSyntax ? 'Đã chép' : 'Chép'}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  <p className="text-[11px] text-neutral-400 text-center">
                    Hệ thống Bông Store sẽ tự động kiểm tra và cập nhật trạng thái đơn hàng ngay sau khi tài khoản nhận được tiền.
                  </p>
                </div>
              )}

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row justify-center gap-3 pt-2">
                <button
                  onClick={onClose}
                  className="px-6 py-3 bg-black hover:bg-neutral-800 text-white text-xs font-extrabold uppercase rounded-xs transition-colors"
                >
                  Tiếp Tục Mua Sắm
                </button>
              </div>
            </div>
          ) : (
            /* Checkout Form View */
            <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left: Customer & Shipping Details (7 cols) */}
              <div className="lg:col-span-7 space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-100 pb-2">
                  1. Thông tin giao hàng
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold text-neutral-700 block mb-1">
                      Họ và tên người nhận <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ví dụ: Nguyễn Văn A"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full border border-neutral-300 rounded-xs px-3 py-2 focus:outline-hidden focus:border-black"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-neutral-700 block mb-1">
                        Số điện thoại <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="0901234567"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full border border-neutral-300 rounded-xs px-3 py-2 font-mono focus:outline-hidden focus:border-black"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-neutral-700 block mb-1">
                        Email (nhận mã theo dõi)
                      </label>
                      <input
                        type="email"
                        placeholder="name@email.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full border border-neutral-300 rounded-xs px-3 py-2 focus:outline-hidden focus:border-black"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-neutral-700 block mb-1">
                        Tỉnh / Thành phố <span className="text-red-500">*</span>
                      </label>
                      <select
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full border border-neutral-300 rounded-xs px-3 py-2 bg-white focus:outline-hidden focus:border-black cursor-pointer font-medium"
                      >
                        <option value="TP. Hồ Chí Minh">TP. Hồ Chí Minh</option>
                        <option value="Hà Nội">Hà Nội</option>
                        <option value="Đà Nẵng">Đà Nẵng</option>
                        <option value="Hải Phòng">Hải Phòng</option>
                        <option value="Cần Thơ">Cần Thơ</option>
                        <option value="Bình Dương">Bình Dương</option>
                        <option value="Đồng Nai">Đồng Nai</option>
                        <option value="Khác">Tỉnh thành khác</option>
                      </select>
                    </div>
                    <div>
                      <label className="font-bold text-neutral-700 block mb-1">
                        Quận / Huyện <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Ví dụ: Quận 1, Cầu Giấy..."
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        className="w-full border border-neutral-300 rounded-xs px-3 py-2 focus:outline-hidden focus:border-black"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-neutral-700 block mb-1">
                      Địa chỉ cụ thể (Số nhà, đường, phường/xã) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ví dụ: 123 Lê Văn Sỹ, Phường 13"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full border border-neutral-300 rounded-xs px-3 py-2 focus:outline-hidden focus:border-black"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-neutral-700 block mb-1">
                      Ghi chú đơn hàng (Tùy chọn)
                    </label>
                    <input
                      type="text"
                      placeholder="Giao giờ hành chính, gọi trước khi giao..."
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      className="w-full border border-neutral-300 rounded-xs px-3 py-2 focus:outline-hidden focus:border-black"
                    />
                  </div>
                </div>

                {/* Payment Methods */}
                <div className="pt-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-100 pb-2 mb-3">
                    2. Phương thức thanh toán
                  </h3>

                  <div className="space-y-2">
                    {[
                      { id: 'cod', label: 'Thanh toán khi nhận hàng (COD)', icon: Truck, desc: 'Kiểm tra hàng trước khi thanh toán' },
                      { id: 'banking', label: 'Chuyển khoản Ngân Hàng (VietQR 24/7)', icon: QrCode, desc: 'Quét mã QR tự động xác nhận trong 3 giây' },
                      { id: 'momo', label: 'Ví MoMo', icon: Wallet, desc: 'Thanh toán tiện lợi qua ứng dụng MoMo' },
                      { id: 'vnpay', label: 'Cổng VNPay (Thẻ ATM/Visa/Mastercard)', icon: CreditCard, desc: 'Bảo mật chuẩn quốc tế PCI DSS' },
                    ].map((item) => {
                      const Icon = item.icon;
                      return (
                        <label
                          key={item.id}
                          className={`flex items-start gap-3 p-3 rounded-xs border cursor-pointer transition-all ${
                            paymentMethod === item.id
                              ? 'border-black bg-neutral-50 ring-1 ring-black'
                              : 'border-neutral-200 hover:border-neutral-300'
                          }`}
                        >
                          <input
                            type="radio"
                            name="paymentMethod"
                            checked={paymentMethod === item.id}
                            onChange={() => setPaymentMethod(item.id as any)}
                            className="mt-0.5 accent-black"
                          />
                          <div className="flex-1 text-xs">
                            <div className="flex items-center gap-1.5 font-bold text-neutral-900">
                              <Icon className="w-4 h-4 text-neutral-700" />
                              <span>{item.label}</span>
                            </div>
                            <p className="text-[11px] text-neutral-500 mt-0.5">{item.desc}</p>

                            {item.id === 'banking' && paymentMethod === 'banking' && (
                              <div className="mt-2.5 p-2.5 bg-white border border-neutral-200 rounded text-[11px] space-y-1">
                                <div className="flex items-center justify-between font-bold text-neutral-900">
                                  <span>{currentSettings.bankName}</span>
                                  <span className="font-mono text-amber-600 font-bold">{currentSettings.bankAccountNumber}</span>
                                </div>
                                <div className="flex items-center justify-between text-neutral-600">
                                  <span className="uppercase font-mono font-medium">{currentSettings.bankAccountName}</span>
                                  {currentSettings.bankBranch && <span>{currentSettings.bankBranch}</span>}
                                </div>
                                <p className="text-[10px] text-emerald-700 font-medium pt-1 border-t border-neutral-100">
                                  ✓ Mã VietQR kèm số tiền chính xác sẽ xuất hiện ngay sau khi bạn bấm Xác Nhận Đặt Hàng.
                                </p>
                              </div>
                            )}
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right: Order Summary (5 cols) */}
              <div className="lg:col-span-5 bg-neutral-50 p-4 rounded-xs border border-neutral-200 flex flex-col justify-between">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 pb-2 border-b border-neutral-200 mb-3">
                    Đơn hàng ({items.length} món)
                  </h3>

                  {/* Cart preview */}
                  <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1 mb-4">
                    {items.map((it) => (
                      <div key={it.id} className="flex gap-2.5 items-center text-xs">
                        <img
                          src={it.selectedColor.image}
                          alt={it.product.name}
                          className="w-12 h-14 object-cover rounded-xs border border-neutral-200 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-neutral-900 truncate">{it.product.name}</p>
                          <p className="text-[10px] text-neutral-500">{it.selectedColor.name} | Size {it.selectedSize} x{it.quantity}</p>
                        </div>
                        <div className="font-mono font-bold text-neutral-800">
                          {formatVND(it.product.price * it.quantity)}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Price calculations */}
                  <div className="space-y-1.5 text-xs text-neutral-600 pt-3 border-t border-neutral-200">
                    <div className="flex justify-between">
                      <span>Tạm tính:</span>
                      <span className="font-mono font-bold text-neutral-900">{formatVND(subtotal)}</span>
                    </div>
                    {discountAmount > 0 && (
                      <div className="flex justify-between text-emerald-700 font-bold">
                        <span>Mã giảm ({appliedVoucher?.code}):</span>
                        <span className="font-mono">-{formatVND(discountAmount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Phí vận chuyển:</span>
                      <span className="font-mono font-bold text-neutral-900">
                        {shippingFee === 0 ? <span className="text-emerald-600 uppercase">Miễn Phí</span> : formatVND(shippingFee)}
                      </span>
                    </div>
                    <div className="flex justify-between items-baseline pt-2 border-t border-neutral-200 text-sm font-black text-neutral-900">
                      <span>TỔNG THANH TOÁN:</span>
                      <span className="text-lg text-black font-mono-num font-black">{formatVND(total)}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 space-y-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 bg-black hover:bg-neutral-800 text-white font-extrabold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Đang xử lý đơn hàng...</span>
                    ) : (
                      <>
                        <span>XÁC NHẬN ĐẶT HÀNG</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="text-[10px] text-neutral-500 text-center flex items-center justify-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Đổi trả miễn phí 14 ngày nếu không vừa size</span>
                  </div>
                </div>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
