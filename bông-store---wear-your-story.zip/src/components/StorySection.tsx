import React from 'react';
import { Sparkles, ShieldCheck, Scissors } from 'lucide-react';
import { StoryContent } from '../types';
import { DEFAULT_SITE_SETTINGS } from '../data/mockData';

interface StorySectionProps {
  story?: StoryContent;
}

export const StorySection: React.FC<StorySectionProps> = ({
  story = DEFAULT_SITE_SETTINGS.story
}) => {
  const content = story || DEFAULT_SITE_SETTINGS.story;

  return (
    <section id="story-section" className="py-16 sm:py-24 bg-white text-neutral-900 border-t border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Story Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-16">
          
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-neutral-100 rounded-full text-xs font-bold uppercase tracking-widest text-neutral-800">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>{content.badge || 'CÂU CHUYỆN THƯƠNG HIỆU'}</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-black font-heading tracking-tight uppercase leading-[1.05]">
              {content.title || 'BÔNG STORE'} <br />
              <span className="text-neutral-400">{content.slogan || 'WEAR YOUR STORY.'}</span>
            </h2>

            <p className="text-sm sm:text-base text-neutral-600 leading-relaxed">
              {content.introParagraph}
            </p>

            <p className="text-xs sm:text-sm text-neutral-500 leading-relaxed">
              {content.detailParagraph}
            </p>

            {/* Core Values grid */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-100">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-neutral-100 flex items-center justify-center shrink-0">
                  <Scissors className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase text-neutral-900">Phom Dáng Chuẩn</h4>
                  <p className="text-[11px] text-neutral-500">Boxy Fit & Oversize tôn dáng người Việt</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-neutral-100 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h4 className="text-xs font-black uppercase text-neutral-900">Compact Cotton</h4>
                  <p className="text-[11px] text-neutral-500">100% sợi chải kỹ, không xù lông</p>
                </div>
              </div>
            </div>
          </div>

          {/* Collage Images */}
          <div className="lg:col-span-6 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="aspect-3/4 rounded-xs overflow-hidden bg-neutral-100 shadow-md">
                <img
                  src={content.image1 || 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=800&auto=format&fit=crop'}
                  alt="Bông Store Lifestyle"
                  className="w-full h-full object-cover object-center hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-4 bg-neutral-900 text-white rounded-xs">
                <p className="text-2xl font-black font-mono-num text-amber-400">{content.stat1Number || '100.000+'}</p>
                <p className="text-xs text-neutral-300 uppercase tracking-wider font-bold">{content.stat1Label || 'Khách hàng yêu thích'}</p>
              </div>
            </div>

            <div className="space-y-4 pt-8">
              <div className="p-4 bg-amber-400 text-black rounded-xs">
                <p className="text-2xl font-black font-mono-num">{content.stat2Number || '260-380'}</p>
                <p className="text-xs text-black/80 uppercase tracking-wider font-bold">{content.stat2Label || 'GSM Vải siêu dày dặn'}</p>
              </div>
              <div className="aspect-3/4 rounded-xs overflow-hidden bg-neutral-100 shadow-md">
                <img
                  src={content.image2 || 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=800&auto=format&fit=crop'}
                  alt="Bông Store Fashion"
                  className="w-full h-full object-cover object-center hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
          </div>

        </div>

        {/* 3 Pillars of Craftsmanship */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12 border-t border-neutral-100">
          <div className="p-6 bg-neutral-50 rounded-xs border border-neutral-200">
            <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center font-bold mb-4">
              01
            </div>
            <h3 className="text-sm font-black uppercase text-neutral-900 mb-2">
              {content.pillar1Title || 'CHẤT LIỆU CAO CẤP TUYỂN CHỌN'}
            </h3>
            <p className="text-xs text-neutral-500 leading-relaxed">
              {content.pillar1Desc || 'Sử dụng 100% sợi Compact Cotton 2 chiều và 4 chiều xử lý Enzyme Wash mềm mịn, thấm hút mồ hôi tối đa và thoáng mát cả ngày dài.'}
            </p>
          </div>

          <div className="p-6 bg-neutral-50 rounded-xs border border-neutral-200">
            <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center font-bold mb-4">
              02
            </div>
            <h3 className="text-sm font-black uppercase text-neutral-900 mb-2">
              {content.pillar2Title || 'PHOM DÁNG BOXY & OVERSIZE'}
            </h3>
            <p className="text-xs text-neutral-500 leading-relaxed">
              {content.pillar2Desc || 'Nghiên cứu nhân trắc học người Việt để tạo nên tỷ lệ vai rơi, hạ nách và độ dài hoàn hảo, tôn dáng tự nhiên và che khuyết điểm vượt trội.'}
            </p>
          </div>

          <div className="p-6 bg-neutral-50 rounded-xs border border-neutral-200">
            <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center font-bold mb-4">
              03
            </div>
            <h3 className="text-sm font-black uppercase text-neutral-900 mb-2">
              {content.pillar3Title || 'TINH THẦN ĐƯỜNG PHỐ NGUYÊN BẢN'}
            </h3>
            <p className="text-xs text-neutral-500 leading-relaxed">
              {content.pillar3Desc || 'Mỗi chi tiết từ tag dệt, cúc khắc laser đến hình in lụa thủ công đều được chăm chút tỉ mỉ, cam kết chất lượng bền bỉ vượt thời gian.'}
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};

