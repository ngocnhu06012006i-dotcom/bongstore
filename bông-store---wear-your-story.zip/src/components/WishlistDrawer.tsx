import React from 'react';
import { X, Heart, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { Product, ProductColor, ProductSize } from '../types';
import { formatVND } from '../utils/formatters';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistProducts: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, color: ProductColor, size: ProductSize) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistProducts,
  onRemoveFromWishlist,
  onQuickView,
  onAddToCart,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
          
          {/* Header */}
          <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500 fill-current" />
              <h2 className="text-base font-extrabold font-heading uppercase tracking-tight text-neutral-900">
                SẢN PHẨM YÊU THÍCH ({wishlistProducts.length})
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-black rounded-full transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {wishlistProducts.length > 0 ? (
              <div className="divide-y divide-neutral-100">
                {wishlistProducts.map((product) => (
                  <div key={product.id} className="py-3.5 flex gap-3.5 first:pt-0">
                    <img
                      src={product.colors[0]?.image}
                      alt={product.name}
                      className="w-18 h-22 object-cover rounded-xs border border-neutral-200 shrink-0 cursor-pointer"
                      onClick={() => onQuickView(product)}
                    />

                    <div className="flex-1 flex flex-col justify-between min-w-0">
                      <div>
                        <div className="flex justify-between items-start">
                          <h4 
                            onClick={() => onQuickView(product)}
                            className="text-xs font-bold text-neutral-900 truncate hover:underline cursor-pointer"
                          >
                            {product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveFromWishlist(product)}
                            className="text-neutral-400 hover:text-red-500 p-0.5"
                            title="Xóa khỏi yêu thích"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[10px] text-neutral-500 mt-0.5">{product.fit}</p>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <span className="text-xs font-extrabold font-mono-num text-neutral-900">
                          {formatVND(product.price)}
                        </span>

                        <div className="flex gap-1.5">
                          <button
                            onClick={() => onAddToCart(product, product.colors[0], product.sizes[0])}
                            className="px-3 py-1.5 bg-black hover:bg-neutral-800 text-white text-[11px] font-bold rounded-xs flex items-center gap-1 cursor-pointer"
                          >
                            <ShoppingBag className="w-3 h-3" />
                            <span>Thêm Giỏ</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center mx-auto text-neutral-400">
                  <Heart className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-neutral-800">Danh sách yêu thích trống</h3>
                <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                  Hãy thả tim cho những món đồ bạn ưng ý nhất để lưu lại và theo dõi nhé!
                </p>
                <button
                  onClick={onClose}
                  className="bg-black hover:bg-neutral-800 text-white text-xs font-extrabold uppercase px-6 py-3 rounded-xs transition-colors cursor-pointer"
                >
                  Khám phá sản phẩm
                </button>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
