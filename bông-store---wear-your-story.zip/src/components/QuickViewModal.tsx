import React, { useState } from 'react';
import { Product, ProductColor, ProductSize } from '../types';
import { formatVND } from '../utils/formatters';
import { 
  X, 
  Heart, 
  ShoppingBag, 
  Check, 
  Ruler, 
  Truck, 
  RotateCcw, 
  ShieldCheck, 
  Star,
  Sparkles,
  Zap
} from 'lucide-react';
import { REVIEWS } from '../data/mockData';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product, color: ProductColor, size: ProductSize, quantity: number) => void;
  onBuyNow: (product: Product, color: ProductColor, size: ProductSize, quantity: number) => void;
  onOpenSizeGuide: (callbackSize: (size: ProductSize) => void) => void;
}

export const QuickViewModal: React.FC<QuickViewModalProps> = ({
  product,
  isOpen,
  onClose,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
  onOpenSizeGuide,
}) => {
  if (!isOpen || !product) return null;

  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<ProductSize>(product.sizes[0] || 'M');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'details' | 'reviews'>('details');
  const [addedNotice, setAddedNotice] = useState(false);

  const currentColor = product.colors[selectedColorIndex] || product.colors[0];
  const gallery = currentColor.gallery && currentColor.gallery.length > 0 
    ? currentColor.gallery 
    : [currentColor.image, currentColor.secondaryImage].filter(Boolean);

  const currentImage = gallery[selectedImageIndex] || currentColor.image;
  const currentStock = product.inStockSizes[selectedSize] || 0;

  const handleAddToCart = () => {
    if (currentStock <= 0) return;
    onAddToCart(product, currentColor, selectedSize, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  const handleBuyNow = () => {
    if (currentStock <= 0) return;
    onBuyNow(product, currentColor, selectedSize, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Box */}
      <div className="relative w-full max-w-4xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col md:flex-row">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-30 p-2 bg-white/90 hover:bg-black hover:text-white text-neutral-800 rounded-full shadow-md transition-colors cursor-pointer"
          aria-label="Đóng"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Gallery (50%) */}
        <div className="w-full md:w-1/2 bg-neutral-100 p-4 sm:p-6 flex flex-col justify-between overflow-y-auto">
          {/* Main Big Photo */}
          <div className="relative aspect-4/5 w-full rounded-xs overflow-hidden bg-neutral-200 shadow-xs mb-3">
            <img
              src={currentImage}
              alt={product.name}
              className="w-full h-full object-cover object-center"
            />
            {product.discountPercent && (
              <span className="absolute top-3 left-3 bg-rose-600 text-white text-xs font-black px-2 py-1 rounded-xs">
                GIẢM {product.discountPercent}%
              </span>
            )}
          </div>

          {/* Thumbnails */}
          {gallery.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {gallery.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-16 h-20 rounded-xs overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                    selectedImageIndex === idx ? 'border-black ring-1 ring-black' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Info & Purchase (50%) */}
        <div className="w-full md:w-1/2 p-5 sm:p-7 flex flex-col overflow-y-auto max-h-[85vh] md:max-h-[92vh]">
          {/* Code & Slogan Tag */}
          <div className="flex items-center justify-between text-xs text-neutral-400 font-bold uppercase tracking-wider mb-1">
            <span>MÃ: {product.code}</span>
            <span className="text-amber-600 font-mono">BÔNG STORE • 2026</span>
          </div>

          {/* Title */}
          <h2 className="text-lg sm:text-xl font-extrabold text-neutral-900 font-heading leading-snug mb-2">
            {product.name}
          </h2>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <span className="text-xs font-bold text-neutral-800">{product.rating}</span>
            <span className="text-xs text-neutral-400">({product.reviewCount} đánh giá đã xác thực)</span>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3 pb-4 border-b border-neutral-100 mb-4">
            <span className="text-xl sm:text-2xl font-black text-neutral-900 font-mono-num">
              {formatVND(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-sm text-neutral-400 line-through font-mono-num">
                {formatVND(product.originalPrice)}
              </span>
            )}
            <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-xs">
              Tiết kiệm {formatVND((product.originalPrice || product.price) - product.price)}
            </span>
          </div>

          {/* Color Selector */}
          <div className="mb-4">
            <div className="flex justify-between text-xs font-bold mb-2">
              <span className="text-neutral-700">Màu sắc:</span>
              <span className="text-neutral-900 font-semibold">{currentColor.name}</span>
            </div>
            <div className="flex gap-2">
              {product.colors.map((c, idx) => (
                <button
                  key={c.name}
                  onClick={() => {
                    setSelectedColorIndex(idx);
                    setSelectedImageIndex(0);
                  }}
                  className={`w-8 h-8 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer ${
                    selectedColorIndex === idx ? 'border-black ring-2 ring-black ring-offset-2' : 'border-neutral-300 hover:scale-105'
                  }`}
                  style={{ backgroundColor: c.hex }}
                  title={c.name}
                >
                  {selectedColorIndex === idx && (
                    <Check className={`w-3.5 h-3.5 ${c.hex === '#F4EEDB' || c.hex === '#F9F9F6' ? 'text-black' : 'text-white'}`} />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Size Selector + Size Guide Link */}
          <div className="mb-5">
            <div className="flex justify-between items-center text-xs font-bold mb-2">
              <div className="flex items-center gap-1.5 text-neutral-700">
                <span>Kích thước:</span>
                <span className="text-neutral-900">Size {selectedSize}</span>
              </div>
              <button
                type="button"
                onClick={() => onOpenSizeGuide((size) => setSelectedSize(size))}
                className="text-amber-700 hover:text-black flex items-center gap-1 text-[11px] underline cursor-pointer"
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>Gợi ý size thông minh</span>
              </button>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {product.sizes.map((s) => {
                const stock = product.inStockSizes[s] || 0;
                const isAvail = stock > 0;
                return (
                  <button
                    key={s}
                    disabled={!isAvail}
                    onClick={() => setSelectedSize(s)}
                    className={`py-2 text-xs font-extrabold rounded-xs border transition-all cursor-pointer ${
                      selectedSize === s
                        ? 'border-black bg-black text-white shadow-xs'
                        : isAvail
                        ? 'border-neutral-200 bg-white text-neutral-800 hover:border-black'
                        : 'border-neutral-200 bg-neutral-100 text-neutral-300 line-through cursor-not-allowed'
                    }`}
                  >
                    {s}
                  </button>
                );
              })}
            </div>

            {/* Stock status indicator */}
            <div className="text-[11px] mt-1.5 font-medium text-neutral-500">
              {currentStock > 0 ? (
                <span>Tình trạng: <strong className="text-emerald-600">Còn hàng ({currentStock} chiếc)</strong></span>
              ) : (
                <span className="text-rose-600 font-bold">Size này tạm thời hết hàng</span>
              )}
            </div>
          </div>

          {/* Quantity selector */}
          <div className="flex items-center gap-3 mb-6">
            <span className="text-xs font-bold text-neutral-700">Số lượng:</span>
            <div className="flex items-center border border-neutral-300 rounded-xs bg-white">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-3 py-1.5 text-neutral-600 hover:bg-neutral-100 text-xs font-bold cursor-pointer"
              >
                -
              </button>
              <span className="px-3 py-1.5 text-xs font-mono font-bold min-w-8 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(Math.min(currentStock, quantity + 1))}
                className="px-3 py-1.5 text-neutral-600 hover:bg-neutral-100 text-xs font-bold cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 mb-6">
            <div className="flex gap-2">
              {/* Add to Cart */}
              <button
                onClick={handleAddToCart}
                disabled={currentStock <= 0}
                className="flex-1 py-3.5 px-4 bg-neutral-900 hover:bg-black text-white font-extrabold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Thêm Vào Giỏ Hàng</span>
              </button>

              {/* Wishlist Button */}
              <button
                onClick={() => onToggleWishlist(product)}
                className={`p-3.5 rounded-xs border transition-colors cursor-pointer ${
                  isWishlisted 
                    ? 'border-red-500 bg-red-50 text-red-600' 
                    : 'border-neutral-300 hover:border-black text-neutral-700'
                }`}
                title="Yêu thích"
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Buy Now Fast Checkout */}
            <button
              onClick={handleBuyNow}
              disabled={currentStock <= 0}
              className="w-full py-3 px-4 bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Zap className="w-4 h-4 fill-black" />
              <span>Mua Ngay (Thanh Toán Siêu Tốc)</span>
            </button>

            {/* Added notice */}
            {addedNotice && (
              <div className="p-2 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xs flex items-center justify-center gap-1.5 animate-in fade-in">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Đã thêm {quantity} sản phẩm vào giỏ hàng thành công!</span>
              </div>
            )}
          </div>

          {/* Guarantee Badges */}
          <div className="grid grid-cols-3 gap-2 py-3 border-y border-neutral-100 text-[10px] text-neutral-600 text-center mb-4">
            <div className="flex flex-col items-center gap-1">
              <Truck className="w-4 h-4 text-neutral-800" />
              <span>Freeship từ 499k</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <RotateCcw className="w-4 h-4 text-neutral-800" />
              <span>Đổi trả 14 ngày</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-neutral-800" />
              <span>Bông Store chính hãng</span>
            </div>
          </div>

          {/* Tabs: Details & Reviews */}
          <div className="space-y-3">
            <div className="flex border-b border-neutral-200 text-xs font-bold">
              <button
                onClick={() => setActiveTab('details')}
                className={`pb-2 mr-4 transition-colors cursor-pointer ${
                  activeTab === 'details' ? 'border-b-2 border-black text-black' : 'text-neutral-400 hover:text-black'
                }`}
              >
                Mô tả chi tiết
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`pb-2 transition-colors cursor-pointer ${
                  activeTab === 'reviews' ? 'border-b-2 border-black text-black' : 'text-neutral-400 hover:text-black'
                }`}
              >
                Đánh giá khách hàng ({product.reviewCount})
              </button>
            </div>

            {activeTab === 'details' ? (
              <div className="text-xs text-neutral-600 space-y-2 leading-relaxed">
                <p>{product.description}</p>
                <div className="bg-neutral-50 p-3 rounded-xs border border-neutral-100 space-y-1">
                  <div><strong>Chất liệu:</strong> {product.material}</div>
                  <div><strong>Định lượng:</strong> {product.gsm}</div>
                  <div><strong>Phom dáng:</strong> {product.fit}</div>
                </div>
                <div>
                  <strong className="text-neutral-800 block mb-1">Đặc điểm nổi bật:</strong>
                  <ul className="list-disc pl-4 space-y-0.5 text-neutral-600">
                    {product.features.map((f, i) => (
                      <li key={i}>{f}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
                {REVIEWS.map((rev) => (
                  <div key={rev.id} className="p-2.5 bg-neutral-50 rounded-xs border border-neutral-100 text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-bold text-neutral-900">{rev.author}</span>
                      <span className="text-[10px] text-neutral-400">{rev.date}</span>
                    </div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <div className="flex text-amber-400 text-[10px]">
                        {[...Array(rev.rating)].map((_, i) => (
                          <span key={i}>★</span>
                        ))}
                      </div>
                      <span className="text-[10px] bg-neutral-200 px-1.5 py-0.2 rounded-xs text-neutral-700">
                        Size {rev.sizePurchased} • {rev.fitFeedback}
                      </span>
                    </div>
                    <p className="text-neutral-600 leading-relaxed text-[11px]">{rev.comment}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
