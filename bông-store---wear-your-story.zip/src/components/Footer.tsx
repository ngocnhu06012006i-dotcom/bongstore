import React, { useState } from 'react';
import { 
  Send, 
  MapPin, 
  Phone, 
  Mail, 
  ShieldCheck, 
  RotateCcw, 
  Truck, 
  Sparkles,
  CheckCircle2,
  Instagram,
  Facebook
} from 'lucide-react';
import { STORE_BRANCHES, DEFAULT_SITE_SETTINGS } from '../data/mockData';
import { SiteSettings } from '../types';

interface FooterProps {
  siteSettings?: SiteSettings;
  onOpenStoreLocator: () => void;
  onOpenOrderTracker: () => void;
  onOpenSizeGuide: () => void;
  onOpenVipClub: () => void;
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  siteSettings = DEFAULT_SITE_SETTINGS,
  onOpenStoreLocator,
  onOpenOrderTracker,
  onOpenSizeGuide,
  onOpenVipClub,
  onOpenAdmin,
}) => {
  const settings = siteSettings || DEFAULT_SITE_SETTINGS;
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setSubscribed(true);
    }
  };

  return (
    <footer id="main-footer" className="bg-[#0D0D0E] text-neutral-300 pt-16 pb-12 border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Newsletter & Club Row */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xs p-6 sm:p-8 mb-16 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="max-w-xl text-center lg:text-left">
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
              GIA NHẬP CỘNG ĐỒNG {settings.storeName}
            </span>
            <h3 className="text-xl sm:text-2xl font-black font-heading uppercase text-white mt-1">
              NHẬN MÃ GIẢM GIÁ 10% CHO ĐƠN ĐẦU TIÊN
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              Đăng ký để nhận thông báo sớm nhất về các đợt phát hành Limited Drops và Lookbook mới.
            </p>
          </div>

          <div className="w-full lg:w-auto">
            {subscribed ? (
              <div className="bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-xs font-bold p-3 rounded-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Cảm ơn bạn! Mã <strong>BONGSTORE10</strong> đã sẵn sàng cho bạn.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2 w-full max-w-md">
                <input
                  type="email"
                  required
                  placeholder="Nhập email của bạn..."
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-xs px-3.5 py-2.5 text-xs text-white placeholder:text-neutral-500 focus:outline-hidden focus:border-amber-400"
                />
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-black text-xs font-extrabold uppercase rounded-xs transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Đăng ký</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* 4 Columns Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          
          {/* Brand Col (2 cols on lg) */}
          <div className="lg:col-span-2 space-y-4">
            <div>
              <span className="text-2xl font-black tracking-tight font-heading uppercase text-white">
                {settings.storeName}
              </span>
              <p className="text-[10px] font-extrabold tracking-[0.25em] text-neutral-400 uppercase -mt-0.5">
                {settings.slogan}
              </p>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              Thương hiệu thời trang đường phố Việt Nam cao cấp. Mang đến các thiết kế áo thun Boxy, hoodie, quần parachute và phụ kiện định hình phong cách độc bản cho giới trẻ.
            </p>

            <div className="space-y-1.5 text-xs text-neutral-400">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Hotline CSKH: <strong>{settings.hotline}</strong> ({settings.operatingHours || '09:00 - 22:30'})</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-400" />
                <span>Email: <strong>{settings.email}</strong></span>
              </div>
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              <a href={settings.facebookUrl || '#'} className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-white hover:text-black flex items-center justify-center transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href={settings.instagramUrl || '#'} className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-white hover:text-black flex items-center justify-center transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <span className="text-[11px] text-neutral-500 font-mono">@bongstore.vn</span>
            </div>
          </div>

          {/* About / Brand Col */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-white">VỀ {settings.storeName}</h4>
            <ul className="space-y-2 text-xs text-neutral-400">
              <li><a href="#story-section" className="hover:text-white transition-colors">Câu chuyện thương hiệu</a></li>
              <li><a href="#story-section" className="hover:text-white transition-colors">Slogan "{settings.slogan}"</a></li>
              <li><a href="#lookbook-section" className="hover:text-white transition-colors">Lookbook 2026</a></li>
              <li><button onClick={onOpenVipClub} className="hover:text-white transition-colors text-left">Bông VIP Membership</button></li>
              <li><button onClick={onOpenStoreLocator} className="hover:text-white transition-colors text-left">Hệ thống showroom</button></li>
              <li><a href="#" className="hover:text-white transition-colors">Tuyển dụng & Sự nghiệp</a></li>
            </ul>
          </div>


          {/* Customer Service */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-white">HỖ TRỢ KHÁCH HÀNG</h4>
            <ul className="space-y-2 text-xs text-neutral-400">
              <li><button onClick={onOpenOrderTracker} className="hover:text-white transition-colors text-left cursor-pointer">Tra cứu đơn hàng</button></li>
              <li><button onClick={onOpenSizeGuide} className="hover:text-white transition-colors text-left cursor-pointer">Hướng dẫn chọn size</button></li>
              <li><button onClick={onOpenVipClub} className="hover:text-white transition-colors text-left cursor-pointer">Chính sách VIP Club</button></li>
              <li><a href="#" className="hover:text-white transition-colors">Chính sách đổi trả 14 ngày</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Chính sách bảo hành & Giặt ủi</a></li>
            </ul>
          </div>

          {/* Store Locations */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-white">HỆ THỐNG CỬA HÀNG</h4>
            <div className="space-y-2.5 text-xs text-neutral-400">
              <div>
                <strong className="text-neutral-200 block text-[11px]">TP. HỒ CHÍ MINH</strong>
                <p className="text-[11px]">139 Lê Văn Sỹ, P.13, Q.3 (Flagship)</p>
                <p className="text-[11px]">246 Nguyễn Trãi, P.Bến Thành, Q.1</p>
              </div>
              <div>
                <strong className="text-neutral-200 block text-[11px]">HÀ NỘI</strong>
                <p className="text-[11px]">88 Bà Triệu, Q.Hoàn Kiếm</p>
              </div>
              <button
                onClick={onOpenStoreLocator}
                className="text-amber-400 hover:underline text-xs font-bold flex items-center gap-1 mt-1 cursor-pointer"
              >
                <span>Xem tất cả 5 chi nhánh</span>
                <span>→</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom copyright & badges */}
        <div className="pt-8 border-t border-neutral-800/80 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <div>
            {`© 2026 ${settings.storeName}. ALL RIGHTS RESERVED.`}
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>Điều khoản dịch vụ</span>
            <span>•</span>
            <span>Chính sách bảo mật</span>
            <span>•</span>
            <span className="font-mono text-neutral-400">DESIGNED IN SAIGON</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
