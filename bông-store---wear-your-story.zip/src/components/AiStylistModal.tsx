import React, { useState } from 'react';
import { X, Sparkles, Check, ShoppingBag, ArrowRight, RefreshCw, Flame, Heart } from 'lucide-react';
import { PRODUCTS } from '../data/mockData';
import { Product, ProductColor, ProductSize } from '../types';
import { formatVND } from '../utils/formatters';

interface AiStylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddComboToCart: (items: { product: Product; color: ProductColor; size: ProductSize }[]) => void;
  onQuickView: (product: Product) => void;
}

export const AiStylistModal: React.FC<AiStylistModalProps> = ({
  isOpen,
  onClose,
  onAddComboToCart,
  onQuickView,
}) => {
  const [occasion, setOccasion] = useState<string>('cafe-street');
  const [vibeTone, setVibeTone] = useState<string>('monochrome');
  const [isGenerating, setIsGenerating] = useState(false);
  const [addedComboNotice, setAddedComboNotice] = useState(false);

  if (!isOpen) return null;

  const occasions = [
    { id: 'cafe-street', name: 'Dạo Phố & Cafe Cuối Tuần', desc: 'Thoải mái, phóng khoáng, nổi bật khi chụp hình' },
    { id: 'night-out', name: 'Night Out & Chilling Sài Gòn', desc: 'Cá tính, ngầu, thu hút ánh nhìn về đêm' },
    { id: 'dating', name: 'Hẹn Hò & Gặp Gỡ', desc: 'Chỉn chu, lịch thiệp pha lẫn nét trẻ trung' },
    { id: 'creative-work', name: 'Đi Làm Sáng Tạo / Đi Học', desc: 'Tiện lợi, năng động, phong cách tự do' },
  ];

  const vibeTones = [
    { id: 'monochrome', name: 'Monochrome (Đen / Xám / Trắng)', hex: '#1E1E20' },
    { id: 'earthy', name: 'Earthy & Olive (Be / Rêu / Nâu)', hex: '#8E735B' },
    { id: 'fresh', name: 'Fresh Pastel (Xanh Dương / Kem)', hex: '#8ECAE6' },
  ];

  // Dynamic curated 3-piece combo calculation based on selections
  let topProduct: Product = PRODUCTS[0];
  let bottomProduct: Product = PRODUCTS[2];
  let accessoryProduct: Product = PRODUCTS[6];
  let storyNarration = "Bộ trang phục mang hơi thở đường phố Sài Gòn với áo thun boxy dày dặn kết hợp cùng quần parachute ống suông và túi đeo chéo tiện ích, tạo nên vẻ ngoài tự do không gò bó.";

  if (occasion === 'night-out') {
    topProduct = PRODUCTS[1]; // Hoodie
    bottomProduct = PRODUCTS[9]; // Raw denim
    accessoryProduct = PRODUCTS[7]; // Cap
    storyNarration = "Phong thái bí ẩn của đêm Sài Gòn với áo Hoodie Zip YKK 2 chiều phối cùng quần Raw Denim 13.5oz dày dặn và mũ Dad Hat thêu 3D ấn tượng.";
  } else if (occasion === 'dating') {
    topProduct = PRODUCTS[5]; // Polo knit
    bottomProduct = PRODUCTS[9]; // Denim
    accessoryProduct = PRODUCTS[6]; // Crossbody
    storyNarration = "Sự kết hợp tinh tế giữa phong cách Old Money phóng khoáng và streetwear đương đại với áo Polo dệt kim Jacquard mềm mát và phom quần suông thanh lịch.";
  } else if (occasion === 'creative-work') {
    topProduct = PRODUCTS[3]; // Varsity jacket
    bottomProduct = PRODUCTS[2]; // Cargo
    accessoryProduct = PRODUCTS[7]; // Cap
    storyNarration = "Nguồn cảm hứng bất tận từ áo khoác bóng chày len dạ thêu Chenille cao cấp đi cùng quần túi hộp đa năng, hoàn hảo cho ngày dài làm việc sáng tạo.";
  }

  const comboItems = [topProduct, bottomProduct, accessoryProduct];
  const originalComboTotal = comboItems.reduce((s, p) => s + p.price, 0);
  const bundleDiscount = 100000;
  const finalComboPrice = originalComboTotal - bundleDiscount;

  const handleAddAll = () => {
    const itemsToAdd = comboItems.map((p) => ({
      product: p,
      color: p.colors[0],
      size: p.sizes[0] || ('M' as ProductSize)
    }));
    onAddComboToCart(itemsToAdd);
    setAddedComboNotice(true);
    setTimeout(() => {
      setAddedComboNotice(false);
      onClose();
    }, 1500);
  };

  const handleRegenerate = () => {
    setIsGenerating(true);
    setTimeout(() => setIsGenerating(false), 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div 
        className="fixed inset-0 bg-black/75 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-3xl bg-white rounded-xs shadow-2xl overflow-hidden z-10 border border-neutral-200 my-auto animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-neutral-950 text-white flex items-center justify-between border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-amber-400 text-black flex items-center justify-center font-bold shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black uppercase font-heading tracking-wider">
                WEAR YOUR STORY • AI OUTFIT STYLIST
              </h2>
              <p className="text-[10px] text-neutral-400 font-mono tracking-widest uppercase">GỢI Ý PHỐI ĐỒ STREETWEAR THEO CÁ TÍNH CỦA BẠN</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Controls */}
          <div className="space-y-4 bg-neutral-50 p-4 rounded-xs border border-neutral-200">
            {/* Occasion Selection */}
            <div>
              <label className="text-xs font-bold text-neutral-800 uppercase tracking-wider block mb-2">
                1. Chọn dịp / Hoàn cảnh bạn muốn mặc:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {occasions.map((occ) => (
                  <button
                    key={occ.id}
                    onClick={() => {
                      setOccasion(occ.id);
                      handleRegenerate();
                    }}
                    className={`p-2.5 rounded-xs border text-left transition-all ${
                      occasion === occ.id
                        ? 'border-black bg-black text-white'
                        : 'border-neutral-200 bg-white text-neutral-800 hover:border-neutral-400'
                    }`}
                  >
                    <div className="text-xs font-bold">{occ.name}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Vibe tone Selection */}
            <div>
              <label className="text-xs font-bold text-neutral-800 uppercase tracking-wider block mb-2">
                2. Chọn tông màu bạn thích:
              </label>
              <div className="flex flex-wrap gap-2">
                {vibeTones.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => {
                      setVibeTone(v.id);
                      handleRegenerate();
                    }}
                    className={`px-3 py-1.5 rounded-xs border text-xs font-bold flex items-center gap-2 transition-all ${
                      vibeTone === v.id
                        ? 'border-black bg-neutral-900 text-white'
                        : 'border-neutral-200 bg-white text-neutral-700 hover:border-neutral-400'
                    }`}
                  >
                    <span className="w-3 h-3 rounded-full border border-white/40" style={{ backgroundColor: v.hex }} />
                    <span>{v.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Curated Outfit Result Card */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-extrabold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-xs uppercase tracking-wider">
                  OUTFIT COMBO RECOMMENDATION
                </span>
                <h3 className="text-base font-black font-heading uppercase text-neutral-900 mt-1">
                  SET ĐỒ ĐƯỜNG PHỐ HOÀN CHỈNH
                </h3>
              </div>

              <button
                onClick={handleRegenerate}
                className="text-xs text-neutral-500 hover:text-black font-bold flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
                <span>Làm mới</span>
              </button>
            </div>

            {/* Story Philosophy Quote */}
            <div className="p-3.5 bg-neutral-900 text-white rounded-xs text-xs italic leading-relaxed border-l-4 border-amber-400">
              "{storyNarration}"
            </div>

            {/* 3 Products in Outfit */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {comboItems.map((prod, idx) => (
                <div 
                  key={prod.id} 
                  className="p-3 bg-neutral-50 border border-neutral-200 rounded-xs flex flex-col justify-between hover:border-neutral-400 transition-colors"
                >
                  <div className="aspect-4/5 rounded-xs overflow-hidden bg-neutral-200 mb-2 relative">
                    <img 
                      src={prod.colors[0]?.image} 
                      alt={prod.name}
                      className="w-full h-full object-cover" 
                    />
                    <span className="absolute top-2 left-2 bg-black text-white text-[9px] font-black px-1.5 py-0.5 rounded-xs">
                      ITEM 0{idx + 1}
                    </span>
                  </div>

                  <div>
                    <h4 
                      onClick={() => onQuickView(prod)}
                      className="text-xs font-bold text-neutral-900 line-clamp-1 hover:underline cursor-pointer"
                    >
                      {prod.name}
                    </h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">{prod.fit}</p>
                  </div>

                  <div className="flex items-center justify-between pt-2 mt-2 border-t border-neutral-200">
                    <span className="text-xs font-bold font-mono-num text-neutral-900">
                      {formatVND(prod.price)}
                    </span>
                    <button
                      onClick={() => onQuickView(prod)}
                      className="text-[10px] text-neutral-600 hover:text-black underline font-bold"
                    >
                      Xem chi tiết
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Bundle Price & Add All Button */}
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xs flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <div className="text-xs text-neutral-600">
                  Tổng giá trị combo gốc: <span className="line-through font-mono">{formatVND(originalComboTotal)}</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-black font-mono-num text-neutral-900">{formatVND(finalComboPrice)}</span>
                  <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-xs">
                    Tiết kiệm ngay 100.000₫ khi mua cả set
                  </span>
                </div>
              </div>

              <button
                onClick={handleAddAll}
                className="w-full sm:w-auto px-6 py-3.5 bg-black hover:bg-neutral-800 text-white text-xs font-extrabold uppercase rounded-xs transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <ShoppingBag className="w-4 h-4 text-amber-400" />
                <span>Thêm Cả Bộ (3 Món) Vào Giỏ</span>
              </button>
            </div>

            {addedComboNotice && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xs flex items-center justify-center gap-2 animate-in fade-in">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Đã thêm toàn bộ set đồ vào giỏ hàng của bạn!</span>
              </div>
            )}

          </div>

        </div>
      </div>
    </div>
  );
};
