import React, { useState } from 'react';
import { LOOKBOOKS, PRODUCTS } from '../data/mockData';
import { Product, ProductColor, ProductSize, LookbookItem } from '../types';
import { formatVND } from '../utils/formatters';
import { ShoppingBag, Eye, ArrowRight, Sparkles, Plus, X } from 'lucide-react';

interface ShoppableLookbookProps {
  lookbooks?: LookbookItem[];
  products?: Product[];
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, color: ProductColor, size: ProductSize) => void;
}

export const ShoppableLookbook: React.FC<ShoppableLookbookProps> = ({
  lookbooks = LOOKBOOKS,
  products = PRODUCTS,
  onQuickView,
  onAddToCart,
}) => {
  const activeLookbooks = lookbooks && lookbooks.length > 0 ? lookbooks : LOOKBOOKS;
  const activeProducts = products && products.length > 0 ? products : PRODUCTS;
  const [activeLookbookIndex, setActiveLookbookIndex] = useState(0);
  const [activeHotspotProduct, setActiveHotspotProduct] = useState<Product | null>(null);

  const lookbook = activeLookbooks[activeLookbookIndex] || activeLookbooks[0];

  const handleHotspotClick = (productId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const product = activeProducts.find((p) => p.id === productId);
    if (product) {
      setActiveHotspotProduct(product);
    }
  };


  return (
    <section id="lookbook-section" className="py-16 sm:py-24 bg-[#111112] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-4 border-b border-neutral-800">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-amber-400 uppercase mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SHOP THE LOOK • WEAR YOUR STORY</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black font-heading tracking-tight uppercase text-white">
              INTERACTIVE LOOKBOOK 2026
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-neutral-400 max-w-md mt-2 md:mt-0">
            Chạm vào các điểm ghim tròn (+) trên người mẫu để khám phá và mua ngay từng món đồ trong outfit.
          </p>
        </div>

        {/* Lookbook Tabs */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar mb-8">
          {activeLookbooks.map((lb, idx) => (
            <button
              key={lb.id}
              onClick={() => {
                setActiveLookbookIndex(idx);
                setActiveHotspotProduct(null);
              }}
              className={`px-4 py-2 text-xs font-extrabold uppercase rounded-xs transition-all whitespace-nowrap cursor-pointer ${
                activeLookbookIndex === idx
                  ? 'bg-amber-400 text-black shadow-lg scale-105'
                  : 'bg-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-700'
              }`}
            >
              LOOK 0{idx + 1}: {lb.title}
            </button>
          ))}
        </div>

        {/* Main Lookbook Stage */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Interactive Image Container (8 cols) */}
          <div 
            className="lg:col-span-8 relative aspect-4/5 sm:aspect-16/10 rounded-xs overflow-hidden bg-neutral-900 border border-neutral-800 shadow-2xl group select-none"
            onClick={() => setActiveHotspotProduct(null)}
          >
            <img
              src={lookbook.image}
              alt={lookbook.title}
              className="w-full h-full object-cover object-center"
            />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />

            {/* Hotspots */}
            {lookbook.hotspots.map((hs, idx) => {
              const matchedProduct = activeProducts.find((p) => p.id === hs.productId);
              if (!matchedProduct) return null;
              const isSelected = activeHotspotProduct?.id === hs.productId;

              return (
                <div
                  key={idx}
                  style={{ top: `${hs.y}%`, left: `${hs.x}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20"
                >
                  {/* Pulsating Ping Marker */}
                  <button
                    onClick={(e) => handleHotspotClick(hs.productId, e)}
                    className={`relative w-8 h-8 rounded-full flex items-center justify-center transition-transform hover:scale-125 cursor-pointer ${
                      isSelected
                        ? 'bg-amber-400 text-black ring-4 ring-white/50 scale-125'
                        : 'bg-black/70 hover:bg-amber-400 text-white hover:text-black backdrop-blur-md border border-white/80'
                    }`}
                    title={matchedProduct.name}
                  >
                    <span className="absolute inset-0 rounded-full bg-amber-400/40 animate-ping" />
                    <Plus className="w-4 h-4 relative z-10" />
                  </button>
                </div>
              );
            })}

            {/* Lookbook Badge */}
            <div className="absolute bottom-4 left-4 z-10">
              <span className="bg-black/70 backdrop-blur-md px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-white rounded-xs border border-neutral-700">
                {lookbook.title}
              </span>
              <p className="text-[11px] text-neutral-300 mt-1 drop-shadow-md">
                {lookbook.subtitle}
              </p>
            </div>
          </div>

          {/* Shoppable Products Panel (4 cols) */}
          <div className="lg:col-span-4 flex flex-col space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
              <h3 className="text-sm font-extrabold uppercase tracking-wider text-neutral-300">
                SẢN PHẨM TRONG OUTFIT ({lookbook.hotspots.length})
              </h3>
              {activeHotspotProduct && (
                <button
                  onClick={() => setActiveHotspotProduct(null)}
                  className="text-xs text-neutral-400 hover:text-white flex items-center gap-1"
                >
                  <span>Xem tất cả</span>
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Product items in this lookbook */}
            <div className="space-y-3">
              {(activeHotspotProduct ? [activeHotspotProduct] : lookbook.hotspots.map(hs => PRODUCTS.find(p => p.id === hs.productId)).filter(Boolean) as Product[]).map((product) => (
                <div
                  key={product.id}
                  className={`p-3 bg-neutral-900 border rounded-xs transition-all flex gap-3.5 ${
                    activeHotspotProduct?.id === product.id
                      ? 'border-amber-400 ring-1 ring-amber-400/50 bg-neutral-850'
                      : 'border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <img
                    src={product.colors[0]?.image}
                    alt={product.name}
                    className="w-20 h-24 object-cover object-center rounded-xs shrink-0 cursor-pointer"
                    onClick={() => onQuickView(product)}
                  />

                  <div className="flex flex-col justify-between flex-1 min-w-0">
                    <div>
                      <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">
                        {product.code}
                      </span>
                      <h4 
                        onClick={() => onQuickView(product)}
                        className="text-xs font-bold text-white hover:underline cursor-pointer truncate mt-0.5"
                      >
                        {product.name}
                      </h4>
                      <p className="text-[11px] text-neutral-400 font-medium">
                        {product.fit}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <span className="text-sm font-black font-mono-num text-white">
                        {formatVND(product.price)}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onQuickView(product)}
                          className="p-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white rounded-xs transition-colors"
                          title="Xem chi tiết"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onAddToCart(product, product.colors[0], product.sizes[0])}
                          className="px-2.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-extrabold rounded-xs flex items-center gap-1 transition-colors"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>Thêm</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Lookbook Quote / Callout */}
            <div className="p-4 bg-neutral-900/60 border border-neutral-800 rounded-xs text-xs text-neutral-400 italic">
              "Thời trang không chỉ là những gì bạn mặc, mà là cách bạn kể câu chuyện của chính mình cho thế giới."
              <div className="text-right not-italic font-bold text-neutral-300 text-[10px] mt-1 uppercase">
                — BÔNG STORE DESIGN TEAM
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
