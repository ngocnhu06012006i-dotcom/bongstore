import { Product, Collection, LookbookItem, StoreBranch, Voucher, Review, HeroSlide, SiteSettings, CategoryShowcaseItem } from '../types';

export const DEFAULT_HERO_SLIDES: HeroSlide[] = [
  {
    id: 1,
    badge: 'SPRING / SUMMER 2026 DROP',
    title: 'WEAR YOUR STORY',
    subtitle: 'BỘ SƯU TẬP ĐỊNH HÌNH PHONG CÁCH',
    description: 'Mỗi cá tính là một câu chuyện độc nhất. Hãy khoác lên mình phong thái tự tin và tự do của thế hệ đường phố mới.',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1800&auto=format&fit=crop',
    collectionSlug: 'wear-your-story',
    ctaText: 'KHÁM PHÁ BỘ SƯU TẬP'
  },
  {
    id: 2,
    badge: 'URBAN CHRONICLE EDITION',
    title: 'SAIGON UNDERGROUND',
    subtitle: 'CHẤT LIỆU CAO CẤP • PHOM DÁNG BOXY',
    description: 'Dòng sản phẩm Heavyweight Cotton 260GSM - 380GSM xử lý chống co rút và hoàn thiện chi tiết chuẩn quốc tế.',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1800&auto=format&fit=crop',
    collectionSlug: 'urban-chronicle',
    ctaText: 'MUA NGAY'
  },
  {
    id: 3,
    badge: 'SIGNATURE BLOOM DROP',
    title: 'BLOOM IN REBELLION',
    subtitle: 'NĂNG LƯỢNG TRẺ TRUNG • PHÓNG KHOÁNG',
    description: 'Họa tiết hoa Bông cách điệu kết hợp kỹ thuật thêu xù Chenille và in lụa nghệ thuật trên nền vải bền bỉ.',
    image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=1800&auto=format&fit=crop',
    collectionSlug: 'signature-bloom',
    ctaText: 'XEM CHI TIẾT'
  }
];

export const DEFAULT_CATEGORIES: CategoryShowcaseItem[] = [
  {
    id: 'tee',
    name: 'ÁO THUN / TEES',
    desc: 'Boxy Heavyweight 260GSM',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=800&auto=format&fit=crop',
    category: 'tee',
    count: '15+ Mẫu'
  },
  {
    id: 'hoodie',
    name: 'HOODIE & SWEATER',
    desc: 'French Terry 380GSM Khóa YKK 2 Chiều',
    image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=800&auto=format&fit=crop',
    category: 'hoodie-sweater',
    count: '10+ Mẫu'
  },
  {
    id: 'jacket',
    name: 'ÁO KHOÁC / JACKETS',
    desc: 'Varsity & Techwear Outerwear',
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=800&auto=format&fit=crop',
    category: 'jacket',
    count: '8+ Mẫu'
  },
  {
    id: 'pants',
    name: 'QUẦN / PANTS & CARGO',
    desc: 'Parachute & Baggy Denim',
    image: 'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?q=80&w=800&auto=format&fit=crop',
    category: 'pants',
    count: '12+ Mẫu'
  },
  {
    id: 'acc',
    name: 'PHỤ KIỆN / ACCESSORIES',
    desc: 'Balo, Túi Crossbody & Dad Hats',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=800&auto=format&fit=crop',
    category: 'accessories',
    count: '18+ Mẫu'
  }
];

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  storeName: 'BÔNG STORE',
  slogan: 'WEAR YOUR STORY',
  hotline: '1900 6868',
  email: 'cskh@bongstore.vn',
  address: '139 Lê Văn Sỹ, Phường 13, Quận 3, TP. Hồ Chí Minh',
  operatingHours: '09:00 - 22:30 hàng ngày',
  freeShippingThreshold: 499000,
  bankName: 'MB Bank (Ngân hàng TMCP Quân Đội)',
  bankAccountNumber: '0988668899',
  bankAccountName: 'BONG STORE VIETNAM',
  bankBranch: 'Chi nhánh Sài Gòn (TP.HCM)',
  bankQrCodeUrl: '',
  announcementTexts: [
    'MIỄN PHÍ VẬN CHUYỂN toàn quốc cho đơn hàng từ 499.000₫',
    'Nhập mã "BONGSTORE10" giảm 10% cho đơn hàng đầu tiên',
    'BỘ SƯU TẬP MỚI 2026 "WEAR YOUR STORY" ĐÃ CHÍNH THỨC RA MẮT!'
  ],
  marqueeTexts: [
    'WEAR YOUR STORY',
    'BÔNG STORE 2026',
    'PREMIUM COMPACT COTTON 260GSM',
    'SAIGON STREETWEAR CULTURE',
    'DROP SHOULDER BOXY FIT',
    'FREE NATIONWIDE SHIPPING',
    'AUTHENTIC STREET WEAR'
  ],
  facebookUrl: 'https://facebook.com',
  instagramUrl: 'https://instagram.com',
  tiktokUrl: 'https://tiktok.com',
  story: {
    badge: 'CÂU CHUYỆN THƯƠNG HIỆU',
    title: 'BÔNG STORE',
    slogan: 'WEAR YOUR STORY.',
    introParagraph: 'Thành lập từ niềm đam mê văn hóa đường phố và nghệ thuật may mặc nguyên bản, BÔNG STORE ra đời với sứ mệnh trao cho bạn sự tự tin để tự do thể hiện cá tính riêng.',
    detailParagraph: 'Với slogan "WEAR YOUR STORY", chúng tôi tin rằng mỗi bộ trang phục bạn khoác lên người không đơn thuần là vải vóc mà là một chương trong câu chuyện cuộc đời bạn — về những hoài bão, những hành trình và dấu ấn tuổi trẻ.',
    stat1Number: '100.000+',
    stat1Label: 'Khách hàng yêu thích',
    stat2Number: '260-380',
    stat2Label: 'GSM Vải siêu dày dặn',
    image1: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=800&auto=format&fit=crop',
    image2: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=800&auto=format&fit=crop',
    pillar1Title: 'CHẤT LIỆU CAO CẤP TUYỂN CHỌN',
    pillar1Desc: 'Sử dụng 100% sợi Compact Cotton 2 chiều và 4 chiều xử lý Enzyme Wash mềm mịn, thấm hút mồ hôi tối đa và thoáng mát cả ngày dài.',
    pillar2Title: 'PHOM DÁNG BOXY & OVERSIZE',
    pillar2Desc: 'Nghiên cứu nhân trắc học người Việt để tạo nên tỷ lệ vai rơi, hạ nách và độ dài hoàn hảo, tôn dáng tự nhiên và che khuyết điểm vượt trội.',
    pillar3Title: 'TINH THẦN ĐƯỜNG PHỐ NGUYÊN BẢN',
    pillar3Desc: 'Mỗi chi tiết từ tag dệt, cúc khắc laser đến hình in lụa thủ công đều được chăm chút tỉ mỉ, cam kết chất lượng bền bỉ vượt thời gian.'
  }
};


export const COLLECTIONS: Collection[] = [
  {
    id: 'col-1',
    name: 'WEAR YOUR STORY 2026',
    slug: 'wear-your-story',
    tagline: 'Mỗi bộ trang phục là một trang sách kể về cá tính của chính bạn',
    description: 'Bộ sưu tập định hình tinh thần thương hiệu BÔNG STORE với chất liệu Compact Cotton 260gsm xử lý chống co rút, phom dáng Boxy Oversize thời thượng.',
    heroImage: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1600&auto=format&fit=crop',
    lookbookCount: 12,
    year: '2026'
  },
  {
    id: 'col-2',
    name: 'URBAN CHRONICLE',
    slug: 'urban-chronicle',
    tagline: 'Âm hưởng đường phố Sài Gòn giao thoa phong cách Cyber Grunge',
    description: 'Lấy cảm hứng từ những góc phố đêm, ánh đèn neon và nhịp sống năng động của giới trẻ thành thị. Các thiết kế Outerwear và Quần Parachute đa tiện ích.',
    heroImage: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1600&auto=format&fit=crop',
    lookbookCount: 8,
    year: '2026'
  },
  {
    id: 'col-3',
    name: 'RAW STORY',
    slug: 'raw-story',
    tagline: 'Tối giản nguyên bản – Tinh tế trên từng đường may thủ công',
    description: 'Bảng màu trung tính Earthy Tones: Xám xi măng, Be cát, Đen khói cùng kỹ thuật dệt tổ ong Waffle và thêu vi tính mật độ cao.',
    heroImage: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1600&auto=format&fit=crop',
    lookbookCount: 10,
    year: '2025'
  },
  {
    id: 'col-4',
    name: 'SIGNATURE BLOOM',
    slug: 'signature-bloom',
    tagline: 'Bông hoa nở rộ giữa lòng bê tông đô thị',
    description: 'Họa tiết hoa Bông cách điệu kết hợp kỹ thuật in lụa nứt độc quyền và phối màu pastel cá tính mang lại năng lượng tích cực.',
    heroImage: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=1600&auto=format&fit=crop',
    lookbookCount: 6,
    year: '2025'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Áo Thun Bông Store "WEAR YOUR STORY" Boxy Cut',
    code: 'BS-TEE-001',
    price: 420000,
    originalPrice: 520000,
    category: 'tee',
    collection: 'wear-your-story',
    colors: [
      {
        name: 'Washed Black (Đen Khói)',
        hex: '#1E1E20',
        image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Cream Butter (Kem Bơ)',
        hex: '#F4EEDB',
        image: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Sage Green (Xanh Xô Thơm)',
        hex: '#9AA796',
        image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    inStockSizes: { S: 15, M: 28, L: 20, XL: 8, XXL: 0 },
    description: 'Mẫu áo thun chủ đạo của bộ sưu tập WEAR YOUR STORY 2026. Thiết kế phom Boxy Oversized hiện đại với tỷ lệ vai rơi thoải mái, cổ bo rib dệt dày 3cm chống dão tuyệt đối sau 100 lần giặt.',
    material: '100% Premium Compact Cotton',
    gsm: '260 GSM Heavyweight',
    fit: 'Boxy Oversized Fit - Tôn dáng cả nam & nữ',
    features: [
      'Xử lý bề mặt Bio-Polishing hạn chế đổ lông',
      'In lụa thủ công Plastisol siêu bền không nứt',
      'Tag cổ dệt thêu vi tính BÔNG STORE cao cấp',
      'Đường may Double-Needle chắc chắn'
    ],
    isNew: true,
    isBestSeller: true,
    discountPercent: 19,
    rating: 4.9,
    reviewCount: 142,
    createdAt: '2026-08-15'
  },
  {
    id: 'prod-2',
    name: 'Áo Hoodie Zip Bông Store "Saigon Chronicle" Heavyweight',
    code: 'BS-HOD-002',
    price: 690000,
    originalPrice: 790000,
    category: 'hoodie-sweater',
    collection: 'urban-chronicle',
    colors: [
      {
        name: 'Midnight Black (Đen Đêm)',
        hex: '#111111',
        image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Cement Heather (Xám Xi Măng)',
        hex: '#C5C6C7',
        image: 'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inStockSizes: { S: 10, M: 18, L: 25, XL: 12, XXL: 5 },
    description: 'Áo khoác hoodie 2 đầu khóa zip kim loại YKK cao cấp. Nón 2 lớp dày đứng phom chuẩn streetwear quốc tế. Hình in sau lưng lấy cảm hứng từ bản đồ đô thị Sài Gòn.',
    material: 'French Terry 100% Cotton Chân Cua',
    gsm: '380 GSM Siêu Dày Dặn',
    fit: 'Drop Shoulder Oversize',
    features: [
      'Khóa kéo 2 chiều Custom Bông Store Metal Zip',
      'Mũ 2 lớp giữ form đứng cực chuẩn',
      'Túi Kangaroo trước tiện lợi có ngăn phụ',
      'Bo chun tay và gấu dệt Spandex co giãn hồi phục tốt'
    ],
    isNew: true,
    isBestSeller: true,
    discountPercent: 13,
    rating: 5.0,
    reviewCount: 98,
    createdAt: '2026-08-20'
  },
  {
    id: 'prod-3',
    name: 'Quần Dài Parachute Bông Store Multi-Pocket Cargo',
    code: 'BS-PNT-003',
    price: 550000,
    originalPrice: 650000,
    category: 'pants',
    collection: 'urban-chronicle',
    colors: [
      {
        name: 'Olive Drab (Xanh Rêu Đậm)',
        hex: '#4B5320',
        image: 'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Stealth Black (Đen Nhám)',
        hex: '#1A1A1A',
        image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1517445312882-bc9910d016b7?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    inStockSizes: { S: 8, M: 22, L: 19, XL: 14, XXL: 0 },
    description: 'Quần dù ống suông rộng có dây rút gấu (Bungee Cinch Cord) cho phép biến hóa linh hoạt giữa ống suông và ống túm Jogger. Chất vải Poly Ripstop kháng nước nhẹ và chống nhăn.',
    material: 'Technical Nylon Ripstop & Microfiber',
    gsm: '220 GSM Siêu Nhẹ Thoáng',
    fit: 'Wide-Leg / Baggy Parachute Fit',
    features: [
      'Hệ thống 6 túi đa năng thời thượng',
      'Dây rút gấu kim loại điều chỉnh độ phồng',
      'Lưng thun kèm dây rút ẩn cao cấp',
      'Kháng nước nhẹ và dễ vệ sinh'
    ],
    isNew: false,
    isBestSeller: true,
    discountPercent: 15,
    rating: 4.8,
    reviewCount: 76,
    createdAt: '2026-07-28'
  },
  {
    id: 'prod-4',
    name: 'Áo Khoác Varsity Bông Store "Bloom Club" Wool & Leather',
    code: 'BS-JKT-004',
    price: 890000,
    originalPrice: 1100000,
    category: 'jacket',
    collection: 'signature-bloom',
    colors: [
      {
        name: 'Forest Green & Cream',
        hex: '#1E3F20',
        image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1548883354-7622d03aca27?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1548883354-7622d03aca27?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Charcoal Black & White',
        hex: '#2B2B2B',
        image: 'https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['M', 'L', 'XL'],
    inStockSizes: { S: 0, M: 12, L: 15, XL: 6, XXL: 0 },
    description: 'Áo khoác bóng chày biểu tượng của Bông Store. Thân áo bằng dạ len cao cấp phối tay áo giả da PU viền nổi, ngực thêu xù Chenille logo chữ Bông cách điệu.',
    material: 'Dạ Len Tuyết Phối Tay Da PU Cao Cấp',
    gsm: '450 GSM Giữ Ấm Tối Ưu',
    fit: 'Relaxed Retro Varsity Fit',
    features: [
      'Thêu xù thủ công Chenille Patchwork cao cấp',
      'Lót gió quả trám chần bông êm ái chống lạnh',
      'Nút bấm kim loại dập nổi logo Bông',
      'Bo len sọc 3 màu dệt nguyên bản'
    ],
    isNew: true,
    isLimited: true,
    discountPercent: 19,
    rating: 4.9,
    reviewCount: 64,
    createdAt: '2026-08-10'
  },
  {
    id: 'prod-5',
    name: 'Áo Sweater Bông Store "Raw Story" Minimalist Waffle',
    code: 'BS-SWT-005',
    price: 490000,
    originalPrice: 590000,
    category: 'hoodie-sweater',
    collection: 'raw-story',
    colors: [
      {
        name: 'Oatmeal Beige (Be Yến Mạch)',
        hex: '#E3DAC9',
        image: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Washed Charcoal (Xám Khói)',
        hex: '#3D3D3D',
        image: 'https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    inStockSizes: { S: 14, M: 25, L: 20, XL: 9, XXL: 0 },
    description: 'Áo nỉ cổ tròn dệt vân tổ ong waffle tinh tế. Thiết kế tối giản không logo to, tập trung hoàn toàn vào chất liệu vải cao cấp và cảm giác mềm mại khi tiếp xúc da.',
    material: 'Cotton Blend Waffle Knit Premium',
    gsm: '320 GSM Êm Ái Thoáng Khí',
    fit: 'Modern Relaxed Fit',
    features: [
      'Bề mặt dệt tổ ong 3D giữ ấm và thoáng mồ hôi',
      'Đường may phẳng Flat-Lock không gây cọ xát',
      'Tag da thêu dập chìm bên hông áo',
      'Bền màu và giữ phom hoàn hảo'
    ],
    isNew: false,
    isBestSeller: false,
    discountPercent: 17,
    rating: 4.7,
    reviewCount: 39,
    createdAt: '2026-06-18'
  },
  {
    id: 'prod-6',
    name: 'Áo Polo Dệt Kim Bông Store "Urban Vibe" Collar Shirt',
    code: 'BS-POL-006',
    price: 460000,
    originalPrice: 550000,
    category: 'polo-shirt',
    collection: 'wear-your-story',
    colors: [
      {
        name: 'Cream & Coffee Stripe',
        hex: '#D7C4B7',
        image: 'https://images.unsplash.com/photo-1625910513413-7e15d862e391?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1625910513413-7e15d862e391?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Navy Blue & White',
        hex: '#1B263B',
        image: 'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1625910513413-7e15d862e391?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    inStockSizes: { S: 12, M: 20, L: 18, XL: 7, XXL: 0 },
    description: 'Áo polo dệt kim phong cách Old Money pha trộn Streetwear. Cổ bẻ mở không cúc tạo nét phóng khoáng, thanh lịch khi đi cafe hay dạo phố.',
    material: 'Cotton Silk Knit Mềm Mát',
    gsm: '240 GSM Co Giãn 4 Chiều',
    fit: 'Comfort Fit - Không gò bó',
    features: [
      'Kỹ thuật dệt vi tính Jacquard kẻ sọc tinh tế',
      'Không cần ủi (nhăn tự duỗi khi mặc)',
      'Thấm hút mồ hôi vượt trội thích hợp khí hậu Việt Nam'
    ],
    isNew: true,
    isBestSeller: true,
    discountPercent: 16,
    rating: 4.9,
    reviewCount: 88,
    createdAt: '2026-08-01'
  },
  {
    id: 'prod-7',
    name: 'Túi Đeo Chéo Bông Store "Utility Crossbody" Waterproof',
    code: 'BS-ACC-007',
    price: 350000,
    originalPrice: 420000,
    category: 'accessories',
    collection: 'urban-chronicle',
    colors: [
      {
        name: 'Matte Black (Đen Mờ)',
        hex: '#0D0D0D',
        image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Silver Reflective (Bạc Phản Quang)',
        hex: '#C0C0C0',
        image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S'],
    inStockSizes: { S: 45, M: 0, L: 0, XL: 0, XXL: 0 },
    description: 'Túi đeo chéo form hộp hiện đại với chất liệu Cordura chống thấm nước 100%. Quai đeo bản to 4cm có đệm vai và khóa bấm Fidlock kim loại cao cấp.',
    material: 'Cordura 1000D Chống Trầy Xước Chống Nước',
    gsm: 'Chống Thấm Nước Cấp Độ 4',
    fit: 'Freesize - Dây đeo tăng giảm linh hoạt',
    features: [
      'Chứa vừa iPad Mini, điện thoại, sạc dự phòng, ví tiền',
      'Dây kéo chống nước ép nhiệt Seam-Sealed',
      'Móc khóa hợp kim nhôm Anodized không rỉ sét'
    ],
    isNew: false,
    isBestSeller: true,
    discountPercent: 17,
    rating: 4.9,
    reviewCount: 112,
    createdAt: '2026-07-15'
  },
  {
    id: 'prod-8',
    name: 'Nón Lưỡi Trai Bông Store "Storyteller" Washed Cap',
    code: 'BS-ACC-008',
    price: 260000,
    originalPrice: 320000,
    category: 'accessories',
    collection: 'wear-your-story',
    colors: [
      {
        name: 'Vintage Washed Black',
        hex: '#2B2C2D',
        image: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1575428652377-a2d80e2277fc?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1575428652377-a2d80e2277fc?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Mocha Khaki (Nâu Cà Phê)',
        hex: '#8E735B',
        image: 'https://images.unsplash.com/photo-1575428652377-a2d80e2277fc?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1575428652377-a2d80e2277fc?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S'],
    inStockSizes: { S: 60, M: 0, L: 0, XL: 0, XXL: 0 },
    description: 'Mũ lưỡi trai phong cách Dad Hat cổ điển. Chất liệu 100% Cotton Chino xử lý hiệu ứng giặt wash cổ điển mềm mại ôm đầu cực đẹp.',
    material: '100% Cotton Chino Washed Soft Handfeel',
    gsm: 'Form Mềm Cổ Điển',
    fit: 'Freesize - Khóa cài kim loại tùy chỉnh',
    features: [
      'Thêu chữ "WEAR YOUR STORY" nổi sắc nét 3D',
      'Đai cài kim loại khắc laser logo Bông',
      'Lót thấm mồ hôi êm ái chống ố vàng'
    ],
    isNew: false,
    isBestSeller: true,
    discountPercent: 19,
    rating: 4.8,
    reviewCount: 95,
    createdAt: '2026-07-10'
  },
  {
    id: 'prod-9',
    name: 'Áo Thun Bông Store "Bloom Graphic" Graphic Tee',
    code: 'BS-TEE-009',
    price: 390000,
    originalPrice: 480000,
    category: 'tee',
    collection: 'signature-bloom',
    colors: [
      {
        name: 'Off-White (Trắng Ngà)',
        hex: '#F9F9F6',
        image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Sky Blue (Xanh Thiên Thanh)',
        hex: '#8ECAE6',
        image: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    inStockSizes: { S: 20, M: 35, L: 28, XL: 10, XXL: 0 },
    description: 'Họa tiết hoa Bông nở cách điệu theo phong cách nghệ thuật đương đại. Sắc màu tươi trẻ tràn đầy năng lượng tích cực của tuổi trẻ.',
    material: '100% Compact Cotton 250 GSM',
    gsm: '250 GSM Thoáng Mát',
    fit: 'Standard Oversize Fit',
    features: [
      'In lụa sắc nét chuyển sắc Gradient mịn màng',
      'Đường chỉ viền may cuộn 3 kim tinh tế',
      'Mặt vải êm mịn chống xù lông'
    ],
    isNew: true,
    isBestSeller: false,
    discountPercent: 18,
    rating: 4.8,
    reviewCount: 52,
    createdAt: '2026-08-22'
  },
  {
    id: 'prod-10',
    name: 'Quần Jeans Bông Store "Raw Denim" Wide-Leg Pants',
    code: 'BS-PNT-010',
    price: 620000,
    originalPrice: 750000,
    category: 'pants',
    collection: 'raw-story',
    colors: [
      {
        name: 'Indigo Raw Blue (Xanh Indigo Mộc)',
        hex: '#1D2A44',
        image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1542272604-780c96856592?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=900&auto=format&fit=crop',
          'https://images.unsplash.com/photo-1542272604-780c96856592?q=80&w=900&auto=format&fit=crop'
        ]
      },
      {
        name: 'Vintage Washed Grey (Xám Bạc)',
        hex: '#4A4E54',
        image: 'https://images.unsplash.com/photo-1542272604-780c96856592?q=80&w=900&auto=format&fit=crop',
        secondaryImage: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=900&auto=format&fit=crop',
        gallery: [
          'https://images.unsplash.com/photo-1542272604-780c96856592?q=80&w=900&auto=format&fit=crop'
        ]
      }
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    inStockSizes: { S: 11, M: 24, L: 16, XL: 8, XXL: 0 },
    description: 'Quần jeans ống rộng dáng baggy với chất liệu denim 13.5oz dày dặn đứng form. Kỹ thuật giặt tạo nếp râu mèo thủ công ở gối và đùi.',
    material: '100% Cotton Heavy Denim 13.5oz',
    gsm: '13.5 oz Đứng Phom Siêu Đẹp',
    fit: 'Baggy Wide-Leg Silhouette',
    features: [
      'Đinh tán đồng và nút cài dập nổi Bông Store',
      'Đường chỉ may vàng cam phong cách vintage',
      'Tag da thật 100% may sau lưng quần'
    ],
    isNew: false,
    isBestSeller: true,
    discountPercent: 17,
    rating: 4.9,
    reviewCount: 71,
    createdAt: '2026-07-05'
  }
];

export const LOOKBOOKS: LookbookItem[] = [
  {
    id: 'lb-1',
    title: 'THE CHRONICLE OF SAIGON NIGHT',
    subtitle: 'Năng lượng đường phố bất tận của thế hệ trẻ',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=1600&auto=format&fit=crop',
    collectionSlug: 'wear-your-story',
    hotspots: [
      { x: 45, y: 35, productId: 'prod-1' },
      { x: 52, y: 70, productId: 'prod-3' }
    ]
  },
  {
    id: 'lb-2',
    title: 'SUBURBAN CONCRETE POETRY',
    subtitle: 'Tự do định hình cá tính với phom dáng Boxy và Oversize',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1600&auto=format&fit=crop',
    collectionSlug: 'urban-chronicle',
    hotspots: [
      { x: 48, y: 30, productId: 'prod-2' },
      { x: 55, y: 65, productId: 'prod-10' }
    ]
  },
  {
    id: 'lb-3',
    title: 'BLOOM IN RAW TEXTURE',
    subtitle: 'Sự hòa quyện giữa chất liệu cao cấp và cảm xúc chân thật',
    image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=1600&auto=format&fit=crop',
    collectionSlug: 'signature-bloom',
    hotspots: [
      { x: 50, y: 40, productId: 'prod-4' },
      { x: 35, y: 60, productId: 'prod-7' }
    ]
  },
  {
    id: 'lb-4',
    title: 'TIMELESS MONOCHROME ESSENTIALS',
    subtitle: 'Đơn giản nhưng chưa từng nhạt nhòa',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=1600&auto=format&fit=crop',
    collectionSlug: 'raw-story',
    hotspots: [
      { x: 50, y: 35, productId: 'prod-5' },
      { x: 40, y: 20, productId: 'prod-8' }
    ]
  }
];

export const STORE_BRANCHES: StoreBranch[] = [
  {
    id: 'store-1',
    name: 'BÔNG STORE FLAGSHIP SÀI GÒN',
    address: '139 Lê Văn Sỹ, Phường 13, Quận 3',
    district: 'Quận 3',
    city: 'TP. Hồ Chí Minh',
    phone: '0909.123.456',
    hours: '09:00 - 22:30 hàng ngày',
    image: 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?q=80&w=900&auto=format&fit=crop',
    isFlagship: true,
    googleMapQuery: '139 Lê Văn Sỹ, Quận 3, TP.HCM'
  },
  {
    id: 'store-2',
    name: 'BÔNG STORE NGUYỄN TRÃI',
    address: '246 Nguyễn Trãi, Phường Bến Thành, Quận 1',
    district: 'Quận 1',
    city: 'TP. Hồ Chí Minh',
    phone: '0909.789.101',
    hours: '09:30 - 22:30 hàng ngày',
    image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?q=80&w=900&auto=format&fit=crop',
    isFlagship: false,
    googleMapQuery: '246 Nguyễn Trãi, Quận 1, TP.HCM'
  },
  {
    id: 'store-3',
    name: 'BÔNG STORE HÀ NỘI BÀ TRIỆU',
    address: '88 Bà Triệu, Phường Hàng Bài, Quận Hoàn Kiếm',
    district: 'Quận Hoàn Kiếm',
    city: 'Hà Nội',
    phone: '0912.345.678',
    hours: '09:00 - 22:00 hàng ngày',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=900&auto=format&fit=crop',
    isFlagship: true,
    googleMapQuery: '88 Bà Triệu, Hoàn Kiếm, Hà Nội'
  },
  {
    id: 'store-4',
    name: 'BÔNG STORE HÀ NỘI PHỐ HUẾ',
    address: '175 Phố Huế, Quận Hai Bà Trưng',
    district: 'Quận Hai Bà Trưng',
    city: 'Hà Nội',
    phone: '0912.888.999',
    hours: '09:30 - 22:00 hàng ngày',
    image: 'https://images.unsplash.com/photo-1528698827591-e19ccd7bc23d?q=80&w=900&auto=format&fit=crop',
    isFlagship: false,
    googleMapQuery: '175 Phố Huế, Hai Bà Trưng, Hà Nội'
  },
  {
    id: 'store-5',
    name: 'BÔNG STORE ĐÀ NẴNG LÊ DUẨN',
    address: '320 Lê Duẩn, Phường Tân Chính, Quận Thanh Khê',
    district: 'Quận Thanh Khê',
    city: 'Đà Nẵng',
    phone: '0905.112.233',
    hours: '09:00 - 22:00 hàng ngày',
    image: 'https://images.unsplash.com/photo-1513094735237-8f2714d57c13?q=80&w=900&auto=format&fit=crop',
    isFlagship: true,
    googleMapQuery: '320 Lê Duẩn, Thanh Khê, Đà Nẵng'
  }
];

export const VOUCHERS: Voucher[] = [
  {
    code: 'BONGSTORE10',
    description: 'Giảm ngay 10% cho đơn hàng đầu tiên chào mừng bạn mới',
    discountPercent: 10,
    minOrderValue: 0,
    badge: 'MÃ BẠN MỚI'
  },
  {
    code: 'WEARYOURSTORY',
    description: 'Giảm 50.000₫ cho đơn hàng từ 500.000₫',
    discountAmount: 50000,
    minOrderValue: 500000,
    badge: 'HOT DEAL'
  },
  {
    code: 'FREESHIP',
    description: 'Miễn phí vận chuyển toàn quốc cho đơn từ 499.000₫',
    discountAmount: 30000,
    minOrderValue: 499000,
    badge: 'FREESHIP'
  },
  {
    code: 'VIPBONG100',
    description: 'Giảm 100.000₫ cho đơn hàng từ 1.200.000₫',
    discountAmount: 100000,
    minOrderValue: 1200000,
    badge: 'VIP CLUB'
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Minh Hoàng',
    rating: 5,
    date: '28/08/2026',
    comment: 'Áo thun form boxy siêu đẹp! Chất vải 260gsm cầm nặng tay, giặt máy 3 lần không hề bị co hay dão cổ. Slogan WEAR YOUR STORY in sau lưng cực kỳ có chất riêng.',
    sizePurchased: 'L',
    colorPurchased: 'Washed Black',
    fitFeedback: 'Vừa vặn hoàn hảo',
    verified: true
  },
  {
    id: 'rev-2',
    author: 'Phương Uyên',
    rating: 5,
    date: '25/08/2026',
    comment: 'Mình cao 1m62 nặng 48kg mặc size M giấu quần quá xinh luôn. Đóng gói hộp chỉn chu có thơm mùi nước hoa đặc trưng của Bông Store, được tặng kèm sticker cute xỉu!',
    sizePurchased: 'M',
    colorPurchased: 'Cream Butter',
    fitFeedback: 'Hơi rộng (Oversize đẹp)',
    verified: true
  },
  {
    id: 'rev-3',
    author: 'Đức Anh Nguyễn',
    rating: 5,
    date: '20/08/2026',
    comment: 'Áo hoodie zip 2 chiều kéo rất êm, mũ 2 lớp đứng form chứ không bị bẹp như mấy shop khác. Đáng tiền từng đồng luôn anh em ơi!',
    sizePurchased: 'XL',
    colorPurchased: 'Midnight Black',
    fitFeedback: 'Vừa vặn hoàn hảo',
    verified: true
  },
  {
    id: 'rev-4',
    author: 'Khánh Vy',
    rating: 5,
    date: '15/08/2026',
    comment: 'Giao hàng siêu nhanh, ở Sài Gòn đặt hôm trước hôm sau có liền. Nhân viên tư vấn size cực có tâm. Sẽ ủng hộ Bông dài dài!',
    sizePurchased: 'S',
    colorPurchased: 'Sage Green',
    fitFeedback: 'Vừa vặn hoàn hảo',
    verified: true
  }
];
