import { ProductSize } from '../types';

export const formatVND = (amount: number): string => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0
  }).format(amount).replace('₫', '₫');
};

export const FREE_SHIPPING_THRESHOLD = 499000;
export const STANDARD_SHIPPING_FEE = 30000;

export interface SizeRecommendationInput {
  heightCm: number;
  weightKg: number;
  fitPreference: 'standard' | 'oversize' | 'boxy';
}

export interface SizeRecommendationResult {
  recommendedSize: ProductSize;
  confidence: number;
  reason: string;
  measurements: {
    chest: string;
    length: string;
    shoulder: string;
  };
}

export const calculateSmartSize = (input: SizeRecommendationInput): SizeRecommendationResult => {
  const { heightCm, weightKg, fitPreference } = input;
  let baseScore = 0;

  // Height weighting
  if (heightCm < 162) baseScore += 1;
  else if (heightCm <= 170) baseScore += 2;
  else if (heightCm <= 178) baseScore += 3;
  else if (heightCm <= 185) baseScore += 4;
  else baseScore += 5;

  // Weight weighting
  if (weightKg < 52) baseScore += 1;
  else if (weightKg <= 62) baseScore += 2;
  else if (weightKg <= 74) baseScore += 3;
  else if (weightKg <= 86) baseScore += 4;
  else baseScore += 5;

  let average = baseScore / 2;

  if (fitPreference === 'oversize') {
    average += 0.8;
  } else if (fitPreference === 'boxy') {
    average += 0.4;
  }

  let recommendedSize: ProductSize = 'M';
  let measurements = { chest: '112cm', length: '71cm', shoulder: '52cm' };

  if (average <= 1.5) {
    recommendedSize = 'S';
    measurements = { chest: '106cm', length: '68cm', shoulder: '50cm' };
  } else if (average <= 2.5) {
    recommendedSize = 'M';
    measurements = { chest: '112cm', length: '71cm', shoulder: '52cm' };
  } else if (average <= 3.5) {
    recommendedSize = 'L';
    measurements = { chest: '118cm', length: '74cm', shoulder: '54cm' };
  } else if (average <= 4.5) {
    recommendedSize = 'XL';
    measurements = { chest: '124cm', length: '77cm', shoulder: '56cm' };
  } else {
    recommendedSize = 'XXL';
    measurements = { chest: '130cm', length: '79cm', shoulder: '58cm' };
  }

  return {
    recommendedSize,
    confidence: 96,
    reason: `Dựa trên chiều cao ${heightCm}cm, cân nặng ${weightKg}kg và gu mặc ${
      fitPreference === 'oversize' ? 'Rộng rãi Oversize' : fitPreference === 'boxy' ? 'Form Hộp Boxy Fit' : 'Vừa vặn Tiêu chuẩn'
    }, size ${recommendedSize} sẽ mang lại tỷ lệ cân đối và thoải mái nhất.`,
    measurements
  };
};
