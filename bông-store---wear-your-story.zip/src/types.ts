export type ProductCategory = 
  | 'all' 
  | 'tee' 
  | 'hoodie-sweater' 
  | 'jacket' 
  | 'pants' 
  | 'polo-shirt' 
  | 'accessories';

export type CollectionSlug = 
  | 'wear-your-story' 
  | 'urban-chronicle' 
  | 'raw-story' 
  | 'signature-bloom';

export type ProductSize = 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface ProductColor {
  name: string;
  hex: string;
  image: string;
  secondaryImage: string;
  gallery: string[];
}

export interface Product {
  id: string;
  name: string;
  code: string;
  price: number;
  originalPrice?: number;
  category: ProductCategory;
  collection: CollectionSlug;
  colors: ProductColor[];
  sizes: ProductSize[];
  inStockSizes: Record<ProductSize, number>;
  description: string;
  material: string;
  gsm: string;
  fit: string;
  features: string[];
  isNew?: boolean;
  isBestSeller?: boolean;
  isLimited?: boolean;
  discountPercent?: number;
  rating: number;
  reviewCount: number;
  createdAt: string;
}

export interface CartItem {
  id: string; // unique item id (productId + colorName + size)
  product: Product;
  selectedColor: ProductColor;
  selectedSize: ProductSize;
  quantity: number;
}

export interface Collection {
  id: string;
  name: string;
  slug: CollectionSlug;
  tagline: string;
  description: string;
  heroImage: string;
  lookbookCount: number;
  year: string;
}

export interface LookbookHotspot {
  x: number; // percentage 0-100
  y: number; // percentage 0-100
  productId: string;
}

export interface LookbookItem {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  collectionSlug: CollectionSlug;
  hotspots: LookbookHotspot[];
}

export interface Review {
  id: string;
  author: string;
  avatar?: string;
  rating: number;
  date: string;
  comment: string;
  sizePurchased: ProductSize;
  colorPurchased: string;
  fitFeedback: 'Vừa vặn hoàn hảo' | 'Hơi rộng (Oversize đẹp)' | 'Hơi ôm';
  verified: boolean;
}

export interface StoreBranch {
  id: string;
  name: string;
  address: string;
  district: string;
  city: 'TP. Hồ Chí Minh' | 'Hà Nội' | 'Đà Nẵng';
  phone: string;
  hours: string;
  image: string;
  isFlagship?: boolean;
  googleMapQuery: string;
}

export interface Voucher {
  code: string;
  description: string;
  discountPercent?: number;
  discountAmount?: number;
  minOrderValue: number;
  badge: string;
}

export interface HeroSlide {
  id: number | string;
  badge: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  collectionSlug: CollectionSlug;
  ctaText: string;
}

export interface StoryContent {
  badge: string;
  title: string;
  slogan: string;
  introParagraph: string;
  detailParagraph: string;
  stat1Number: string;
  stat1Label: string;
  stat2Number: string;
  stat2Label: string;
  image1: string;
  image2: string;
  pillar1Title: string;
  pillar1Desc: string;
  pillar2Title: string;
  pillar2Desc: string;
  pillar3Title: string;
  pillar3Desc: string;
}

export interface CategoryShowcaseItem {
  id: string;
  name: string;
  desc: string;
  image: string;
  category: ProductCategory;
  count: string;
}

export interface SiteSettings {
  storeName: string;
  slogan: string;
  hotline: string;
  email: string;
  address: string;
  operatingHours: string;
  freeShippingThreshold: number;
  bankName: string;
  bankAccountNumber: string;
  bankAccountName: string;
  bankBranch: string;
  bankQrCodeUrl?: string;
  announcementTexts: string[];
  marqueeTexts: string[];
  facebookUrl: string;
  instagramUrl: string;
  tiktokUrl: string;
  story: StoryContent;
}

export interface OrderInfo {
  orderId: string;
  customerName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  district: string;
  note?: string;
  paymentMethod: 'cod' | 'momo' | 'vnpay' | 'banking';
  items: CartItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  total: number;
  status: 'confirmed' | 'packing' | 'shipping' | 'delivered';
  createdAt: string;
  estimatedDelivery: string;
}


