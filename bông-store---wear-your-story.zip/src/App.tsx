import React, { useState, useEffect } from 'react';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Navbar } from './components/Navbar';
import { HeroSlider } from './components/HeroSlider';
import { MarqueeBanner } from './components/MarqueeBanner';
import { CategoryShowcase } from './components/CategoryShowcase';
import { ProductGrid } from './components/ProductGrid';
import { ShoppableLookbook } from './components/ShoppableLookbook';
import { StorySection } from './components/StorySection';
import { Footer } from './components/Footer';

// Modals & Drawers
import { QuickViewModal } from './components/QuickViewModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SearchModal } from './components/SearchModal';
import { SmartSizeGuideModal } from './components/SmartSizeGuideModal';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { StoreLocatorModal } from './components/StoreLocatorModal';
import { VipClubModal } from './components/VipClubModal';
import { AiStylistModal } from './components/AiStylistModal';
import { AdminPortal } from './components/AdminPortal';

import { PRODUCTS, VOUCHERS, DEFAULT_SITE_SETTINGS, DEFAULT_HERO_SLIDES, DEFAULT_CATEGORIES, LOOKBOOKS } from './data/mockData';
import { Product, ProductColor, ProductSize, CartItem, ProductCategory, CollectionSlug, Voucher, OrderInfo, SiteSettings, HeroSlide, CategoryShowcaseItem, LookbookItem } from './types';

// Real-time cross-tab broadcast channel
const syncChannel = typeof window !== 'undefined' && 'BroadcastChannel' in window 
  ? new BroadcastChannel('bongstore_realtime_sync') 
  : null;

export default function App() {
  // Products and Catalog State (Admin editable & persistent)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_products');
      return saved ? JSON.parse(saved) : PRODUCTS;
    } catch {
      return PRODUCTS;
    }
  });

  const [vouchers, setVouchers] = useState<Voucher[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_vouchers');
      return saved ? JSON.parse(saved) : VOUCHERS;
    } catch {
      return VOUCHERS;
    }
  });

  // Site Settings & Dynamic Content (Banners, Sliders, Story, Category Covers, Lookbook)
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    try {
      const saved = localStorage.getItem('bongstore_site_settings');
      return saved ? JSON.parse(saved) : DEFAULT_SITE_SETTINGS;
    } catch {
      return DEFAULT_SITE_SETTINGS;
    }
  });

  const [heroSlides, setHeroSlides] = useState<HeroSlide[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_hero_slides');
      return saved ? JSON.parse(saved) : DEFAULT_HERO_SLIDES;
    } catch {
      return DEFAULT_HERO_SLIDES;
    }
  });

  const [categoryShowcase, setCategoryShowcase] = useState<CategoryShowcaseItem[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_category_showcase');
      return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
    } catch {
      return DEFAULT_CATEGORIES;
    }
  });

  const [lookbooks, setLookbooks] = useState<LookbookItem[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_lookbooks');
      return saved ? JSON.parse(saved) : LOOKBOOKS;
    } catch {
      return LOOKBOOKS;
    }
  });

  const [lastServerUpdate, setLastServerUpdate] = useState<string | null>(null);

  // Initial fetch and Realtime synchronization from server backend
  useEffect(() => {
    let isMounted = true;

    const fetchServerData = async () => {
      try {
        const res = await fetch('/api/store-data');
        if (res.ok) {
          const json = await res.json();
          if (json.success && json.data && isMounted) {
            const d = json.data;
            if (Array.isArray(d.products) && d.products.length > 0) setProducts(d.products);
            if (Array.isArray(d.vouchers) && d.vouchers.length > 0) setVouchers(d.vouchers);
            if (d.siteSettings && typeof d.siteSettings === 'object') setSiteSettings(d.siteSettings);
            if (Array.isArray(d.heroSlides) && d.heroSlides.length > 0) setHeroSlides(d.heroSlides);
            if (Array.isArray(d.categoryShowcase) && d.categoryShowcase.length > 0) setCategoryShowcase(d.categoryShowcase);
            if (Array.isArray(d.lookbooks) && d.lookbooks.length > 0) setLookbooks(d.lookbooks);
            if (Array.isArray(d.orders)) setRecentOrders(d.orders);
            if (d.lastUpdated) setLastServerUpdate(d.lastUpdated);
          }
        }
      } catch {
        // Fallback to local storage if running in client-only mode
      }
    };

    fetchServerData();

    // Cross-tab broadcast listener (Instant 0ms sync between admin and storefront tabs)
    if (syncChannel) {
      const handleBroadcast = (event: MessageEvent) => {
        if (event.data?.type === 'STORE_SYNC' && event.data.data) {
          const d = event.data.data;
          if (d.products) setProducts(d.products);
          if (d.vouchers) setVouchers(d.vouchers);
          if (d.siteSettings) setSiteSettings(d.siteSettings);
          if (d.heroSlides) setHeroSlides(d.heroSlides);
          if (d.categoryShowcase) setCategoryShowcase(d.categoryShowcase);
          if (d.lookbooks) setLookbooks(d.lookbooks);
          if (d.orders) setRecentOrders(d.orders);
        }
      };
      syncChannel.addEventListener('message', handleBroadcast);

      // Storage event listener for fallback cross-tab updates
      const handleStorage = (e: StorageEvent) => {
        if (!e.newValue) return;
        try {
          const parsed = JSON.parse(e.newValue);
          if (e.key === 'bongstore_products') setProducts(parsed);
          if (e.key === 'bongstore_vouchers') setVouchers(parsed);
          if (e.key === 'bongstore_site_settings') setSiteSettings(parsed);
          if (e.key === 'bongstore_hero_slides') setHeroSlides(parsed);
          if (e.key === 'bongstore_category_showcase') setCategoryShowcase(parsed);
          if (e.key === 'bongstore_lookbooks') setLookbooks(parsed);
          if (e.key === 'bongstore_orders') setRecentOrders(parsed);
        } catch {
          // ignore
        }
      };
      window.addEventListener('storage', handleStorage);

      // Background periodic polling every 4s to sync across different devices/browsers
      const interval = setInterval(async () => {
        try {
          const res = await fetch('/api/store-data');
          if (res.ok) {
            const json = await res.json();
            if (json.success && json.data && json.lastUpdated && json.lastUpdated !== lastServerUpdate) {
              const d = json.data;
              if (Array.isArray(d.products)) setProducts(d.products);
              if (Array.isArray(d.vouchers)) setVouchers(d.vouchers);
              if (d.siteSettings) setSiteSettings(d.siteSettings);
              if (Array.isArray(d.heroSlides)) setHeroSlides(d.heroSlides);
              if (Array.isArray(d.categoryShowcase)) setCategoryShowcase(d.categoryShowcase);
              if (Array.isArray(d.lookbooks)) setLookbooks(d.lookbooks);
              if (Array.isArray(d.orders)) setRecentOrders(d.orders);
              setLastServerUpdate(json.lastUpdated);
            }
          }
        } catch {
          // Silent polling failure
        }
      }, 4000);

      return () => {
        isMounted = false;
        clearInterval(interval);
        syncChannel.removeEventListener('message', handleBroadcast);
        window.removeEventListener('storage', handleStorage);
      };
    }

    return () => {
      isMounted = false;
    };
  }, [lastServerUpdate]);

  // Helper to sync changes to server and broadcast to all open storefront tabs
  const syncChanges = async (payload: {
    products?: Product[];
    vouchers?: Voucher[];
    siteSettings?: SiteSettings;
    heroSlides?: HeroSlide[];
    categoryShowcase?: CategoryShowcaseItem[];
    lookbooks?: LookbookItem[];
    orders?: OrderInfo[];
  }) => {
    // 1. Broadcast locally for instant multi-tab sync
    if (syncChannel) {
      syncChannel.postMessage({ type: 'STORE_SYNC', data: payload });
    }

    // 2. Persist to Express backend server
    try {
      const res = await fetch('/api/store-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.lastUpdated) setLastServerUpdate(json.lastUpdated);
      }
    } catch (err) {
      console.error('[Sync] Failed to persist data to server:', err);
    }
  };

  // Admin View URL Routing State
  const [isAdminView, setIsAdminView] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname;
      const hash = window.location.hash;
      const search = window.location.search;
      return path === '/admin' || path.startsWith('/admin') || hash === '#admin' || search.includes('admin=true');
    }
    return false;
  });

  // URL Popstate / Hashchange listener for direct link navigation (/admin)
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname;
      const hash = window.location.hash;
      const search = window.location.search;
      const shouldBeAdmin = path === '/admin' || path.startsWith('/admin') || hash === '#admin' || search.includes('admin=true');
      setIsAdminView(shouldBeAdmin);
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const handleOpenAdmin = () => {
    setIsAdminView(true);
    if (typeof window !== 'undefined' && window.history) {
      window.history.pushState(null, '', '/admin');
    }
  };

  const handleExitAdmin = () => {
    setIsAdminView(false);
    if (typeof window !== 'undefined' && window.history) {
      window.history.pushState(null, '', '/');
    }
  };

  // Sync products to local storage
  useEffect(() => {
    localStorage.setItem('bongstore_products', JSON.stringify(products));
  }, [products]);

  // Sync vouchers to local storage
  useEffect(() => {
    localStorage.setItem('bongstore_vouchers', JSON.stringify(vouchers));
  }, [vouchers]);

  // Sync site settings to local storage
  useEffect(() => {
    localStorage.setItem('bongstore_site_settings', JSON.stringify(siteSettings));
  }, [siteSettings]);

  // Sync hero slides to local storage
  useEffect(() => {
    localStorage.setItem('bongstore_hero_slides', JSON.stringify(heroSlides));
  }, [heroSlides]);

  // Sync category showcase to local storage
  useEffect(() => {
    localStorage.setItem('bongstore_category_showcase', JSON.stringify(categoryShowcase));
  }, [categoryShowcase]);

  // Sync lookbooks to local storage
  useEffect(() => {
    localStorage.setItem('bongstore_lookbooks', JSON.stringify(lookbooks));
  }, [lookbooks]);

  // Persistence states
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_wishlist');
      return saved ? JSON.parse(saved) : ['prod-1', 'prod-2'];
    } catch {
      return ['prod-1', 'prod-2'];
    }
  });

  const [recentOrders, setRecentOrders] = useState<OrderInfo[]>(() => {
    try {
      const saved = localStorage.getItem('bongstore_orders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedVoucher, setAppliedVoucher] = useState<Voucher | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('bongstore_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('bongstore_wishlist', JSON.stringify(wishlistIds));
  }, [wishlistIds]);

  useEffect(() => {
    localStorage.setItem('bongstore_orders', JSON.stringify(recentOrders));
  }, [recentOrders]);

  // Navigation and filtering states
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [selectedCollection, setSelectedCollection] = useState<CollectionSlug | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Drawers visibility
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [sizeGuideCallback, setSizeGuideCallback] = useState<((size: ProductSize) => void) | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrderTrackerOpen, setIsOrderTrackerOpen] = useState(false);
  const [isStoreLocatorOpen, setIsStoreLocatorOpen] = useState(false);
  const [isVipClubOpen, setIsVipClubOpen] = useState(false);
  const [isAiStylistOpen, setIsAiStylistOpen] = useState(false);

  // Toast Notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Cart operations
  const handleAddToCart = (
    product: Product,
    color: ProductColor,
    size: ProductSize,
    quantity: number = 1
  ) => {
    const itemId = `${product.id}-${color.name}-${size}`;
    setCart((prev) => {
      const existing = prev.find((item) => item.id === itemId);
      if (existing) {
        return prev.map((item) =>
          item.id === itemId ? { ...item, quantity: item.quantity + quantity } : item
        );
      } else {
        return [
          ...prev,
          {
            id: itemId,
            product,
            selectedColor: color,
            selectedSize: size,
            quantity,
          },
        ];
      }
    });

    showToast(`Đã thêm "${product.name} (${color.name} - Size ${size})" vào giỏ hàng!`);
  };

  const handleUpdateQuantity = (itemId: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.id === itemId ? { ...item, quantity: qty } : item))
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== itemId));
  };

  // Buy Now direct flow
  const handleBuyNow = (
    product: Product,
    color: ProductColor,
    size: ProductSize,
    quantity: number = 1
  ) => {
    handleAddToCart(product, color, size, quantity);
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Add multiple combo items (from AI Stylist)
  const handleAddComboToCart = (
    items: { product: Product; color: ProductColor; size: ProductSize }[]
  ) => {
    items.forEach((it) => {
      handleAddToCart(it.product, it.color, it.size, 1);
    });
    // Automatically apply bundle voucher if not applied
    if (!appliedVoucher) {
      const bundleVoucher = VOUCHERS.find((v) => v.code === 'WEARYOURSTORY');
      if (bundleVoucher) setAppliedVoucher(bundleVoucher);
    }
    setIsCartOpen(true);
  };

  // Wishlist toggle
  const handleToggleWishlist = (product: Product) => {
    setWishlistIds((prev) => {
      if (prev.includes(product.id)) {
        showToast(`Đã xóa "${product.name}" khỏi danh sách yêu thích`);
        return prev.filter((id) => id !== product.id);
      } else {
        showToast(`Đã thêm "${product.name}" vào danh sách yêu thích! ❤️`);
        return [...prev, product.id];
      }
    });
  };

  // Navigation scroll helper
  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Wishlist products object array (using active products state)
  const wishlistProducts = products.filter((p) => wishlistIds.includes(p.id));

  // Open Size Guide from Quick View with callback
  const handleOpenSizeGuideFromProduct = (callback: (size: ProductSize) => void) => {
    setSizeGuideCallback(() => callback);
    setIsSizeGuideOpen(true);
  };

  const handleOrderSuccess = (newOrder: OrderInfo) => {
    setRecentOrders((prev) => [newOrder, ...prev]);
    setCart([]);
    setAppliedVoucher(null);
  };

  // Admin order status update
  const handleUpdateOrderStatus = (orderId: string, status: OrderInfo['status']) => {
    setRecentOrders((prev) => 
      prev.map((o) => (o.orderId === orderId ? { ...o, status } : o))
    );
    showToast(`Đã cập nhật trạng thái đơn ${orderId} sang "${status}"`);
  };

  // Admin delete order
  const handleDeleteOrder = (orderId: string) => {
    setRecentOrders((prev) => prev.filter((o) => o.orderId !== orderId));
    showToast(`Đã xóa đơn hàng ${orderId}`);
  };

  // Admin reset data to factory default
  const handleResetToDefault = () => {
    setProducts(PRODUCTS);
    setVouchers(VOUCHERS);
    setSiteSettings(DEFAULT_SITE_SETTINGS);
    setHeroSlides(DEFAULT_HERO_SLIDES);
    setCategoryShowcase(DEFAULT_CATEGORIES);
    setLookbooks(LOOKBOOKS);
    localStorage.removeItem('bongstore_products');
    localStorage.removeItem('bongstore_vouchers');
    localStorage.removeItem('bongstore_site_settings');
    localStorage.removeItem('bongstore_hero_slides');
    localStorage.removeItem('bongstore_category_showcase');
    localStorage.removeItem('bongstore_lookbooks');
    showToast('Đã khôi phục toàn bộ dữ liệu gốc của Bông Store thành công!');
  };

  // IF ADMIN VIEW IS ACTIVE, RENDER DEDICATED ADMIN PORTAL
  if (isAdminView) {
    return (
      <div className="min-h-screen bg-[#F4F4F5] text-neutral-900 flex flex-col font-sans">
        <AdminPortal
          products={products}
          onSaveProducts={setProducts}
          orders={recentOrders}
          onUpdateOrderStatus={handleUpdateOrderStatus}
          onDeleteOrder={handleDeleteOrder}
          vouchers={vouchers}
          onSaveVouchers={setVouchers}
          siteSettings={siteSettings}
          onSaveSiteSettings={setSiteSettings}
          heroSlides={heroSlides}
          onSaveHeroSlides={setHeroSlides}
          categoryShowcase={categoryShowcase}
          onSaveCategoryShowcase={setCategoryShowcase}
          lookbooks={lookbooks}
          onSaveLookbooks={setLookbooks}
          onResetToDefault={handleResetToDefault}
          onExitAdmin={handleExitAdmin}
          onQuickView={(p) => setQuickViewProduct(p)}
        />

        {/* Quick View Product Modal also accessible in Admin for verification */}
        <QuickViewModal
          product={quickViewProduct}
          isOpen={Boolean(quickViewProduct)}
          onClose={() => setQuickViewProduct(null)}
          isWishlisted={Boolean(quickViewProduct && wishlistIds.includes(quickViewProduct.id))}
          onToggleWishlist={handleToggleWishlist}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onOpenSizeGuide={handleOpenSizeGuideFromProduct}
        />
      </div>
    );
  }

  // ELSE RENDER CUSTOMER STOREFRONT
  return (
    <div className="min-h-screen bg-[#FAFAFA] text-[#111111] flex flex-col selection:bg-neutral-900 selection:text-white">
      
      {/* Top Announcement Bar */}
      <AnnouncementBar
        announcementTexts={siteSettings.announcementTexts}
        hotline={siteSettings.hotline}
        onOpenStoreLocator={() => setIsStoreLocatorOpen(true)}
        onOpenOrderTracker={() => setIsOrderTrackerOpen(true)}
        onOpenVouchers={() => setIsVipClubOpen(true)}
      />

      {/* Main Header & Navbar */}
      <Navbar
        siteSettings={siteSettings}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        wishlistCount={wishlistIds.length}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        selectedCollection={selectedCollection}
        onSelectCollection={setSelectedCollection}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAiStylist={() => setIsAiStylistOpen(true)}
        onOpenVipClub={() => setIsVipClubOpen(true)}
        onOpenStoreLocator={() => setIsStoreLocatorOpen(true)}
        onNavigateSection={handleNavigateSection}
      />

      {/* Main Page Sections */}
      <main className="flex-1">
        {/* Hero Slider */}
        <HeroSlider
          slides={heroSlides}
          onExploreCollection={(slug) => {
            setSelectedCollection(slug);
            setSelectedCategory('all');
            handleNavigateSection('products-section');
          }}
          onExploreAll={() => {
            setSelectedCollection('all');
            setSelectedCategory('all');
            handleNavigateSection('products-section');
          }}
          onOpenAiStylist={() => setIsAiStylistOpen(true)}
        />

        {/* Streetwear Marquee Ticker */}
        <MarqueeBanner marqueeTexts={siteSettings.marqueeTexts} />

        {/* Categories Showcase */}
        <CategoryShowcase
          categories={categoryShowcase}
          onSelectCategory={setSelectedCategory}
          onNavigateSection={handleNavigateSection}
        />

        {/* Product Catalog Grid with Advanced Filters */}
        <ProductGrid
          products={products}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          selectedCollection={selectedCollection}
          onSelectCollection={setSelectedCollection}
          searchQuery={searchQuery}
          onClearSearch={() => setSearchQuery('')}
          wishlistIds={wishlistIds}
          onToggleWishlist={handleToggleWishlist}
          onQuickView={(p) => setQuickViewProduct(p)}
          onAddToCart={handleAddToCart}
        />

        {/* Interactive Shoppable Lookbook */}
        <ShoppableLookbook
          lookbooks={lookbooks}
          products={products}
          onQuickView={(p) => setQuickViewProduct(p)}
          onAddToCart={handleAddToCart}
        />

        {/* Brand Story Section */}
        <StorySection story={siteSettings.story} />
      </main>

      {/* Footer */}
      <Footer
        siteSettings={siteSettings}
        onOpenStoreLocator={() => setIsStoreLocatorOpen(true)}
        onOpenOrderTracker={() => setIsOrderTrackerOpen(true)}
        onOpenSizeGuide={() => {
          setSizeGuideCallback(null);
          setIsSizeGuideOpen(true);
        }}
        onOpenVipClub={() => setIsVipClubOpen(true)}
      />

      {/* MODALS & DRAWERS */}

      {/* Quick View Product Modal */}
      <QuickViewModal
        product={quickViewProduct}
        isOpen={Boolean(quickViewProduct)}
        onClose={() => setQuickViewProduct(null)}
        isWishlisted={Boolean(quickViewProduct && wishlistIds.includes(quickViewProduct.id))}
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
        onOpenSizeGuide={handleOpenSizeGuideFromProduct}
      />

      {/* Cart Slide-over Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        appliedVoucher={appliedVoucher}
        onApplyVoucher={setAppliedVoucher}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        onAddToCart={handleAddToCart}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistProducts={wishlistProducts}
        onRemoveFromWishlist={handleToggleWishlist}
        onQuickView={(p) => setQuickViewProduct(p)}
        onAddToCart={handleAddToCart}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={products}
        onSelectProduct={(p) => setQuickViewProduct(p)}
        onSearchSubmit={(q) => {
          setSearchQuery(q);
          handleNavigateSection('products-section');
        }}
      />

      {/* Smart Size Guide Modal */}
      <SmartSizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => {
          setIsSizeGuideOpen(false);
          setSizeGuideCallback(null);
        }}
        onSelectSize={sizeGuideCallback || undefined}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        appliedVoucher={appliedVoucher}
        siteSettings={siteSettings}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Order Tracker Modal */}
      <OrderTrackerModal
        isOpen={isOrderTrackerOpen}
        onClose={() => setIsOrderTrackerOpen(false)}
        recentOrders={recentOrders}
      />

      {/* Store Locator Modal */}
      <StoreLocatorModal
        isOpen={isStoreLocatorOpen}
        onClose={() => setIsStoreLocatorOpen(false)}
      />

      {/* VIP Club Modal */}
      <VipClubModal
        isOpen={isVipClubOpen}
        onClose={() => setIsVipClubOpen(false)}
        onApplyVoucher={(v) => {
          setAppliedVoucher(v);
          showToast(`Đã áp dụng mã ưu đãi ${v.code}!`);
        }}
      />

      {/* Wear Your Story AI Stylist Modal */}
      <AiStylistModal
        isOpen={isAiStylistOpen}
        onClose={() => setIsAiStylistOpen(false)}
        onAddComboToCart={handleAddComboToCart}
        onQuickView={(p) => setQuickViewProduct(p)}
      />

      {/* Floating Action / Quick Stylist Widget */}
      <aside aria-label="Nút hỗ trợ phối đồ nhanh" className="fixed bottom-6 right-6 z-30 hidden sm:block">
        <button
          onClick={() => setIsAiStylistOpen(true)}
          className="flex items-center gap-2 bg-neutral-900 hover:bg-black text-white px-4 py-3 rounded-full shadow-2xl hover:scale-105 transition-all text-xs font-extrabold uppercase tracking-wider border border-neutral-700 cursor-pointer"
        >
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
          <span>Gợi Ý Phối Đồ AI</span>
        </button>
      </aside>

      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 text-white px-5 py-2.5 rounded-full shadow-2xl text-xs font-bold border border-neutral-700 animate-in fade-in slide-in-from-bottom-3 duration-200">
          {toastMessage}
        </div>
      )}

    </div>
  );
}
