import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), 'store_database.json');

// Support large payloads for base64 images (banner, products, QR codes)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// In-memory store cache
let storeDataCache: any = null;

function loadStoreDataFromFile() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      if (raw && raw.trim()) {
        storeDataCache = JSON.parse(raw);
        console.log('[Server] Loaded store data from disk successfully.');
        return storeDataCache;
      }
    }
  } catch (err) {
    console.error('[Server] Failed to read store data from file:', err);
  }
  storeDataCache = null;
  return null;
}

function saveStoreDataToFile(data: any) {
  try {
    storeDataCache = {
      ...data,
      lastUpdated: new Date().toISOString(),
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(storeDataCache, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('[Server] Failed to write store data to file:', err);
    return false;
  }
}

// Load initial data on startup
loadStoreDataFromFile();

// API ROUTES
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasCustomData: Boolean(storeDataCache),
    lastUpdated: storeDataCache?.lastUpdated || null,
  });
});

// GET complete store data
app.get('/api/store-data', (req, res) => {
  if (storeDataCache) {
    return res.json({
      success: true,
      data: storeDataCache,
      lastUpdated: storeDataCache.lastUpdated,
    });
  }
  return res.json({
    success: true,
    data: null,
    message: 'Using default client dataset',
  });
});

// POST / Save complete or partial store data (called from Admin and Storefront)
app.post('/api/store-data', (req, res) => {
  try {
    const payload = req.body;
    const current = storeDataCache || {};
    const updated = {
      ...current,
      ...payload,
      lastUpdated: new Date().toISOString(),
    };
    saveStoreDataToFile(updated);
    res.json({
      success: true,
      message: 'Đã lưu và đồng bộ dữ liệu toàn hệ thống thành công!',
      lastUpdated: updated.lastUpdated,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Lỗi khi lưu dữ liệu' });
  }
});

// POST new customer order
app.post('/api/orders', (req, res) => {
  try {
    const newOrder = req.body;
    const current = storeDataCache || {};
    const orders = Array.isArray(current.orders) ? current.orders : [];
    const updatedOrders = [newOrder, ...orders];
    const updated = {
      ...current,
      orders: updatedOrders,
      lastUpdated: new Date().toISOString(),
    };
    saveStoreDataToFile(updated);
    res.json({
      success: true,
      order: newOrder,
      lastUpdated: updated.lastUpdated,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Lỗi đặt hàng' });
  }
});

// POST reset to defaults
app.post('/api/reset-data', (req, res) => {
  try {
    storeDataCache = null;
    if (fs.existsSync(DATA_FILE)) {
      fs.unlinkSync(DATA_FILE);
    }
    res.json({ success: true, message: 'Đã xóa dữ liệu tùy chỉnh, khôi phục gốc!' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message });
  }
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[BongStore Server] Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
